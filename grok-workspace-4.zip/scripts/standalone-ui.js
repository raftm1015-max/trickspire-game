(function () {
  const app = document.getElementById("app");
  app.innerHTML = '<div id="play-root" class="hidden"></div><div id="ui-root"></div>';
  const playRoot = document.getElementById("play-root");
  const uiRoot = document.getElementById("ui-root");

  let save = loadSave();
  let screen = "title";
  let playWorld = 0;
  let playRoom = 0;
  let game = null;
  let hud = { souls: save.souls, coins: save.coins, world: 0, room: 0, signAr: null, signEn: null, deaths: 0, paused: false };
  let adKind = null;
  let adLeft = 0;
  let adTimer = null;
  let toast = null;
  let toastTimer = null;
  let padsBound = false;

  const lang = () => save.settings.lang;
  const txt = (k) => t(k, lang());
  const worldName = (id) => {
    const w = WORLDS_INFO[id];
    if (!w) return "";
    return lang() === "ar" ? w.nameAr : w.nameEn;
  };

  function persist() { writeSave(save); }

  function setToast(msg) {
    toast = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast = null; paintUi(); }, 1800);
    paintUi();
  }

  function bootAudio() {
    unlockAudio();
    startMusic();
    setVolumes(save.settings.sfx, save.settings.music);
    sfx.click();
  }

  function ensurePlayLayer() {
    if (playRoot.dataset.ready) return;
    playRoot.className = "playwrap";
    playRoot.innerHTML = `
      <canvas id="game-canvas"></canvas>
      <div class="hud">
        <div class="chip"><div class="dots" id="hud-souls"></div></div>
        <div class="chip" id="hud-meta"></div>
      </div>
      <div class="sign hidden" id="hud-sign"></div>
      <button class="pause" id="btn-pause">❚❚</button>
      <div class="pads" id="pads">
        <div style="display:flex;gap:8px">
          <button class="pad" id="pad-l">←</button>
          <button class="pad" id="pad-r">→</button>
        </div>
        <button class="pad jump" id="pad-j"></button>
      </div>`;
    playRoot.dataset.ready = "1";
    padsBound = false;
    bindPads();
    document.getElementById("btn-pause").onclick = () => {
      screen = "pause";
      if (game) game.setPaused(true);
      paintUi();
    };
  }

  function bindPads() {
    if (padsBound) return;
    padsBound = true;
    function hold(id, action) {
      const n = document.getElementById(id);
      if (!n) return;
      const down = (e) => {
        e.preventDefault();
        e.stopPropagation();
        try { n.setPointerCapture(e.pointerId); } catch (err) {}
        if (game) game.input.pointerDown(action, e.pointerId);
      };
      const up = (e) => {
        if (game) game.input.pointerUp(action, e.pointerId);
      };
      n.addEventListener("pointerdown", down, { passive: false });
      n.addEventListener("pointerup", up);
      n.addEventListener("pointercancel", up);
      n.addEventListener("lostpointercapture", up);
    }
    hold("pad-l", "left");
    hold("pad-r", "right");
    hold("pad-j", "jump");
  }

  function bootGame() {
    ensurePlayLayer();
    const canvas = document.getElementById("game-canvas");
    if (!canvas) return;
    if (game) { game.destroy(); game = null; }
    game = new TrickspireGame(canvas, {
      onHud: (h) => {
        hud = h;
        save.souls = h.souls;
        save.coins = h.coins;
        if (h.paused && screen === "play") {
          screen = "pause";
          if (game) game.setPaused(true);
          paintUi();
        }
        paintHud();
      },
      onDeath: () => {},
      onRoomClear: () => {
        if (game) { save.coins = game.coins; save.souls = game.souls; }
        save = markRoomCleared(save, playWorld, playRoom);
        if (playRoom + 1 >= ROOMS) {
          save.souls = MAX_SOULS;
          playWorld = playWorld + 1;
          playRoom = 0;
          screen = "worldClear";
        } else {
          playRoom = playRoom + 1;
          screen = "roomClear";
        }
        persist();
        if (game) game.setPaused(true);
        paintUi();
      },
      onWorldFail: () => {
        save.souls = 0;
        screen = "worldFail";
        persist();
        paintUi();
      },
      onWorldClear: () => {},
      onCoin: () => {},
      onCheckpoint: () => {},
    });
    game.lang = lang();
    game.shakeOn = save.settings.shake;
    game.start(playWorld, playRoom, save.souls, save.coins);
    document.getElementById("pad-j").textContent = txt("jump");
  }

  function startRun(world, room) {
    if (save.souls <= 0) save.souls = MAX_SOULS;
    save.currentWorld = world;
    save.currentRoom = room;
    save.inRun = true;
    playWorld = world;
    playRoom = room;
    screen = "play";
    persist();
    playRoot.classList.remove("hidden");
    paintUi();
    bootGame();
  }

  function leavePlay() {
    if (game) { game.destroy(); game = null; }
    playRoot.classList.add("hidden");
  }

  function showAd(kind) {
    adKind = kind;
    adLeft = kind === "interstitial" ? 3 : 5;
    screen = "ad";
    paintUi();
    clearInterval(adTimer);
    adTimer = setInterval(() => {
      adLeft -= 1;
      if (adLeft <= 0) { clearInterval(adTimer); adLeft = 0; }
      const n = document.getElementById("ad-skip");
      if (n) {
        n.disabled = adLeft > 0;
        n.textContent = adLeft > 0 ? txt("skipAd") + " " + adLeft : txt("skipAd");
      }
    }, 1000);
  }

  function finishAd() {
    clearInterval(adTimer);
    const kind = adKind;
    adKind = null;
    if (kind === "rewarded-soul") {
      save.souls = Math.min(MAX_SOULS + 5, save.souls + 1);
      persist();
      screen = "pause";
      paintUi();
      return;
    }
    if (kind === "rewarded-coins") {
      save.coins += 25;
      persist();
      screen = "shop";
      leavePlay();
      paintUi();
      return;
    }
    if (kind === "rewarded-continue") {
      save.souls = 3;
      persist();
      startRun(playWorld, playRoom);
      return;
    }
    startRun(playWorld, playRoom);
  }

  function buy(cost, apply) {
    if (save.coins < cost) { setToast(txt("needCoins")); return false; }
    save.coins -= cost;
    apply();
    persist();
    paintUi();
    return true;
  }

  function paintHud() {
    const souls = document.getElementById("hud-souls");
    const meta = document.getElementById("hud-meta");
    const sign = document.getElementById("hud-sign");
    const pads = document.getElementById("pads");
    const pause = document.getElementById("btn-pause");
    if (souls) {
      souls.innerHTML = Array.from({ length: MAX_SOULS }, (_, i) =>
        `<span class="dot${i < hud.souls ? " on" : ""}"></span>`
      ).join("");
    }
    if (meta) meta.textContent = `${worldName(hud.world)} · ${txt("room")} ${hud.room + 1}/${ROOMS} · ${hud.coins}`;
    if (sign) {
      const s = lang() === "ar" ? hud.signAr : hud.signEn;
      sign.textContent = s || "";
      sign.classList.toggle("hidden", !s || screen !== "play");
    }
    if (pads) pads.classList.toggle("hidden", screen !== "play");
    if (pause) pause.classList.toggle("hidden", screen !== "play");
  }

  function overlay(title, body, buttons) {
    return `<div class="overlay"><div class="modal">
      <h2>${title}</h2>
      ${body ? `<p class="muted" style="margin:8px 0 0;line-height:1.5">${body}</p>` : ""}
      ${buttons}
    </div></div>`;
  }

  function paintUi() {
    document.documentElement.lang = lang();
    document.documentElement.dir = lang() === "ar" ? "rtl" : "ltr";
    const ads = !save.adsRemoved;
    const inPlay = ["play", "pause", "roomClear", "worldFail", "worldClear", "ad"].includes(screen);
    if (!inPlay) leavePlay();
    else {
      playRoot.classList.remove("hidden");
      if (game) game.setPaused(screen !== "play");
      paintHud();
    }

    let html = "";
    if (screen === "title") {
      html = `<main class="screen center">
        <div class="wash"></div>
        ${ads ? `<div class="banner">${txt("adLabel")} · ${txt("sponsor")}</div>` : `<div></div>`}
        <header>
          <p class="kicker">TRICKSPIRE</p>
          <h1 class="title">${txt("title")}</h1>
          <p class="muted" style="max-width:22rem;margin:12px auto 0;line-height:1.6">${txt("tag")}</p>
          <p class="subtle" style="margin-top:8px">20 × 10 · ${txt("souls")} 10</p>
        </header>
        <div class="stack">
          <button class="btn" id="go-play">${save.inRun ? txt("continue") : txt("play")}</button>
          <button class="btn sec" id="go-worlds">${txt("worlds")}</button>
          <div class="row">
            <button class="btn sec" id="go-shop">${txt("shop")}</button>
            <button class="btn sec" id="go-install">${txt("install")}</button>
          </div>
          <div class="row">
            <button class="btn ghost" id="go-how">${txt("how")}</button>
            <button class="btn ghost" id="go-settings">${txt("settings")}</button>
          </div>
        </div>
      </main>`;
    } else if (screen === "worlds") {
      html = `<main class="screen"><div class="top"><button class="icon" id="go-title">←</button><h1>${txt("worlds")}</h1></div><div class="grid">`;
      for (const w of WORLDS_INFO) {
        const locked = w.id > save.unlockedWorld;
        const done = (save.bestRoom[w.id] || 0) >= ROOMS;
        const progress = save.bestRoom[w.id] || 0;
        html += `<button class="card" data-world="${w.id}" ${locked ? "disabled" : ""}>
          <div class="swatch" style="background:${w.sky[1]}"></div>
          <div style="font-weight:600;font-size:14px">${String(w.id + 1).padStart(2,"0")} · ${lang()==="ar"?w.nameAr:w.nameEn}</div>
          <div class="muted" style="font-size:12px;margin-top:4px">${lang()==="ar"?w.tagAr:w.tagEn}</div>
          <div class="subtle" style="margin-top:8px">${locked?txt("locked"):done?txt("cleared"):progress+"/"+ROOMS}</div>
        </button>`;
      }
      html += `</div></main>`;
    } else if (screen === "shop") {
      html = `<main class="screen"><div class="top"><button class="icon" id="go-title">←</button><h1>${txt("shop")}</h1></div>
        <p class="muted" style="margin-top:8px">${txt("coins")} ${save.coins} · ${txt("souls")} ${save.souls}</p>
        ${ads ? `<div class="banner" style="margin-top:12px">${txt("adLabel")} · ${txt("sponsor")}</div>` : ""}
        <div class="stack" style="margin-top:16px">
          <button class="shop-row" id="buy-1"><span>${txt("buySoul")}</span><span class="muted">30</span></button>
          <button class="shop-row" id="buy-3"><span>${txt("buySouls3")}</span><span class="muted">80</span></button>
          <button class="shop-row" id="buy-refill"><span>${txt("refill")}</span><span class="muted">120</span></button>
          <button class="shop-row" id="buy-ads" ${save.adsRemoved?"disabled":""}><span>${txt("removeAds")}</span><span class="muted">${save.adsRemoved?txt("owned"):"500"}</span></button>
          <button class="btn sec" id="ad-coins">${txt("watchCoins")}</button>
        </div></main>`;
    } else if (screen === "settings") {
      html = `<main class="screen"><div class="top"><button class="icon" id="go-title">←</button><h1>${txt("settings")}</h1></div>
        <label>${txt("sfx")}</label><input id="vol-sfx" type="range" min="0" max="1" step="0.05" value="${save.settings.sfx}"/>
        <label>${txt("music")}</label><input id="vol-music" type="range" min="0" max="1" step="0.05" value="${save.settings.music}"/>
        <button class="shop-row" id="tog-shake" style="margin-top:16px"><span>${txt("shake")}</span><span class="muted">${save.settings.shake?"On":"Off"}</span></button>
        <button class="shop-row" id="tog-lang"><span>${txt("lang")}</span><span class="muted">${lang()==="ar"?"العربية":"English"}</span></button>
        <button class="btn danger" id="do-reset" style="margin-top:32px;width:min(100%,24rem)">${txt("reset")}</button>
      </main>`;
    } else if (screen === "how") {
      html = `<main class="screen"><div class="top"><button class="icon" id="go-title">←</button><h1>${txt("how")}</h1></div>
        <p class="muted" style="margin-top:24px;max-width:28rem;line-height:1.7">${txt("howBody")}</p></main>`;
    } else if (screen === "install") {
      html = `<main class="screen"><div class="top"><button class="icon" id="go-title">←</button><h1>${txt("install")}</h1></div>
        <p class="muted" style="margin-top:24px;max-width:28rem;line-height:1.7">${lang()==="ar"
          ? "هذا الملف هو اللعبة كاملة: المحرك، الرسومات، الموسيقى، والعوالم. احفظه باسم index.html ثم افتحه في أي متصفح. يعمل بعد الحفظ بدون إنترنت."
          : "This file is the whole game: engine, art, music, and worlds. Save it as index.html and open it in any browser. It works offline after saving."}</p>
        <div class="stack" style="margin-top:20px">
          <button class="btn" id="copy-html">${lang()==="ar"?"نسخ كود HTML":"Copy HTML code"}</button>
          <button class="btn sec" id="dl-html">${lang()==="ar"?"تنزيل index.html":"Download index.html"}</button>
          <button class="btn ghost" id="show-code">${lang()==="ar"?"عرض الكود للنسخ اليدوي":"Show code to copy"}</button>
        </div>
        <textarea id="src-box" class="codebox hidden" readonly spellcheck="false"></textarea>
      </main>`;
    } else if (screen === "pause") {
      html = overlay(txt("pause"), "", `
        <button class="btn" id="do-resume">${txt("resume")}</button>
        <button class="btn sec" id="ad-soul">${txt("extraSoul")}</button>
        <button class="btn sec" id="do-hint">${txt("hint")}</button>
        <button class="btn ghost" id="go-title">${txt("menu")}</button>`);
    } else if (screen === "roomClear") {
      html = overlay(txt("roomClear"), `${txt("room")} ${playRoom}/${ROOMS}`, `<button class="btn" id="do-next">${txt("next")}</button>`);
    } else if (screen === "worldClear") {
      html = overlay(txt("worldClear"), "", `<button class="btn" id="do-next-world">${txt("next")}</button>`);
    } else if (screen === "worldFail") {
      html = overlay(txt("worldFail"), txt("worldFailBody"), `
        <button class="btn" id="do-restart">${txt("restartWorld")}</button>
        <button class="btn sec" id="ad-continue">${txt("watchContinue")}</button>
        <button class="btn ghost" id="go-title">${txt("menu")}</button>`);
    } else if (screen === "ad") {
      html = `<div class="overlay"><div class="modal" style="text-align:center">
        <p class="kicker">${txt("adLabel")}</p>
        <div class="banner" style="height:180px;margin-top:16px">${txt("sponsor")}<br/>Trickspire Ads</div>
        <button class="btn" id="ad-skip" ${adLeft>0?"disabled":""}>${adLeft>0?txt("skipAd")+" "+adLeft:txt("skipAd")}</button>
      </div></div>`;
    } else if (screen === "play") {
      html = "";
    }
    if (toast) html += `<div class="toast">${toast}</div>`;
    uiRoot.innerHTML = html;
    bind();
  }

  function bind() {
    const click = (id, fn) => { const n = document.getElementById(id); if (n) n.onclick = fn; };
    click("go-play", () => { bootAudio(); startRun(save.inRun ? save.currentWorld : 0, save.inRun ? save.currentRoom : 0); });
    click("go-worlds", () => { screen = "worlds"; paintUi(); });
    click("go-shop", () => { screen = "shop"; paintUi(); });
    click("go-settings", () => { screen = "settings"; paintUi(); });
    click("go-how", () => { screen = "how"; paintUi(); });
    click("go-install", () => { screen = "install"; paintUi(); });
    click("go-title", () => { leavePlay(); screen = "title"; paintUi(); });
    click("do-resume", () => { screen = "play"; if (game) game.setPaused(false); paintUi(); });
    click("do-next", () => {
      if (!save.adsRemoved && playRoom % 5 === 0) { showAd("interstitial"); return; }
      startRun(playWorld, playRoom);
    });
    click("do-next-world", () => {
      if (playWorld >= WORLDS) { leavePlay(); screen = "title"; paintUi(); return; }
      if (!save.adsRemoved) { showAd("interstitial"); return; }
      startRun(playWorld, 0);
    });
    click("do-restart", () => { save.souls = MAX_SOULS; persist(); startRun(playWorld, 0); });
    click("ad-continue", () => showAd("rewarded-continue"));
    click("ad-soul", () => showAd("rewarded-soul"));
    click("ad-coins", () => showAd("rewarded-coins"));
    click("ad-skip", () => { if (adLeft <= 0) finishAd(); });
    click("do-hint", () => { if (buy(15, () => {})) { if (game) game.setHint(8); } });
    click("buy-1", () => buy(30, () => { save.souls = Math.min(MAX_SOULS + 5, save.souls + 1); }));
    click("buy-3", () => buy(80, () => { save.souls = Math.min(MAX_SOULS + 5, save.souls + 3); }));
    click("buy-refill", () => buy(120, () => { save.souls = MAX_SOULS; }));
    click("buy-ads", () => buy(500, () => { save.adsRemoved = true; }));
    click("tog-shake", () => { save.settings.shake = !save.settings.shake; persist(); paintUi(); });
    click("tog-lang", () => { save.settings.lang = lang() === "ar" ? "en" : "ar"; persist(); paintUi(); });
    click("do-reset", () => { if (confirm(txt("confirmReset"))) { save = defaultSave(); persist(); paintUi(); } });
    const sfxEl = document.getElementById("vol-sfx");
    const musEl = document.getElementById("vol-music");
    if (sfxEl) sfxEl.oninput = (e) => { save.settings.sfx = Number(e.target.value); persist(); setVolumes(save.settings.sfx, save.settings.music); };
    if (musEl) musEl.oninput = (e) => { save.settings.music = Number(e.target.value); persist(); setVolumes(save.settings.sfx, save.settings.music); };
    document.querySelectorAll("[data-world]").forEach((b) => {
      b.onclick = () => { bootAudio(); startRun(Number(b.getAttribute("data-world")), 0); };
    });
    click("copy-html", async () => {
      const src = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;
      try {
        await navigator.clipboard.writeText(src);
        setToast(lang() === "ar" ? "تم النسخ — الصق في ملف index.html" : "Copied — paste into index.html");
      } catch {
        setToast(lang() === "ar" ? "استخدم زر التنزيل أو عرض الكود" : "Use download or show code");
      }
    });
    click("dl-html", () => {
      const blob = new Blob(["<!DOCTYPE html>\n" + document.documentElement.outerHTML], { type: "text/html;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "index.html";
      a.click();
      URL.revokeObjectURL(a.href);
    });
    click("show-code", () => {
      const box = document.getElementById("src-box");
      if (!box) return;
      box.classList.remove("hidden");
      box.value = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;
      box.focus();
      box.select();
      setToast(lang() === "ar" ? "حدّد الكل ثم انسخ" : "Select all, then copy");
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) persist();
    else resumeAudio();
  });

  paintUi();
})();

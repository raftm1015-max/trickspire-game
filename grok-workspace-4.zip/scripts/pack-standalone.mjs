import fs from "node:fs";
import path from "node:path";
import ts from "typescript";

const root = "/workspace";
const files = [
  "types.ts",
  "copy.ts",
  "worlds.ts",
  "save.ts",
  "input.ts",
  "audio.ts",
  "levels.ts",
  "render.ts",
  "engine.ts",
];

function strip(src) {
  let s = src.replace(/^\uFEFF/, "");
  s = s.replace(/^import[\s\S]*?from\s+["'][^"']+["'];?\s*/gm, "");
  s = s.replace(/declare global \{[\s\S]*?\n\}\s*/g, "");
  s = s.replace(/\bexport\s+default\s+/g, "");
  s = s.replace(/\bexport\s+/g, "");
  return s;
}

let combined = files
  .map((f) => strip(fs.readFileSync(path.join(root, "src/game", f), "utf8")))
  .join("\n\n");

combined = combined.replace(
  /function loadSprites\(\)[\s\S]*?\n\}/,
  `function loadSprites() {
  const S = window.__TRICK_SPRITES || {};
  const load = (src) => { const img = new Image(); img.src = src; return img; };
  return {
    idle: load(S.idle || ""),
    run: load(S.run || ""),
    jump: load(S.jump || ""),
    hurt: load(S.hurt || ""),
  };
}`,
);

const out = ts.transpileModule(combined, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.None,
    removeComments: true,
    strict: false,
  },
  reportDiagnostics: true,
});

if (out.diagnostics?.length) {
  const msg = ts.formatDiagnosticsWithColorAndContext(out.diagnostics, {
    getCanonicalFileName: (f) => f,
    getCurrentDirectory: () => root,
    getNewLine: () => "\n",
  });
  console.error(msg);
}

const js = out.outputText;

function dataUri(file) {
  const buf = fs.readFileSync(file);
  return `data:image/png;base64,${buf.toString("base64")}`;
}

const sprites = {
  idle: dataUri(path.join(root, "public/sprites/wick-idle.png")),
  run: dataUri(path.join(root, "public/sprites/wick-run.png")),
  jump: dataUri(path.join(root, "public/sprites/wick-jump.png")),
  hurt: dataUri(path.join(root, "public/sprites/wick-hurt.png")),
};

const ui = fs.readFileSync(path.join(root, "scripts/standalone-ui.js"), "utf8");
const css = fs.readFileSync(path.join(root, "scripts/standalone.css"), "utf8");

const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
<meta name="theme-color" content="#0a090c"/>
<meta name="description" content="Trickspire — برج الخداع. لعبة منصات مخادعة. 20 عالماً × 10 غرف."/>
<title>Trickspire — برج الخداع</title>
<!--
  Trickspire / برج الخداع
  احفظ هذا الملف باسم index.html ثم افتحه في أي متصفح (هاتف أو كمبيوتر).
  ملف واحد مستقل: المحرك + 20×10 مرحلة + الرسومات + الموسيقى + المتجر والإعلانات.
  يعمل بدون إنترنت بعد الحفظ. التقدم يُحفظ في المتصفح.
-->
<style>
${css}
</style>
</head>
<body>
<div id="app"></div>
<script>
window.__TRICK_SPRITES = ${JSON.stringify(sprites)};
</script>
<script>
${js}
</script>
<script>
${ui}
</script>
</body>
</html>
`;

const dests = [
  path.join(root, "public/trickspire.html"),
  path.join(root, "public/index-standalone.html"),
  path.join(root, "artifacts/index.html"),
  path.join(root, "artifacts/trickspire.html"),
];
for (const d of dests) {
  fs.mkdirSync(path.dirname(d), { recursive: true });
  fs.writeFileSync(d, html);
  console.log("wrote", d, html.length, "bytes");
}

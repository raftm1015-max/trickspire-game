import {
  T,
  type LevelSpec,
  type MovingPlat,
  type Sign,
  type Tile,
  type TrollId,
} from "./types";

function mulberry(seed: number) {
  let s = seed | 0;
  return () => {
    s = (Math.imul(s, 1831565813) + 0xdeadbeef) | 0;
    const t = Math.imul(s ^ (s >>> 15), 1 | s);
    return ((t ^ (t >>> 7)) >>> 0) / 4294967296;
  };
}

class Grid {
  cols: number;
  rows: number;
  tiles: Uint8Array;
  constructor(cols: number, rows: number) {
    this.cols = cols;
    this.rows = rows;
    this.tiles = new Uint8Array(cols * rows);
  }
  i(x: number, y: number) {
    return y * this.cols + x;
  }
  in(x: number, y: number) {
    return x >= 0 && y >= 0 && x < this.cols && y < this.rows;
  }
  get(x: number, y: number): Tile {
    if (!this.in(x, y)) return T.SOLID;
    return this.tiles[this.i(x, y)] as Tile;
  }
  set(x: number, y: number, v: Tile) {
    if (this.in(x, y)) this.tiles[this.i(x, y)] = v;
  }
  rect(x: number, y: number, w: number, h: number, v: Tile) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, v);
  }
  border() {
    this.rect(0, 0, this.cols, 1, T.SOLID);
    this.rect(0, this.rows - 1, this.cols, 1, T.SOLID);
    this.rect(0, 0, 1, this.rows, T.SOLID);
    this.rect(this.cols - 1, 0, 1, this.rows, T.SOLID);
  }
  ground() {
    this.rect(1, this.rows - 2, this.cols - 2, 1, T.SOLID);
  }
}

const TROLLS: TrollId[][] = [
  ["none", "none", "none", "falseFloor", "fakeGoal", "reverse", "crumble", "lyingSign", "vanishFloor", "combo"],
  ["crumble", "crumble", "falseFloor", "vanishFloor", "crumble", "fakeGoal", "crumble", "lyingSign", "combo", "crumble"],
  ["none", "spikePop", "falseFloor", "spikePop", "fakeCheck", "spikePop", "lyingSign", "combo", "spikePop", "combo"],
  ["reverse", "swapLR", "cameraFlip", "reverse", "mirrorCam", "swapLR", "reverse", "lyingSign", "combo", "cameraFlip"],
  ["falseFloor", "invisWall", "vanishFloor", "falseFloor", "invisWall", "fakeGoal", "vanishFloor", "combo", "invisWall", "combo"],
  ["gravity", "slowFall", "gravity", "jumpCut", "gravity", "fakeGoal", "slowFall", "combo", "gravity", "combo"],
  ["iceBoost", "boostSpike", "iceBoost", "iceBoost", "boostSpike", "fakeGoal", "iceBoost", "combo", "boostSpike", "combo"],
  ["shrink", "tiny", "shrink", "tiny", "jumpCut", "fakeGoal", "shrink", "combo", "tiny", "combo"],
  ["lyingSign", "fakeCheck", "fakeWin", "lyingSign", "fakeGoal", "fakeWin", "lyingSign", "combo", "fakeCheck", "combo"],
  ["timedDoor", "vanishFloor", "timedDoor", "spikePop", "timedDoor", "fakeGoal", "vanishFloor", "combo", "timedDoor", "combo"],
  ["darkness", "crumble", "invisWall", "darkness", "fakeGoal", "vanishFloor", "lyingSign", "combo", "darkness", "combo"],
  ["fakeGoal", "fakeWin", "crumble", "falseFloor", "fakeGoal", "vanishFloor", "fakeWin", "combo", "crumble", "combo"],
  ["crumble", "spikePop", "falseFloor", "crumble", "fakeGoal", "vanishFloor", "invisWall", "combo", "crumble", "combo"],
  ["teleport", "crumble", "fakeGoal", "teleport", "invisWall", "vanishFloor", "lyingSign", "combo", "teleport", "combo"],
  ["wind", "crumble", "boostSpike", "wind", "fakeGoal", "vanishFloor", "jumpCut", "combo", "wind", "combo"],
  ["risingLava", "crumble", "timedDoor", "risingLava", "fakeGoal", "vanishFloor", "crumble", "combo", "risingLava", "combo"],
  ["invisWall", "falseFloor", "invisWall", "vanishFloor", "crumble", "fakeGoal", "invisWall", "combo", "falseFloor", "combo"],
  ["combo", "reverse", "darkness", "risingLava", "fakeWin", "gravity", "wind", "combo", "crumble", "combo"],
  ["fakeWin", "swapLR", "goalRuns", "crumble", "lockedJump", "vanishFloor", "cameraFlip", "combo", "goalRuns", "combo"],
  ["combo", "reverse", "risingLava", "darkness", "goalRuns", "gravity", "crumble", "combo", "fakeWin", "combo"],
];

function parseAscii(lines: string[], world: number, room: number, trolls: TrollId[], signs: Sign[] = []): LevelSpec {
  const rows = lines.length;
  const cols = Math.max(...lines.map((l) => l.length));
  const g = new Grid(cols, rows);
  let spawn = { x: 2, y: rows - 4 };
  let goal = { x: cols - 3, y: rows - 4 };
  const moving: MovingPlat[] = [];
  for (let y = 0; y < rows; y++) {
    const line = lines[y]!.padEnd(cols, ".");
    for (let x = 0; x < cols; x++) {
      const c = line[x]!;
      switch (c) {
        case "#":
          g.set(x, y, T.SOLID);
          break;
        case "^":
          g.set(x, y, T.SPIKE_U);
          break;
        case "v":
          g.set(x, y, T.SPIKE_D);
          break;
        case "S":
          spawn = { x, y };
          break;
        case "G":
          goal = { x, y };
          g.set(x, y, T.GOAL);
          break;
        case "g":
          g.set(x, y, T.FAKE_GOAL);
          break;
        case "P":
          g.set(x, y, T.CRUMBLE);
          break;
        case "F":
          g.set(x, y, T.FAKE_SOLID);
          break;
        case "I":
          g.set(x, y, T.INVIS);
          break;
        case "i":
          g.set(x, y, T.ICE);
          break;
        case "B":
          g.set(x, y, T.BOUNCE);
          break;
        case "A":
          g.set(x, y, T.TELE_A);
          break;
        case "T":
          g.set(x, y, T.TELE_B);
          break;
        case "-":
          g.set(x, y, T.ONE_WAY);
          break;
        case "=":
          g.set(x, y, T.CONV_R);
          break;
        case "+":
          g.set(x, y, T.CONV_L);
          break;
        case "O":
          g.set(x, y, T.SPRING);
          break;
        case "o":
          g.set(x, y, T.COIN);
          break;
        case "L":
          g.set(x, y, T.LAVA);
          break;
        case "D":
          g.set(x, y, T.DOOR);
          break;
        case "K":
          g.set(x, y, T.BUTTON);
          break;
        case "H":
          g.set(x, y, T.HIDDEN_SPIKE);
          break;
        case "V":
          g.set(x, y, T.VANISH);
          break;
        case "X":
          g.set(x, y, T.SPIKE_POP);
          break;
        default:
          break;
      }
    }
  }
  return finish(g, world, room, trolls, spawn, goal, signs, moving);
}

function finish(
  g: Grid,
  world: number,
  room: number,
  trolls: TrollId[],
  spawn: { x: number; y: number },
  goal: { x: number; y: number },
  signs: Sign[],
  moving: MovingPlat[],
): LevelSpec {
  g.set(spawn.x, g.rows - 2, T.SOLID);
  g.set(goal.x, g.rows - 2, T.SOLID);
  ensureWalk(g, spawn.x, goal.x, world >= 10 ? 4 : 3);
  armDisappearTraps(g);
  ensureWalk(g, spawn.x, goal.x, world >= 10 ? 4 : 3);
  g.set(spawn.x, g.rows - 2, T.SOLID);
  g.set(goal.x, g.rows - 2, T.SOLID);
  const has = (id: TrollId) => trolls.includes(id);
  return {
    cols: g.cols,
    rows: g.rows,
    tiles: g.tiles,
    world,
    room,
    trolls,
    spawn,
    goal,
    signs,
    moving,
    wind: has("wind") ? (world % 2 === 0 ? 140 : -140) : 0,
    gravitySign: 1,
    risingLava: has("risingLava"),
    darkness: has("darkness"),
    cameraFlip: has("cameraFlip"),
    mirrorCam: has("mirrorCam"),
    reverse: has("reverse"),
    swapLR: has("swapLR"),
    shrink: has("shrink") || has("tiny"),
    jumpCut: has("jumpCut"),
    lockedJump: has("lockedJump"),
    goalRuns: has("goalRuns"),
    fakeWin: has("fakeWin"),
    timedDoor: has("timedDoor"),
    vanishFloor: has("vanishFloor"),
  };
}

const TUTORIAL: string[][] = [
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "################################",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########...###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########^^^###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#########FFFF###################",
    "#........^^^^..................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#.................g............#",
    "#................####..........#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "################################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............####............#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#############...################",
    "#............^^^...............#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#######PPPPPPP##################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########^^^###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########VVV###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#...................g..........#",
    "#..................####........#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#######FFFF####PPPP#############",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
];

const TUTORIAL_SIGNS: Sign[][] = [
  [{ x: 10, y: 6, ar: "امشِ إلى الباب. بسيط.", en: "Walk to the door. Simple." }],
  [{ x: 12, y: 5, ar: "اقفز. المسافة تصدق هذه المرة.", en: "Jump. Space tells the truth this time." }],
  [{ x: 12, y: 5, ar: "الإبر سيئة. تجاوزها.", en: "Needles are rude. Go over." }],
  [{ x: 10, y: 5, ar: "الأرض صديقتك.", en: "The floor is your friend." }],
  [{ x: 14, y: 5, ar: "أقرب باب هو الباب.", en: "The nearest door is the door." }],
  [{ x: 12, y: 4, ar: "التحكم معكوس. أو لا.", en: "Controls are reversed. Or not." }],
  [{ x: 12, y: 4, ar: "قف طويلاً. الأرض تحبك.", en: "Stand still. The floor loves you." }],
  [{ x: 12, y: 4, ar: "لا تقفز.", en: "Do not jump here." }],
  [{ x: 14, y: 3, ar: "هذه الأرضية تبدو عادية.", en: "This floor looks ordinary." }],
  [{ x: 10, y: 3, ar: "الآن فهمت القواعد.", en: "Now you know the rules." }],
];

const PHANTOM_ROOM0 = [
  "################################",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#..............VVVV............#",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#S...........o................G#",
  "#######LL########LL#############",
  "#..............................#",
  "################################",
];

const DUST_ROOM4 = [
  "################################",
  "#..............................#",
  "#..........VVVV................#",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#S........o...................G#",
  "######...########...############",
  "#.....^^^........^^^...........#",
  "#..............................#",
  "#..............................#",
  "################################",
];

function trapUnder(g: Grid, x: number, y: number) {
  const by = y + 1;
  if (!g.in(x, by)) return;
  const cur = g.get(x, by);
  if (cur === T.GOAL || cur === T.FAKE_GOAL) {
    const by2 = by + 1;
    if (g.in(x, by2) && g.get(x, by2) !== T.GOAL && g.get(x, by2) !== T.FAKE_GOAL) {
      g.set(x, by2, T.HIDDEN_SPIKE);
    }
    return;
  }
  if (cur === T.HIDDEN_SPIKE) return;
  g.set(x, by, T.HIDDEN_SPIKE);
}

function armDisappearTraps(g: Grid) {
  for (let y = 0; y < g.rows - 1; y++) {
    for (let x = 0; x < g.cols; x++) {
      const t = g.get(x, y);
      if (t !== T.CRUMBLE && t !== T.VANISH) continue;
      trapUnder(g, x, y);
    }
  }
}

function applyTrollTiles(g: Grid, troll: TrollId, R: () => number, spawnX: number, goalX: number) {
  const mid = ((spawnX + goalX) / 2) | 0;
  const gy = g.rows - 2;
  if (troll === "falseFloor" || troll === "combo") {
    const w = 2 + ((R() * 2) | 0);
    const x = Math.max(spawnX + 4, mid - 1);
    for (let i = 0; i < w; i++) {
      if (g.get(x + i, gy) === T.SOLID) {
        g.set(x + i, gy, T.FAKE_SOLID);
        g.set(x + i, gy + 1, T.LAVA);
      }
    }
  }
  if (troll === "crumble" || troll === "combo") {
    const x = mid;
    for (let i = 0; i < 3; i++) {
      if (g.get(x + i, gy) === T.SOLID) {
        g.set(x + i, gy, T.CRUMBLE);
      }
    }
  }
  if (troll === "fakeGoal" || troll === "fakeWin" || troll === "combo") {
    const fx = Math.min(g.cols - 4, mid + 2);
    const fy = gy - 4;
    g.rect(fx - 1, fy + 1, 3, 1, T.SOLID);
    g.set(fx, fy, T.FAKE_GOAL);
  }
  if (troll === "invisWall") {
    const x = mid + 1;
    g.rect(x, gy - 3, 1, 2, T.INVIS);
  }
  if (troll === "iceBoost" || troll === "boostSpike") {
    g.rect(spawnX + 4, gy, 8, 1, T.ICE);
    if (troll === "boostSpike") g.set(spawnX + 12, gy - 1, T.SPIKE_U);
  }
  if (troll === "teleport") {
    g.set(spawnX + 5, gy - 1, T.TELE_A);
    g.set(goalX - 3, gy - 1, T.TELE_B);
  }
  if (troll === "spikePop") {
    for (let x = spawnX + 5; x < goalX - 3; x += 4) g.set(x, gy, T.SPIKE_POP);
  }
  if (troll === "timedDoor") {
    g.rect(mid, gy - 3, 1, 3, T.DOOR);
    g.set(mid - 2, gy - 1, T.BUTTON);
  }
  if (troll === "vanishFloor") {
    const x = Math.min(g.cols - 8, Math.max(spawnX + 8, mid));
    g.rect(x, Math.max(4, gy - 6), 4, 1, T.VANISH);
  }
}

function trollsFor(world: number, room: number): TrollId[] {
  const raw = TROLLS[world]?.[room] ?? "none";
  if (raw !== "combo") {
    if (world >= 10 && raw !== "crumble" && raw !== "none") return [raw, "crumble"];
    return [raw];
  }
  const theme = (TROLLS[world] ?? []).find((id) => id !== "combo" && id !== "none") ?? "crumble";
  if (world >= 10) return [...new Set<TrollId>([theme, "fakeGoal", "crumble", "falseFloor", "vanishFloor"])];
  return [...new Set<TrollId>([theme, "fakeGoal", "crumble", "falseFloor"])];
}

function generate(world: number, room: number): LevelSpec {
  const trolls = trollsFor(world, room);
  const troll = trolls[0] ?? "none";
  const R = mulberry(world * 10007 + room * 9176 + 13);
  const expert = world >= 10;
  const cols = expert ? 42 + room * 2 : 32 + room * 2;
  const rows = expert ? 18 : 16;
  const g = new Grid(cols, rows);
  g.border();
  g.ground();

  const family = (world * 3 + room * 7) % 8;
  const spawn = { x: 2, y: rows - 3 };
  g.rect(1, rows - 2, expert ? 5 : 6, 1, T.SOLID);
  let x = expert ? 6 : 7;
  const plats: { x: number; y: number; w: number }[] = [];
  const segments = expert ? 7 + (room % 4) : 4 + ((room + world) % 3);
  const shortJump =
    troll === "jumpCut" || troll === "gravity" || troll === "shrink" || troll === "tiny" || troll === "risingLava";

  for (let s = 0; s < segments && x < cols - 7; s++) {
    const gap = expert ? (s === 0 || shortJump ? 3 : 3 + ((R() * 2) | 0)) : 2 + ((R() * 2) | 0);
    const crumAll = !expert && troll === "crumble" && s % 2 === 1;
    const width = crumAll ? 3 : expert ? 3 + ((R() * 2) | 0) : 4 + ((R() * 3) | 0);
    const stepUp = expert ? ((R() * 2) | 0) : world >= 6 && R() > 0.7 ? 1 : 0;
    const floorY = rows - 2 - Math.min(2, stepUp);
    const pitKind: Tile = expert && R() > 0.45 ? T.SPIKE_U : T.LAVA;
    g.rect(x, rows - 2, gap, 1, pitKind);
    x += gap;
    const type: Tile = crumAll
      ? T.CRUMBLE
      : troll === "iceBoost"
        ? T.ICE
        : family === 4 && s % 2
          ? T.ONE_WAY
          : T.SOLID;
    g.rect(x, floorY, width, 1, type);
    if (type === T.SOLID && floorY < rows - 2) g.rect(x, floorY + 1, width, rows - 2 - floorY, T.SOLID);
    if (type === T.CRUMBLE) {
      for (let i = 0; i < width; i++) trapUnder(g, x + i, floorY);
    }
    if (expert && type === T.SOLID && width >= 3 && s % 2 === 1) {
      g.set(x + 1, floorY, T.CRUMBLE);
      trapUnder(g, x + 1, floorY);
    }
    plats.push({ x, y: floorY, w: width });
    if (R() > 0.8 && floorY < rows - 4) g.set(x + 1, floorY - 1, T.COIN);
    x += width;
  }

  if (x < cols - 2) g.rect(x, rows - 2, cols - 2 - x, 1, T.SOLID);

  if (family === 1 && world >= 8) {
    let sy = rows - 3;
    let sx = 8;
    for (let i = 0; i < (expert ? 6 : 4); i++) {
      g.rect(sx, sy, 2, 1, T.SOLID);
      sx += 3;
      sy -= 1;
      if (sy < 6) break;
    }
  }
  if (family === 5 && world >= 5) {
    g.rect(10, 4, Math.min(8, cols - 16), 1, T.ONE_WAY);
  }
  if (family === 6 && !expert) {
    g.rect(6, rows - 2, Math.min(8, cols - 12), 1, T.CONV_R);
  }

  const goal = { x: cols - 3, y: rows - 3 };
  g.set(goal.x, rows - 2, T.SOLID);
  g.set(goal.x - 1, rows - 2, T.SOLID);
  g.set(goal.x, goal.y, T.GOAL);

  for (const tr of trolls) applyTrollTiles(g, tr, R, spawn.x, goal.x);

  g.set(spawn.x, rows - 2, T.SOLID);
  g.set(spawn.x + 1, rows - 2, T.SOLID);
  g.set(goal.x, rows - 2, T.SOLID);
  ensureWalk(g, spawn.x, goal.x, expert ? 4 : 3);

  if (world === 11 && room % 2 === 0) {
    g.set(goal.x - 4, goal.y, T.FAKE_GOAL);
    g.rect(goal.x - 5, goal.y + 1, 3, 1, T.SOLID);
  }

  const moving: MovingPlat[] = [];
  if (world === 12 || (expert && room % 3 === 1) || (world >= 17 && room % 3 === 1)) {
    const mx = 8 + room;
    const my = rows - 5;
    moving.push({
      x: mx * 32,
      y: my * 32,
      w: 3 * 32,
      h: 12,
      x0: mx * 32,
      x1: (mx + 6) * 32,
      y0: my * 32,
      y1: my * 32,
      period: expert ? 2.6 : 3.2,
      t: 0,
      carry: true,
    });
    g.rect(mx, rows - 2, 4, 1, T.SPIKE_U);
  }

  g.set(spawn.x, rows - 2, T.SOLID);
  g.set(goal.x, rows - 2, T.SOLID);
  ensureWalk(g, spawn.x, goal.x, expert ? 4 : 3);

  const signs: Sign[] = [];
  if (troll === "lyingSign" || troll === "vanishFloor" || world === 8 || (expert && room === 0)) {
    const lies = [
      { ar: "الباب على اليسار", en: "The door is to the left" },
      { ar: "لا تقفز هنا", en: "Do not jump here" },
      { ar: "المنصة العليا هي الطريق", en: "The upper shelf is the way" },
      { ar: "الأرض ثابتة", en: "The floor is stable" },
      { ar: "اعكس الاتجاه", en: "Reverse direction" },
    ];
    const lie = lies[(world + room) % lies.length]!;
    signs.push({ x: spawn.x + 4, y: spawn.y - 2, ...lie });
  }

  void plats;
  return finish(g, world, room, trolls, spawn, goal, signs, moving);
}

function ensureWalk(g: Grid, spawnX: number, goalX: number, maxPit: number) {
  const gy = g.rows - 2;
  const walkable = (t: Tile) =>
    t === T.SOLID ||
    t === T.CRUMBLE ||
    t === T.ICE ||
    t === T.CONV_L ||
    t === T.CONV_R ||
    t === T.ONE_WAY ||
    t === T.SPRING ||
    t === T.BOUNCE ||
    t === T.SPIKE_POP;
  let run = 0;
  const x0 = 1;
  const x1 = g.cols - 2;
  for (let x = x0; x <= x1; x++) {
    if (walkable(g.get(x, gy))) run = 0;
    else {
      run++;
      if (run > maxPit) {
        g.set(x, gy, T.SOLID);
        run = 0;
      }
    }
  }
  void spawnX;
  void goalX;
}

export function getLevel(world: number, room: number): LevelSpec {
  const w = Math.max(0, Math.min(19, world | 0));
  const r = Math.max(0, Math.min(9, room | 0));
  if (w === 0) {
    return parseAscii(TUTORIAL[r]!, 0, r, trollsFor(0, r), TUTORIAL_SIGNS[r]);
  }
  if (w === 1 && r === 3) {
    return parseAscii(DUST_ROOM4, 1, 3, ["vanishFloor"], [
      { x: 12, y: 4, ar: "المنصة العليا هي الطريق.", en: "The upper shelf is the way." },
    ]);
  }
  if (w === 4 && r === 0) {
    return parseAscii(PHANTOM_ROOM0, 4, 0, ["falseFloor", "vanishFloor"], [
      { x: 11, y: 6, ar: "المنصة العليا طريق مختصر.", en: "The upper shelf is a shortcut." },
    ]);
  }
  return generate(w, r);
}

export function tileSolid(t: Tile, falling: boolean, fromAbove: boolean, reveal = false): boolean {
  switch (t) {
    case T.SOLID:
    case T.CRUMBLE:
    case T.ICE:
    case T.BOUNCE:
    case T.SPRING:
    case T.CONV_L:
    case T.CONV_R:
    case T.VANISH:
    case T.DOOR:
    case T.SPIKE_POP:
      return true;
    case T.INVIS:
      return true;
    case T.ONE_WAY:
      return falling && fromAbove;
    case T.FAKE_SOLID:
      return false;
    default:
      return false;
  }
  void reveal;
}

export function looksSolid(t: Tile, hint: boolean): boolean {
  if (t === T.FAKE_SOLID) return !hint;
  if (t === T.INVIS) return hint;
  if (t === T.FAKE_GOAL || t === T.GOAL) return false;
  if (
    t === T.SPIKE_U ||
    t === T.SPIKE_D ||
    t === T.SPIKE_L ||
    t === T.SPIKE_R ||
    t === T.HIDDEN_SPIKE ||
    t === T.LAVA
  ) {
    return false;
  }
  return tileSolid(t, true, true);
}

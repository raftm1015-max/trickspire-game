export type Actions = {
  moveX: number;
  jump: boolean;
  jumpHeld: boolean;
  down: boolean;
};

export type PadAction = "left" | "right" | "jump" | "down";

const GAME_KEYS = new Set([
  "KeyA",
  "KeyD",
  "KeyW",
  "KeyS",
  "ArrowLeft",
  "ArrowRight",
  "ArrowUp",
  "ArrowDown",
  "Space",
  "KeyK",
  "KeyP",
  "Escape",
]);

export class Input {
  private keys = new Set<string>();
  private injected: string[] | null = null;
  private prevJump = false;
  private ptr = {
    left: new Set<number>(),
    right: new Set<number>(),
    jump: new Set<number>(),
    down: new Set<number>(),
  };
  pauseQueued = false;

  attach(el: HTMLElement) {
    const down = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (GAME_KEYS.has(e.code)) e.preventDefault();
      if (e.code === "Escape" || e.code === "KeyP") this.pauseQueued = true;
    };
    const up = (e: KeyboardEvent) => this.keys.delete(e.code);
    const clear = () => this.keys.clear();
    const ptrUp = (e: PointerEvent) => this.pointerUpAll(e.pointerId);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);
    window.addEventListener("pointerup", ptrUp);
    window.addEventListener("pointercancel", ptrUp);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        clear();
        this.clearPointers();
      }
    });
    el.addEventListener(
      "contextmenu",
      (e) => {
        e.preventDefault();
      },
      { passive: false },
    );
    this._cleanup = () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
      window.removeEventListener("pointerup", ptrUp);
      window.removeEventListener("pointercancel", ptrUp);
    };
  }

  private _cleanup: (() => void) | null = null;

  detach() {
    this._cleanup?.();
    this._cleanup = null;
    this.clearPointers();
  }

  pointerDown(action: PadAction, id: number) {
    this.ptr[action].add(id);
  }

  pointerUp(action: PadAction, id: number) {
    this.ptr[action].delete(id);
  }

  pointerUpAll(id: number) {
    this.ptr.left.delete(id);
    this.ptr.right.delete(id);
    this.ptr.jump.delete(id);
    this.ptr.down.delete(id);
  }

  clearPointers() {
    this.ptr.left.clear();
    this.ptr.right.clear();
    this.ptr.jump.clear();
    this.ptr.down.clear();
  }

  setKeys(codes: string[]) {
    this.injected = codes.length ? codes : null;
  }

  sample(reverse: boolean, swapLR: boolean): Actions & { jumpPressed: boolean } {
    const has = (c: string) =>
      this.injected ? this.injected.includes(c) : this.keys.has(c);
    let left = has("KeyA") || has("ArrowLeft") || this.ptr.left.size > 0;
    let right = has("KeyD") || has("ArrowRight") || this.ptr.right.size > 0;
    if (swapLR) [left, right] = [right, left];
    if (reverse) [left, right] = [right, left];
    let moveX = 0;
    if (left) moveX -= 1;
    if (right) moveX += 1;
    let padJump = false;
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (!pad) continue;
      const ax = pad.axes[0] ?? 0;
      if (Math.abs(ax) > 0.25) moveX = Math.sign(ax) * (reverse || swapLR ? -1 : 1);
      if (pad.buttons[14]?.pressed) moveX = reverse || swapLR ? 1 : -1;
      if (pad.buttons[15]?.pressed) moveX = reverse || swapLR ? -1 : 1;
      if (pad.buttons[0]?.pressed || pad.buttons[1]?.pressed) padJump = true;
      if (pad.buttons[9]?.pressed) this.pauseQueued = true;
    }
    const jumpHeld =
      has("Space") || has("KeyW") || has("ArrowUp") || has("KeyK") || this.ptr.jump.size > 0 || padJump;
    const jumpPressed = jumpHeld && !this.prevJump;
    this.prevJump = jumpHeld;
    const down = has("KeyS") || has("ArrowDown") || this.ptr.down.size > 0;
    return { moveX, jump: jumpPressed, jumpHeld, jumpPressed, down };
  }
}

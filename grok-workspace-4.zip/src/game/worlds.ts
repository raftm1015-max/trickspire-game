import { WORLDS_META } from "./copy";
import type { WorldInfo } from "./types";

const PALETTES: Array<Pick<WorldInfo, "sky" | "solid" | "solidHi" | "accent" | "fog">> = [
  { sky: ["#16121c", "#2a2434"], solid: "#3a3344", solidHi: "#524a5c", accent: "#c4b8a8", fog: "rgba(12,10,14,0.35)" },
  { sky: ["#1c1610", "#3a2a1c"], solid: "#5a4636", solidHi: "#7a6250", accent: "#d4b496", fog: "rgba(28,20,12,0.4)" },
  { sky: ["#140c12", "#2c1420"], solid: "#4a3038", solidHi: "#6a4850", accent: "#d08080", fog: "rgba(20,8,12,0.4)" },
  { sky: ["#10141c", "#1c2838"], solid: "#344056", solidHi: "#4c5c74", accent: "#a8c4d4", fog: "rgba(8,12,20,0.4)" },
  { sky: ["#101018", "#201c2c"], solid: "#38344c", solidHi: "#504868", accent: "#b8a8d0", fog: "rgba(10,8,18,0.5)" },
  { sky: ["#0c1414", "#183030"], solid: "#2c4844", solidHi: "#3c645c", accent: "#80c4b0", fog: "rgba(6,16,16,0.4)" },
  { sky: ["#1c100c", "#3c2414"], solid: "#5c3c28", solidHi: "#7c5840", accent: "#e0a070", fog: "rgba(24,12,8,0.4)" },
  { sky: ["#141018", "#2c2030"], solid: "#443850", solidHi: "#5c4c68", accent: "#d8b0c8", fog: "rgba(16,10,18,0.4)" },
  { sky: ["#12100c", "#2c281c"], solid: "#4a4434", solidHi: "#68604c", accent: "#c8c094", fog: "rgba(14,12,8,0.4)" },
  { sky: ["#140c18", "#301428"], solid: "#4c2844", solidHi: "#6c4060", accent: "#e090b0", fog: "rgba(18,8,16,0.4)" },
  { sky: ["#08080c", "#101018"], solid: "#242430", solidHi: "#383848", accent: "#888898", fog: "rgba(4,4,8,0.55)" },
  { sky: ["#180c0c", "#301818"], solid: "#4c3030", solidHi: "#6c4848", accent: "#e0a0a0", fog: "rgba(20,8,8,0.4)" },
  { sky: ["#0c141c", "#183040"], solid: "#2c4458", solidHi: "#3c5c74", accent: "#90c0d8", fog: "rgba(6,14,20,0.4)" },
  { sky: ["#100c1c", "#241838"], solid: "#3c3060", solidHi: "#544878", accent: "#b8a0e0", fog: "rgba(10,8,22,0.45)" },
  { sky: ["#0c1814", "#1c3830"], solid: "#2c5448", solidHi: "#3c7060", accent: "#90d8b8", fog: "rgba(6,18,14,0.4)" },
  { sky: ["#1c1408", "#3c2c10"], solid: "#5c4820", solidHi: "#7c6430", accent: "#e0c060", fog: "rgba(22,16,6,0.4)" },
  { sky: ["#14181c", "#2c343c"], solid: "#485058", solidHi: "#687078", accent: "#d0d8e0", fog: "rgba(12,14,16,0.45)" },
  { sky: ["#180c14", "#341828"], solid: "#503044", solidHi: "#704860", accent: "#e0a0c0", fog: "rgba(18,8,14,0.4)" },
  { sky: ["#0c0c10", "#1c1828"], solid: "#343044", solidHi: "#4c4860", accent: "#c0b8d0", fog: "rgba(8,8,12,0.5)" },
  { sky: ["#100808", "#280c10"], solid: "#441820", solidHi: "#642830", accent: "#e07070", fog: "rgba(16,4,6,0.5)" },
];

export const WORLDS_INFO: WorldInfo[] = WORLDS_META.map((m, i) => ({
  id: i,
  nameAr: m.nameAr,
  nameEn: m.nameEn,
  tagAr: m.tagAr,
  tagEn: m.tagEn,
  ...PALETTES[i]!,
}));

import { Input } from "./input";
import { getLevel, tileSolid } from "./levels";
import { drawWorld, loadSprites, type Particle, type Sprites } from "./render";
import { sfx } from "./audio";
import {
  FIXED_DT,
  TILE,
  T,
  VIEW_H,
  VIEW_W,
  type GameHooks,
  type LevelSpec,
  type Tile,
} from "./types";

const MOVE_ACCEL = 2100;
const MOVE_MAX = 230;
const AIR_ACCEL = 1500;
const FRICTION = 1900;
const ICE_FRICTION = 240;
const GRAV_UP = 1250;
const GRAV_DOWN = 2500;
const JUMP_V = -560;
const COYOTE = 0.1;
const BUFFER = 0.12;
const TERMINAL = 640;
const PLAYER_W = 14;
const PLAYER_H = 20;

type Anim = "idle" | "run" | "jump" | "hurt";

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  facing: number;
  grounded: boolean;
  coyote: number;
  buffer: number;
  scale: number;
  dead: boolean;
  squish: number;
  anim: Anim;
  frame: number;
  frameT: number;
  flash: number;
  jumps: number;
  onIce: boolean;
  riding: number;
}

export class TrickspireGame {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  input = new Input();
  hooks: GameHooks;
  level!: LevelSpec;
  player!: Player;
  sprites: Sprites;
  camX = 0;
  camY = 0;
  acc = 0;
  last = 0;
  raf = 0;
  running = false;
  paused = false;
  souls = 10;
  coins = 0;
  roomCoins = 0;
  deaths = 0;
  world = 0;
  room = 0;
  particles: Particle[] = [];
  trauma = 0;
  time = 0;
  crumble = new Map<number, number>();
  popped = new Set<number>();
  popWait = new Map<number, number>();
  vanished = false;
  lavaY = 0;
  doorOpen = false;
  hintT = 0;
  lieWinT = 0;
  shakeOn = true;
  lang: "ar" | "en" = "en";
  teleCool = 0;
  signAr: string | null = null;
  signEn: string | null = null;
  hudT = 0;
  freezeT = 0;
  crumbleSfxAt = -1;
  tileBackup = new Uint8Array(0);
  goalBackup = { x: 0, y: 0 };
  respawnT = 0;

  constructor(canvas: HTMLCanvasElement, hooks: GameHooks) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("No 2d context");
    this.ctx = ctx;
    this.hooks = hooks;
    this.sprites = loadSprites();
    this.input.attach(canvas);
    this.fit();
    window.addEventListener("resize", this.fit);
    this.wireControlsTest();
  }

  fit = () => {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.canvas.width = VIEW_W * dpr;
    this.canvas.height = VIEW_H * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  start(world: number, room: number, souls: number, coins: number) {
    this.world = world;
    this.room = room;
    this.souls = souls;
    this.coins = coins;
    this.roomCoins = 0;
    this.level = getLevel(world, room);
    this.tileBackup = new Uint8Array(this.level.tiles);
    this.goalBackup = { ...this.level.goal };
    this.resetHazards();
    this.respawnT = 0;
    this.spawnAt(this.level.spawn.x, this.level.spawn.y, true);
    this.camX = this.player.x + this.player.w / 2 - VIEW_W / 2;
    this.camY = this.player.y + this.player.h / 2 - VIEW_H / 2;
    this.freezeT = 0;
    this.particles = [];
    this.running = true;
    this.paused = false;
    this.last = performance.now();
    this.acc = 0;
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.loop);
    this.emitHud();
  }

  spawnAt(tx: number, ty: number, resetVel: boolean) {
    const scale = this.level.shrink ? 0.58 : 1;
    const below = this.level.tiles[(ty + 1) * this.level.cols + tx];
    const onFloor = tileSolid(below as Tile, true, true);
    this.player = {
      x: tx * TILE + (TILE - PLAYER_W * scale) / 2,
      y: ty * TILE + TILE - PLAYER_H * scale - 1,
      vx: resetVel ? 0 : this.player?.vx ?? 0,
      vy: 0,
      w: PLAYER_W * scale,
      h: PLAYER_H * scale,
      facing: 1,
      grounded: onFloor,
      coyote: onFloor ? COYOTE : 0,
      buffer: 0,
      scale,
      dead: false,
      squish: 0,
      anim: "idle",
      frame: 0,
      frameT: 0,
      flash: 0,
      jumps: 0,
      onIce: false,
      riding: -1,
    };
  }

  resetHazards() {
    if (this.tileBackup.length === this.level.tiles.length) this.level.tiles.set(this.tileBackup);
    this.level.goal = { ...this.goalBackup };
    this.crumble.clear();
    this.popped.clear();
    this.popWait.clear();
    this.vanished = false;
    this.doorOpen = false;
    this.lieWinT = 0;
    this.lavaY = this.level.rows * TILE;
    this.time = 0;
    this.trauma = 0;
  }

  revealHiddenUnder(id: number) {
    const below = id + this.level.cols;
    if (below < this.level.tiles.length && this.level.tiles[below] === T.HIDDEN_SPIKE) {
      this.level.tiles[below] = T.SPIKE_U;
    }
  }

  /** True when a still-solid floor is sitting on this cell — nails/lava stay inert and invisible. */
  coveredByFloor(id: number): boolean {
    const above = id - this.level.cols;
    if (above < 0) return false;
    if (this.crumble.get(above) === -1) return false;
    let t = this.level.tiles[above] as Tile;
    if (this.vanished && t === T.VANISH) return false;
    return tileSolid(t, true, true);
  }

  setPaused(v: boolean) {
    this.paused = v;
  }

  setHint(seconds: number) {
    this.hintT = seconds;
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.input.detach();
    window.removeEventListener("resize", this.fit);
    if (window.__controlsTest) delete window.__controlsTest;
  }

  loop = (now: number) => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.1) dt = 0.1;
    if (this.paused) {
      this.draw();
      return;
    }
    this.acc += dt;
    while (this.acc >= FIXED_DT) {
      this.step(FIXED_DT);
      this.acc -= FIXED_DT;
    }
    this.draw();
  };

  step(dt: number) {
    this.time += dt;
    if (this.player.dead) {
      this.respawnT -= dt;
      if (this.respawnT <= 0 && this.souls > 0) {
        this.resetHazards();
        this.spawnAt(this.level.spawn.x, this.level.spawn.y, true);
        this.player.flash = 0.8;
        this.emitHud();
      }
      return;
    }
    if (this.freezeT > 0) {
      this.freezeT -= dt;
      return;
    }
    if (this.lieWinT > 0) {
      this.lieWinT -= dt;
      if (this.lieWinT <= 0) this.kill();
      return;
    }
    if (this.player.dead) return;

    if (this.input.pauseQueued) {
      this.input.pauseQueued = false;
      this.hooks.onHud({ ...this.hudSnap(), paused: true });
    }

    const act = this.input.sample(this.level.reverse, this.level.swapLR);
    const p = this.player;
    p.buffer = Math.max(0, p.buffer - dt);
    p.coyote = Math.max(0, p.coyote - dt);
    p.flash = Math.max(0, p.flash - dt);
    p.squish = Math.max(0, p.squish - dt * 4);
    this.teleCool = Math.max(0, this.teleCool - dt);
    this.hintT = Math.max(0, this.hintT - dt);
    this.trauma = Math.max(0, this.trauma - dt * 1.8);

    const accel = p.grounded ? MOVE_ACCEL : AIR_ACCEL;
    if (act.moveX !== 0) {
      p.vx += act.moveX * accel * dt;
      p.facing = act.moveX > 0 ? 1 : -1;
    } else {
      const fr = p.onIce ? ICE_FRICTION : FRICTION;
      const max = fr * dt;
      if (Math.abs(p.vx) <= max) p.vx = 0;
      else p.vx -= Math.sign(p.vx) * max;
    }
    const cap = p.onIce ? MOVE_MAX * 1.35 : MOVE_MAX;
    if (p.vx > cap) p.vx = cap;
    if (p.vx < -cap) p.vx = -cap;

    if (this.level.wind) p.vx += this.level.wind * dt * 0.35;

    const gravSign = this.level.gravitySign * (this.level.trolls.includes("gravity") && Math.sin(this.time * 0.7) > 0.65 ? -1 : 1);
    const g = (p.vy * gravSign < 0 ? GRAV_UP : GRAV_DOWN) * gravSign;
    p.vy += g * dt;
    if (gravSign > 0 && p.vy > TERMINAL) p.vy = TERMINAL;
    if (gravSign < 0 && p.vy < -TERMINAL) p.vy = -TERMINAL;

    const canJump = !this.level.lockedJump || this.time > 1.4;
    const jumpV = this.level.jumpCut && p.jumps >= 1 ? JUMP_V * 0.55 : JUMP_V;
    if (act.jump || (act.jumpHeld && p.grounded)) p.buffer = BUFFER;
    if (p.buffer > 0 && (p.grounded || p.coyote > 0) && canJump) {
      p.vy = gravSign > 0 ? jumpV : -jumpV;
      p.grounded = false;
      p.coyote = 0;
      p.buffer = 0;
      p.jumps++;
      p.squish = -0.4;
      sfx.jump();
    }

    this.movePlatforms(dt);
    this.moveAxis(p, p.vx * dt, 0);
    const wasGround = p.grounded;
    p.grounded = false;
    p.onIce = false;
    this.moveAxis(p, 0, p.vy * dt);
    if (p.grounded && !wasGround) {
      p.squish = 0.45;
      sfx.land();
      this.burst(p.x + p.w / 2, p.y + p.h, 6, "#c4b8a8");
    }
    if (p.grounded) p.coyote = COYOTE;

    this.touchTiles(dt);
    this.anim(dt, act.moveX);

    if (this.level.risingLava) {
      const start = this.level.rows * TILE - 8;
      const delay = this.world >= 10 ? 2.4 : 1.0;
      const spd = 16 + this.room + (this.world >= 10 ? 6 : 0);
      this.lavaY = start - Math.max(0, this.time - delay) * spd;
      if (p.y + p.h > this.lavaY + 4) this.kill();
    }

    if (this.level.goalRuns) {
      const gx = this.level.goal.x * TILE;
      if (Math.abs(p.x - gx) < 90 && this.level.goal.x < this.level.cols - 3) {
        this.level.goal.x += dt * 1.6;
      }
    }

    this.camera(dt);
    this.tickParticles(dt);
    this.hudT += dt;
    if (this.hudT > 0.12) {
      this.hudT = 0;
      this.emitHud();
    }

    if (p.y > this.level.rows * TILE + 40 || p.y < -80) this.kill();
  }

  movePlatforms(dt: number) {
    for (const m of this.level.moving) {
      m.t += dt;
      const u = (1 - Math.cos((m.t / m.period) * Math.PI * 2)) / 2;
      const nx = m.x0 + (m.x1 - m.x0) * u;
      const ny = m.y0 + (m.y1 - m.y0) * u;
      const dx = nx - m.x;
      const dy = ny - m.y;
      m.x = nx;
      m.y = ny;
      const p = this.player;
      if (p.riding >= 0) {
        p.x += dx;
        p.y += dy;
      }
    }
  }

  moveAxis(p: Player, dx: number, dy: number) {
    p.x += dx;
    p.y += dy;
    p.riding = -1;
    const x0 = Math.floor(p.x / TILE);
    const y0 = Math.floor(p.y / TILE);
    const x1 = Math.floor((p.x + p.w - 0.001) / TILE);
    const y1 = Math.floor((p.y + p.h - 0.001) / TILE);
    const falling = dy > 0;
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (tx < 0 || ty < 0 || tx >= this.level.cols || ty >= this.level.rows) {
          if (dx > 0) p.x = tx * TILE - p.w;
          if (dx < 0) p.x = (tx + 1) * TILE;
          if (dy > 0) {
            p.y = ty * TILE - p.h;
            p.vy = 0;
            p.grounded = true;
          }
          if (dy < 0) {
            p.y = (ty + 1) * TILE;
            p.vy = 0;
          }
          if (dx !== 0) p.vx = 0;
          continue;
        }
        const id = ty * this.level.cols + tx;
        let tile = this.level.tiles[id] as Tile;
        if (this.vanished && tile === T.VANISH) {
          continue;
        }
        if (this.crumble.get(id) === -1) continue;
        if (tile === T.DOOR && this.doorOpen) continue;
        const top = ty * TILE;
        const fromAbove = p.y + p.h - dy <= top + 2;
        if (!tileSolid(tile, falling, fromAbove)) continue;
        const left = tx * TILE;
        const right = left + TILE;
        const bottom = top + TILE;
        if (dx > 0 && p.x + p.w > left && p.x < left) {
          p.x = left - p.w;
          p.vx = 0;
        } else if (dx < 0 && p.x < right && p.x + p.w > right) {
          p.x = right;
          p.vx = 0;
        }
        if (dy > 0 && p.y + p.h > top && p.y < top) {
          p.y = top - p.h;
          p.vy = 0;
          p.grounded = true;
          if (tile === T.ICE || tile === T.CONV_L || tile === T.CONV_R) p.onIce = true;
          if (tile === T.CONV_R) p.vx += 18;
          if (tile === T.CONV_L) p.vx -= 18;
          if (tile === T.SPRING || tile === T.BOUNCE) {
            p.vy = JUMP_V * 1.25;
            p.grounded = false;
          }
          if (tile === T.CRUMBLE || tile === T.VANISH) {
            if (!this.crumble.has(id)) this.crumble.set(id, 0.7);
          }
        } else if (dy < 0 && p.y < bottom && p.y + p.h > bottom) {
          p.y = bottom;
          p.vy = 0;
        }
      }
    }
    for (let i = 0; i < this.level.moving.length; i++) {
      const m = this.level.moving[i]!;
      if (dy > 0 && aabb(p.x, p.y, p.w, p.h, m.x, m.y, m.w, m.h) && p.y + p.h - dy <= m.y + 6) {
        p.y = m.y - p.h;
        p.vy = 0;
        p.grounded = true;
        p.riding = i;
      }
    }
  }

  touchTiles(dt: number) {
    const p = this.player;
    const x0 = Math.floor(p.x / TILE);
    const y0 = Math.floor(p.y / TILE);
    const x1 = Math.floor((p.x + p.w - 0.001) / TILE);
    const y1 = Math.floor((p.y + p.h - 0.001) / TILE);
    this.signAr = null;
    this.signEn = null;
    for (const s of this.level.signs) {
      if (Math.abs(s.x * TILE - p.x) < 64 && Math.abs(s.y * TILE - p.y) < 64) {
        this.signAr = s.ar;
        this.signEn = s.en;
      }
    }
    for (const [id, t] of [...this.crumble]) {
      const nt = t - dt;
      if (nt <= 0) {
        this.level.tiles[id] = T.EMPTY;
        this.crumble.set(id, -1);
        this.revealHiddenUnder(id);
        if (this.time - this.crumbleSfxAt > 0.2) {
          sfx.crumble();
          this.crumbleSfxAt = this.time;
        }
      } else this.crumble.set(id, nt);
    }
    for (const [id, t] of [...this.popWait]) {
      const nt = t - dt;
      if (nt <= 0) {
        this.level.tiles[id] = T.SPIKE_U;
        this.popWait.delete(id);
        sfx.pop();
      } else this.popWait.set(id, nt);
    }
    for (let ty = y0 - 1; ty <= y1 + 1; ty++) {
      for (let tx = x0 - 1; tx <= x1 + 1; tx++) {
        if (tx < 0 || ty < 0 || tx >= this.level.cols || ty >= this.level.rows) continue;
        const id = ty * this.level.cols + tx;
        const tile = this.level.tiles[id] as Tile;
        const left = tx * TILE;
        const top = ty * TILE;
        if (
          tile === T.SPIKE_POP &&
          p.grounded &&
          aabb(p.x + 2, p.y + p.h - 8, p.w - 4, 10, left, top, TILE, TILE)
        ) {
          if (!this.popWait.has(id)) this.popWait.set(id, 0.12);
        }
        if (!aabb(p.x + 2, p.y + 2, p.w - 4, p.h - 4, left, top, TILE, TILE)) continue;
        if (tile === T.HIDDEN_SPIKE) {
          if (this.coveredByFloor(id)) continue;
          this.level.tiles[id] = T.SPIKE_U;
          this.kill();
          return;
        }
        if (tile === T.SPIKE_U || tile === T.SPIKE_D || tile === T.SPIKE_L || tile === T.SPIKE_R || tile === T.LAVA) {
          if (this.coveredByFloor(id)) continue;
          this.kill();
          return;
        }
        if (tile === T.FAKE_CHECK) {
          this.kill();
          return;
        }
        if (tile === T.GOAL) {
          this.winRoom();
          return;
        }
        if (tile === T.FAKE_GOAL) {
          if (this.level.fakeWin) {
            this.lieWinT = 0.9;
            this.trauma = 0.2;
          } else this.kill();
          return;
        }
        if (tile === T.CHECK) continue;
        if (tile === T.COIN) {
          this.level.tiles[id] = T.EMPTY;
          this.roomCoins += 1;
          this.coins += 1;
          sfx.coin();
          this.hooks.onCoin(this.coins);
        }
        if (tile === T.BUTTON) this.doorOpen = true;
        if ((tile === T.TELE_A || tile === T.TELE_B) && this.teleCool <= 0) {
          const want = tile === T.TELE_A ? T.TELE_B : T.TELE_A;
          for (let i = 0; i < this.level.tiles.length; i++) {
            if (this.level.tiles[i] === want && i !== id) {
              const nx = i % this.level.cols;
              const ny = (i / this.level.cols) | 0;
              p.x = nx * TILE + 8;
              p.y = ny * TILE - p.h;
              this.teleCool = 0.6;
              this.trauma = 0.3;
              break;
            }
          }
        }
      }
    }
  }

  anim(dt: number, moveX: number) {
    const p = this.player;
    let next: Anim = "idle";
    if (p.flash > 0.05) next = "hurt";
    else if (!p.grounded) next = "jump";
    else if (Math.abs(p.vx) > 20 || moveX !== 0) next = "run";
    if (next !== p.anim) {
      p.anim = next;
      p.frame = 0;
      p.frameT = 0;
    }
    p.frameT += dt;
    const sp = p.anim === "run" ? 0.09 : p.anim === "jump" ? 0.12 : 0.18;
    if (p.frameT > sp) {
      p.frameT = 0;
      p.frame = (p.frame + 1) % 4;
      if (p.anim === "run" && p.grounded && p.frame % 2 === 0) sfx.step();
      if (p.anim === "jump") {
        p.frame = p.vy < -80 ? 1 : p.vy < 80 ? 2 : 3;
      }
    }
  }

  camera(dt: number) {
    const p = this.player;
    const look = p.facing * 70;
    const tx = p.x + p.w / 2 - VIEW_W / 2 + look;
    const ty = p.y + p.h / 2 - VIEW_H / 2 - 20;
    const k = 1 - Math.exp(-6 * dt);
    this.camX += (tx - this.camX) * k;
    this.camY += (ty - this.camY) * k;
    const maxX = Math.max(0, this.level.cols * TILE - VIEW_W);
    const maxY = Math.max(0, this.level.rows * TILE - VIEW_H);
    this.camX = Math.max(0, Math.min(maxX, this.camX));
    this.camY = Math.max(0, Math.min(maxY, this.camY));
  }

  kill() {
    if (this.player.dead) return;
    this.player.dead = true;
    this.player.anim = "hurt";
    this.souls = Math.max(0, this.souls - 1);
    this.deaths++;
    this.trauma = 0.5;
    this.freezeT = 0;
    this.respawnT = 0.42;
    sfx.death();
    this.burst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 16, "#b4233a");
    this.hooks.onDeath(this.souls);
    this.resetHazards();
    if (this.souls <= 0) {
      this.hooks.onWorldFail();
      return;
    }
  }

  winRoom() {
    if (this.player.dead) return;
    this.player.dead = true;
    sfx.goal();
    this.burst(this.player.x, this.player.y, 14, "#e8e0d4");
    const gained = 3 + this.roomCoins + (this.deaths === 0 ? 2 : 0);
    this.coins += 3;
    this.hooks.onRoomClear(gained);
  }

  burst(x: number, y: number, n: number, color: string) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 40 + Math.random() * 120;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.35 + Math.random() * 0.3,
        max: 0.6,
        size: 2 + Math.random() * 3,
        color,
      });
    }
  }

  tickParticles(dt: number) {
    for (const p of this.particles) {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 400 * dt;
      p.life -= dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);
  }

  draw() {
    const shake = this.shakeOn
      ? {
          x: (Math.random() * 2 - 1) * this.trauma * this.trauma * 10,
          y: (Math.random() * 2 - 1) * this.trauma * this.trauma * 8,
        }
      : { x: 0, y: 0 };
    drawWorld(
      this.ctx,
      this.level,
      this.camX,
      this.camY,
      this.time,
      this.hintT > 0,
      this.doorOpen,
      this.lavaY,
      this.particles,
      this.player,
      this.sprites,
      shake,
      this.level.cameraFlip,
      this.level.mirrorCam,
      this.level.darkness,
    );
    if (this.lieWinT > 0) {
      this.ctx.fillStyle = "rgba(10,9,12,0.55)";
      this.ctx.fillRect(0, 0, VIEW_W, VIEW_H);
      this.ctx.fillStyle = "#f0ebe3";
      this.ctx.font = "700 42px Syne, sans-serif";
      this.ctx.textAlign = "center";
      this.ctx.fillText(this.lang === "ar" ? "فزت" : "YOU WIN", VIEW_W / 2, VIEW_H / 2);
    }
  }

  hudSnap() {
    return {
      souls: this.souls,
      coins: this.coins,
      world: this.world,
      room: this.room,
      signAr: this.signAr,
      signEn: this.signEn,
      deaths: this.deaths,
      paused: this.paused,
    };
  }

  emitHud() {
    this.hooks.onHud(this.hudSnap());
  }

  wireControlsTest() {
    window.__controlsTest = {
      getYaw: () => -this.player.x,
      getSpeed: () => Math.hypot(this.player.vx, this.player.vy),
      setKeys: (codes: string[]) => this.input.setKeys(codes),
      setSteer: (v: number) => {
        if (v > 0.2) this.input.setKeys(["KeyA"]);
        else if (v < -0.2) this.input.setKeys(["KeyD"]);
        else this.input.setKeys([]);
      },
    };
  }
}

function aabb(ax: number, ay: number, aw: number, ah: number, bx: number, by: number, bw: number, bh: number) {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}

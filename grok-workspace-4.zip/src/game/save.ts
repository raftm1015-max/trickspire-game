import { MAX_SOULS, ROOMS, WORLDS } from "./types";

export const SAVE_VERSION = 4;
const KEY = "trickspire-save-v1";
const BACKUP = "trickspire-save-bak";
const SALT = "trickspire.wick.v3";

export interface SaveData {
  version: number;
  unlockedWorld: number;
  bestRoom: number[];
  souls: number;
  coins: number;
  adsRemoved: boolean;
  currentWorld: number;
  currentRoom: number;
  inRun: boolean;
  deaths: number;
  roomsCleared: number;
  settings: {
    sfx: number;
    music: number;
    shake: boolean;
    lang: "ar" | "en";
  };
}

export const defaultSave = (): SaveData => ({
  version: SAVE_VERSION,
  unlockedWorld: 0,
  bestRoom: Array.from({ length: WORLDS }, () => 0),
  souls: MAX_SOULS,
  coins: 0,
  adsRemoved: false,
  currentWorld: 0,
  currentRoom: 0,
  inRun: false,
  deaths: 0,
  roomsCleared: 0,
  settings: { sfx: 0.8, music: 0.55, shake: true, lang: "en" },
});

function fnv(text: string): string {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}

function seal(data: SaveData): string {
  const payload = JSON.stringify(data);
  return JSON.stringify({ p: payload, h: fnv(SALT + payload) });
}

function clampSave(raw: SaveData): SaveData {
  const d = defaultSave();
  const lang = raw.version < 4 ? "en" : raw.settings?.lang === "ar" ? "ar" : "en";
  const n = (v: unknown, min: number, max: number, fallback: number) => {
    const x = typeof v === "number" && Number.isFinite(v) ? v : fallback;
    return Math.max(min, Math.min(max, x | 0));
  };
  const f = (v: unknown, min: number, max: number, fallback: number) => {
    const x = typeof v === "number" && Number.isFinite(v) ? v : fallback;
    return Math.max(min, Math.min(max, x));
  };
  return {
    version: SAVE_VERSION,
    unlockedWorld: n(raw.unlockedWorld, 0, WORLDS - 1, 0),
    bestRoom: Array.from({ length: WORLDS }, (_, i) => n(raw.bestRoom?.[i], 0, ROOMS, 0)),
    souls: n(raw.souls, 0, MAX_SOULS + 5, MAX_SOULS),
    coins: n(raw.coins, 0, 99999, 0),
    adsRemoved: raw.adsRemoved === true,
    currentWorld: n(raw.currentWorld, 0, WORLDS - 1, 0),
    currentRoom: n(raw.currentRoom, 0, ROOMS - 1, 0),
    inRun: raw.inRun === true,
    deaths: n(raw.deaths, 0, 999999, 0),
    roomsCleared: n(raw.roomsCleared, 0, WORLDS * ROOMS, 0),
    settings: {
      sfx: f(raw.settings?.sfx, 0, 1, d.settings.sfx),
      music: f(raw.settings?.music, 0, 1, d.settings.music),
      shake: raw.settings?.shake !== false,
      lang,
    },
  };
}

function parseRaw(text: string): SaveData | null {
  try {
    const parsed = JSON.parse(text) as { p?: string; h?: string } & Partial<SaveData>;
    if (parsed && typeof parsed.p === "string" && typeof parsed.h === "string") {
      if (parsed.h !== fnv(SALT + parsed.p)) return null;
      const inner = JSON.parse(parsed.p) as SaveData;
      if (!inner || typeof inner !== "object") return null;
      return clampSave(inner);
    }
    if (parsed && typeof parsed === "object" && "version" in parsed) {
      return clampSave(parsed as SaveData);
    }
    return null;
  } catch {
    return null;
  }
}

export function loadSave(): SaveData {
  try {
    const s = localStorage.getItem(KEY);
    if (s) {
      const ok = parseRaw(s);
      if (ok) return ok;
    }
  } catch {
    /* ignore */
  }
  try {
    const b = localStorage.getItem(BACKUP);
    if (b) {
      const ok = parseRaw(b);
      if (ok) return ok;
    }
  } catch {
    /* ignore */
  }
  return defaultSave();
}

export function writeSave(data: SaveData) {
  try {
    const safe = clampSave(data);
    const prev = localStorage.getItem(KEY);
    if (prev) localStorage.setItem(BACKUP, prev);
    localStorage.setItem(KEY, seal(safe));
  } catch {
    /* private mode */
  }
}

export function markRoomCleared(save: SaveData, world: number, room: number): SaveData {
  const best = [...save.bestRoom];
  best[world] = Math.max(best[world] ?? 0, room + 1);
  let unlocked = save.unlockedWorld;
  if (room + 1 >= ROOMS) unlocked = Math.max(unlocked, Math.min(WORLDS - 1, world + 1));
  return clampSave({
    ...save,
    bestRoom: best,
    unlockedWorld: unlocked,
    roomsCleared: save.roomsCleared + 1,
    currentWorld: room + 1 >= ROOMS ? Math.min(WORLDS - 1, world + 1) : world,
    currentRoom: room + 1 >= ROOMS ? 0 : room + 1,
    inRun: true,
  });
}

export function furthestRoom(save: SaveData, world: number): number {
  const best = save.bestRoom[world] ?? 0;
  if (best >= ROOMS) return 0;
  if (save.inRun && save.currentWorld === world) return Math.min(save.currentRoom, ROOMS - 1);
  return Math.min(best, ROOMS - 1);
}

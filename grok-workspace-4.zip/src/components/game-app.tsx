import { useEffect, useRef, useState, type CSSProperties, type RefObject } from "react";
import {
  ChevronLeft,
  Download,
  Gem,
  Heart,
  Pause,
  Play,
  Settings as SettingsIcon,
  Store,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { type TrickspireGame } from "@/game/engine";
import { type PadAction } from "@/game/input";
import { unlockAudio, startMusic, setVolumes, resumeAudio, sfx } from "@/game/audio";
import { t } from "@/game/copy";
import { WORLDS_INFO } from "@/game/worlds";
import { MAX_SOULS, ROOMS, WORLDS } from "@/game/types";
import { useGameStore } from "@/store/game-store";
import { furthestRoom } from "@/game/save";
import { cn } from "@/lib/utils";

export function GameApp() {
  const screen = useGameStore((s) => s.screen);
  const lang = useGameStore((s) => s.save.settings.lang);
  const dir = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    const w = window as Window & { __trickBootStop?: () => void };
    w.__trickBootStop?.();
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  useEffect(() => {
    const onVis = () => {
      if (document.hidden) useGameStore.getState().persist();
      else resumeAudio();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  return (
    <OnlineGate>
    <div className="relative flex h-dvh w-full flex-col overflow-hidden bg-bg text-fg" dir={dir}>
      {screen === "play" || screen === "pause" || screen === "roomClear" || screen === "worldFail" || screen === "worldClear" ? (
        <PlayLayer />
      ) : null}
      {screen === "title" && <TitleScreen />}
      {screen === "worlds" && <WorldsScreen />}
      {screen === "shop" && <ShopScreen />}
      {screen === "settings" && <SettingsScreen />}
      {screen === "how" && <HowScreen />}
      {screen === "install" && <InstallScreen />}
      {screen === "ad" && <AdScreen />}
      {screen === "pause" && <PauseOverlay />}
      {screen === "roomClear" && <RoomClearOverlay />}
      {screen === "worldClear" && <WorldClearOverlay />}
      {screen === "worldFail" && <WorldFailOverlay />}
      <Toast />
    </div>
    </OnlineGate>
  );
}

function OnlineGate({ children }: { children: React.ReactNode }) {
  const lang = useGameStore((s) => s.save.settings.lang);
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    const id = window.setInterval(sync, 4000);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
      window.clearInterval(id);
    };
  }, []);
  if (online) return <>{children}</>;
  return (
    <div className="flex h-dvh w-full flex-col items-center justify-center bg-bg px-6 text-center text-fg">
      <p className="text-xs tracking-[0.35em] text-muted uppercase">TRICKSPIRE</p>
      <h1 className="font-display mt-4 text-3xl">{t("offlineTitle", lang)}</h1>
      <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted">{t("offlineBody", lang)}</p>
    </div>
  );
}

function TitleScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const save = useGameStore((s) => s.save);
  const startRun = useGameStore((s) => s.startRun);
  const setScreen = useGameStore((s) => s.setScreen);
  const ads = !save.adsRemoved;

  return (
    <main className="relative flex h-full flex-col items-center justify-between px-5 py-8">
      <div className="pointer-events-none absolute inset-0 opacity-40" style={towerWash()} />
      {ads && <AdBanner />}
      <header className="mt-6 flex w-full max-w-md flex-col items-center text-center">
        <p className="text-xs tracking-[0.35em] text-muted uppercase">TRICKSPIRE</p>
        <h1 className="font-display mt-2 text-5xl font-extrabold leading-tight tracking-tight text-fg">
          {t("title", lang)}
        </h1>
        <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted">{t("tag", lang)}</p>
        <p className="mt-2 text-xs text-subtle">20 × 10 · {t("souls", lang)} 10</p>
      </header>
      <div className="flex w-full max-w-sm flex-col gap-2.5 pb-[max(1rem,env(safe-area-inset-bottom))]">
        <Button
          size="lg"
          className="h-12 w-full font-display"
          onClick={() => {
            bootAudio();
            startRun(save.inRun ? save.currentWorld : 0, save.inRun ? save.currentRoom : 0);
          }}
        >
          <Play className="size-4" />
          {save.inRun ? t("continue", lang) : t("play", lang)}
        </Button>
        <Button size="lg" variant="secondary" className="w-full" onClick={() => setScreen("worlds")}>
          {t("worlds", lang)}
        </Button>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="secondary" onClick={() => setScreen("shop")}>
            <Store className="size-4" />
            {t("shop", lang)}
          </Button>
          <Button variant="secondary" onClick={() => setScreen("install")}>
            <Download className="size-4" />
            {t("install", lang)}
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="ghost" onClick={() => setScreen("how")}>
            {t("how", lang)}
          </Button>
          <Button variant="ghost" onClick={() => setScreen("settings")}>
            <SettingsIcon className="size-4" />
            {t("settings", lang)}
          </Button>
        </div>
      </div>
    </main>
  );
}

function WorldsScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const save = useGameStore((s) => s.save);
  const startRun = useGameStore((s) => s.startRun);
  const setScreen = useGameStore((s) => s.setScreen);
  return (
    <main className="flex h-full flex-col px-4 pt-5 pb-6">
      <TopBar title={t("worlds", lang)} onBack={() => setScreen("title")} />
      <div className="mt-4 grid grid-cols-2 gap-2 overflow-y-auto pb-8 sm:grid-cols-4">
        {WORLDS_INFO.map((w) => {
          const locked = w.id > save.unlockedWorld;
          const done = (save.bestRoom[w.id] ?? 0) >= ROOMS;
          const progress = save.bestRoom[w.id] ?? 0;
          return (
            <button
              key={w.id}
              disabled={locked}
              onClick={() => {
                bootAudio();
                startRun(w.id, furthestRoom(save, w.id));
              }}
              className={cn(
                "rounded-xl border border-border bg-surface p-3 text-start transition-opacity",
                locked && "opacity-40",
              )}
            >
              <div className="mb-2 h-12 rounded-md" style={{ background: w.sky[1] }} />
              <p className="font-display text-sm font-semibold">
                {String(w.id + 1).padStart(2, "0")} · {lang === "ar" ? w.nameAr : w.nameEn}
              </p>
              <p className="mt-1 text-xs text-muted">{lang === "ar" ? w.tagAr : w.tagEn}</p>
              <p className="mt-2 text-xs tabular-nums text-subtle">
                {locked ? t("locked", lang) : done ? t("cleared", lang) : `${progress}/${ROOMS}`}
              </p>
            </button>
          );
        })}
      </div>
    </main>
  );
}

function ShopScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const save = useGameStore((s) => s.save);
  const buy = useGameStore((s) => s.buy);
  const watchAd = useGameStore((s) => s.watchAd);
  const setScreen = useGameStore((s) => s.setScreen);
  const setToast = useGameStore((s) => s.setToast);
  const tryBuy = (cost: number, apply: Parameters<typeof buy>[1], ok: string) => {
    if (!buy(cost, apply)) setToast(t("needCoins", lang));
    else setToast(ok);
  };
  return (
    <main className="flex h-full flex-col px-4 pt-5">
      <TopBar title={t("shop", lang)} onBack={() => setScreen("title")} />
      <div className="mt-2 flex items-center gap-3 text-sm text-muted">
        <span className="inline-flex items-center gap-1 tabular-nums">
          <Gem className="size-4 text-accent" /> {save.coins}
        </span>
        <span className="inline-flex items-center gap-1 tabular-nums">
          <Heart className="size-4 text-soul" /> {save.souls}
        </span>
      </div>
      {!save.adsRemoved && <AdBanner />}
      <div className="mt-4 flex flex-col gap-2">
        <ShopRow
          title={t("buySoul", lang)}
          price="30"
          onClick={() => tryBuy(30, (s) => ({ ...s, souls: Math.min(MAX_SOULS + 5, s.souls + 1) }), t("buySoul", lang))}
        />
        <ShopRow
          title={t("buySouls3", lang)}
          price="80"
          onClick={() => tryBuy(80, (s) => ({ ...s, souls: Math.min(MAX_SOULS + 5, s.souls + 3) }), t("buySouls3", lang))}
        />
        <ShopRow
          title={t("refill", lang)}
          price="120"
          onClick={() => tryBuy(120, (s) => ({ ...s, souls: MAX_SOULS }), t("refill", lang))}
        />
        <ShopRow
          title={t("removeAds", lang)}
          price="500"
          disabled={save.adsRemoved}
          tag={save.adsRemoved ? t("owned", lang) : undefined}
          onClick={() => tryBuy(500, (s) => ({ ...s, adsRemoved: true }), t("removeAds", lang))}
        />
        <Button variant="secondary" className="mt-2" onClick={() => watchAd("rewarded-coins")}>
          {t("watchCoins", lang)}
        </Button>
      </div>
    </main>
  );
}

function ShopRow({
  title,
  price,
  onClick,
  disabled,
  tag,
}: {
  title: string;
  price: string;
  onClick: () => void;
  disabled?: boolean;
  tag?: string;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className="flex h-14 items-center justify-between rounded-lg border border-border bg-surface px-4 text-sm disabled:opacity-40"
    >
      <span>{title}</span>
      <span className="tabular-nums text-muted">{tag ?? price}</span>
    </button>
  );
}

function SettingsScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const settings = useGameStore((s) => s.save.settings);
  const setSetting = useGameStore((s) => s.setSetting);
  const setLang = useGameStore((s) => s.setLang);
  const resetAll = useGameStore((s) => s.resetAll);
  const setScreen = useGameStore((s) => s.setScreen);
  useEffect(() => {
    setVolumes(settings.sfx, settings.music);
  }, [settings.sfx, settings.music]);
  return (
    <main className="flex h-full flex-col px-4 pt-5">
      <TopBar title={t("settings", lang)} onBack={() => setScreen("title")} />
      <label className="mt-6 text-xs text-muted">{t("sfx", lang)}</label>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={settings.sfx}
        onChange={(e) => setSetting({ sfx: Number(e.target.value) })}
        className="mt-1 w-full accent-accent"
      />
      <label className="mt-5 text-xs text-muted">{t("music", lang)}</label>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={settings.music}
        onChange={(e) => setSetting({ music: Number(e.target.value) })}
        className="mt-1 w-full accent-accent"
      />
      <button
        className="mt-5 flex h-11 items-center justify-between rounded-md border border-border bg-surface px-4 text-sm"
        onClick={() => setSetting({ shake: !settings.shake })}
      >
        {t("shake", lang)}
        <span className="text-muted">{settings.shake ? "On" : "Off"}</span>
      </button>
      <button
        className="mt-2 flex h-11 items-center justify-between rounded-md border border-border bg-surface px-4 text-sm"
        onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      >
        {t("lang", lang)}
        <span className="text-muted">{lang === "ar" ? "العربية" : "English"}</span>
      </button>
      <Button
        variant="danger"
        className="mt-8"
        onClick={() => {
          if (confirm(t("confirmReset", lang))) resetAll();
        }}
      >
        {t("reset", lang)}
      </Button>
    </main>
  );
}

function HowScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const setScreen = useGameStore((s) => s.setScreen);
  return (
    <main className="flex h-full flex-col px-5 pt-5">
      <TopBar title={t("how", lang)} onBack={() => setScreen("title")} />
      <p className="mt-6 max-w-md text-sm leading-relaxed text-muted">{t("howBody", lang)}</p>
    </main>
  );
}

function InstallScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const setScreen = useGameStore((s) => s.setScreen);
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [source, setSource] = useState<string | null>(null);
  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);
  const loadSource = async () => {
    if (source) return source;
    const res = await fetch("/trickspire.html");
    const text = await res.text();
    setSource(text);
    return text;
  };
  return (
    <main className="flex h-full flex-col px-5 pt-5">
      <TopBar title={t("install", lang)} onBack={() => setScreen("title")} />
      <p className="mt-6 max-w-md text-sm leading-relaxed text-muted">{t("installBody", lang)}</p>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">{t("htmlHint", lang)}</p>
      <Button
        className="mt-6"
        onClick={async () => {
          if (deferred) {
            await deferred.prompt();
            setDeferred(null);
            return;
          }
          window.location.href = "/?install=1";
        }}
      >
        <Download className="size-4" />
        {t("installNow", lang)}
      </Button>
      <Button
        variant="secondary"
        className="mt-2"
        onClick={async () => {
          try {
            const text = await loadSource();
            const blob = new Blob([text], { type: "text/html;charset=utf-8" });
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = "index.html";
            a.click();
            URL.revokeObjectURL(a.href);
          } catch {
            const a = document.createElement("a");
            a.href = "/trickspire.html";
            a.download = "index.html";
            a.click();
          }
        }}
      >
        <Download className="size-4" />
        {t("htmlFile", lang)}
      </Button>
      <Button
        variant="ghost"
        className="mt-2"
        onClick={async () => {
          try {
            const text = await loadSource();
            await navigator.clipboard.writeText(text);
            useGameStore.getState().setToast(lang === "ar" ? "تم النسخ — الصق في index.html" : "Copied — paste into index.html");
          } catch {
            useGameStore.getState().setToast(lang === "ar" ? "استخدم زر التنزيل أو عرض الكود" : "Use download or show code");
          }
        }}
      >
        {t("copyHtml", lang)}
      </Button>
      <Button
        variant="ghost"
        className="mt-2"
        onClick={async () => {
          try {
            await loadSource();
          } catch {
            useGameStore.getState().setToast(lang === "ar" ? "تعذر تحميل الملف" : "Could not load file");
          }
        }}
      >
        {lang === "ar" ? "عرض الكود للنسخ اليدوي" : "Show code to copy"}
      </Button>
      {source && (
        <textarea
          readOnly
          value={source}
          spellCheck={false}
          onFocus={(e) => e.currentTarget.select()}
          className="mt-3 mb-6 min-h-40 w-full max-w-lg flex-1 rounded-xl border border-border bg-bg p-3 font-mono text-[11px] leading-relaxed text-muted"
          dir="ltr"
        />
      )}
    </main>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
}

function PlayLayer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<TrickspireGame | null>(null);
  const world = useGameStore((s) => s.playWorld);
  const room = useGameStore((s) => s.playRoom);
  const session = useGameStore((s) => s.session);
  const save = useGameStore((s) => s.save);
  const lang = save.settings.lang;
  const screen = useGameStore((s) => s.screen);
  const applyHud = useGameStore((s) => s.applyHud);
  const nextRoom = useGameStore((s) => s.nextRoom);
  const failWorld = useGameStore((s) => s.failWorld);
  const setScreen = useGameStore((s) => s.setScreen);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    let game: TrickspireGame | null = null;
    const onHint = () => game?.setHint(8);
    void import("@/game/engine").then(({ TrickspireGame: Game }) => {
      if (cancelled || !canvasRef.current) return;
      game = new Game(canvasRef.current, {
        onHud: applyHud,
        onDeath: () => {},
        onRoomClear: () => {
          const g = gameRef.current;
          if (g) {
            const st = useGameStore.getState();
            useGameStore.setState({
              save: { ...st.save, coins: g.coins, souls: g.souls },
            });
          }
          nextRoom();
        },
        onWorldFail: () => failWorld(),
        onWorldClear: () => {},
        onCoin: () => {},
        onCheckpoint: () => {},
      });
      game.lang = lang;
      game.shakeOn = save.settings.shake;
      game.start(world, room, save.souls, save.coins);
      gameRef.current = game;
      setVolumes(save.settings.sfx, save.settings.music);
      window.addEventListener("trickspire-hint", onHint);
    });
    return () => {
      cancelled = true;
      window.removeEventListener("trickspire-hint", onHint);
      game?.destroy();
      gameRef.current = null;
    };
    // session remounts a new room
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [world, room, session]);

  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    g.setPaused(screen !== "play");
    g.shakeOn = save.settings.shake;
    g.lang = lang;
  }, [screen, save.settings.shake, lang]);

  const playing = screen === "play";

  return (
    <div className="relative h-full w-full bg-bg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 m-auto h-full w-full touch-none object-contain"
        style={{ imageRendering: "auto", touchAction: "none" }}
      />
      <HudBar />
      <SignBanner playing={playing} />
      {playing && <TouchPad gameRef={gameRef} />}
      {playing && (
        <button
          className="absolute top-3 end-3 z-10 flex size-11 items-center justify-center rounded-md border border-border bg-surface/80"
          onClick={() => setScreen("pause")}
          aria-label={t("pause", lang)}
        >
          <Pause className="size-4" />
        </button>
      )}
    </div>
  );
}

function HudBar() {
  const hud = useGameStore((s) => s.hud);
  const lang = useGameStore((s) => s.save.settings.lang);
  const world = WORLDS_INFO[hud.world];
  return (
    <div className="pointer-events-none absolute top-3 start-3 z-10 flex flex-col gap-1">
      <div className="flex items-center gap-2 rounded-md border border-border bg-surface/80 px-2.5 py-1.5 text-xs tabular-nums">
        <span className="inline-flex items-center gap-1">
          {Array.from({ length: MAX_SOULS }).map((_, i) => (
            <span
              key={i}
              className={cn("inline-block size-2 rounded-full", i < hud.souls ? "bg-soul" : "bg-soul-dim")}
            />
          ))}
        </span>
      </div>
      <div className="rounded-md border border-border bg-surface/80 px-2.5 py-1 text-xs text-muted whitespace-nowrap">
        {(lang === "ar" ? world?.nameAr : world?.nameEn) ?? ""} · {t("room", lang)} {hud.room + 1}/{ROOMS}
        <span className="ms-2 inline-flex items-center gap-1 tabular-nums text-fg">
          <Gem className="size-3" />
          {hud.coins}
        </span>
      </div>
    </div>
  );
}

function SignBanner({ playing }: { playing: boolean }) {
  const hud = useGameStore((s) => s.hud);
  const lang = useGameStore((s) => s.save.settings.lang);
  if (!playing || !hud.signAr) return null;
  return (
    <div className="pointer-events-none absolute top-16 left-1/2 z-10 w-[min(90%,22rem)] -translate-x-1/2 rounded-md border border-border bg-surface/90 px-3 py-2 text-center text-sm text-fg">
      {lang === "ar" ? hud.signAr : hud.signEn}
    </div>
  );
}

function TouchPad({ gameRef }: { gameRef: RefObject<TrickspireGame | null> }) {
  const lang = useGameStore((s) => s.save.settings.lang);
  const leftRef = useRef<HTMLButtonElement>(null);
  const rightRef = useRef<HTMLButtonElement>(null);
  const jumpRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const cleanups: Array<() => void> = [];
    const bind = (el: HTMLButtonElement | null, action: PadAction) => {
      if (!el) return;
      const down = (e: PointerEvent) => {
        e.preventDefault();
        e.stopPropagation();
        try {
          el.setPointerCapture(e.pointerId);
        } catch {
          /* iOS may ignore capture */
        }
        gameRef.current?.input.pointerDown(action, e.pointerId);
      };
      const up = (e: PointerEvent) => {
        e.preventDefault();
        gameRef.current?.input.pointerUp(action, e.pointerId);
      };
      el.addEventListener("pointerdown", down, { passive: false });
      el.addEventListener("pointerup", up);
      el.addEventListener("pointercancel", up);
      el.addEventListener("lostpointercapture", up);
      el.addEventListener(
        "contextmenu",
        (ev) => {
          ev.preventDefault();
        },
        { passive: false },
      );
      cleanups.push(() => {
        el.removeEventListener("pointerdown", down);
        el.removeEventListener("pointerup", up);
        el.removeEventListener("pointercancel", up);
        el.removeEventListener("lostpointercapture", up);
      });
    };
    bind(leftRef.current, "left");
    bind(rightRef.current, "right");
    bind(jumpRef.current, "jump");
    return () => {
      for (const c of cleanups) c();
      gameRef.current?.input.clearPointers();
    };
  }, [gameRef]);

  const padClass =
    "touch-none select-none [touch-action:none] [-webkit-user-select:none] rounded-lg border border-border bg-surface/80 text-lg active:bg-accent active:text-accent-fg";

  return (
    <div
      dir="ltr"
      className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))]"
    >
      <div className="pointer-events-auto flex gap-3">
        <button
          ref={leftRef}
          type="button"
          className={cn(padClass, "h-20 w-20")}
          aria-label="left"
        >
          ←
        </button>
        <button
          ref={rightRef}
          type="button"
          className={cn(padClass, "h-20 w-20")}
          aria-label="right"
        >
          →
        </button>
      </div>
      <button
        ref={jumpRef}
        type="button"
        className={cn(padClass, "pointer-events-auto h-20 w-28 bg-accent/90 font-display text-sm text-accent-fg")}
        aria-label="jump"
      >
        {t("jump", lang)}
      </button>
    </div>
  );
}

function PauseOverlay() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const setScreen = useGameStore((s) => s.setScreen);
  const watchAd = useGameStore((s) => s.watchAd);
  const buy = useGameStore((s) => s.buy);
  const gameHint = () => {
    const ok = buy(15, (s) => s);
    if (ok) window.dispatchEvent(new Event("trickspire-hint"));
    else useGameStore.getState().setToast(t("needCoins", lang));
  };
  useEffect(() => {
    /* engine pause handled by PlayLayer */
  }, []);
  return (
    <Modal>
      <h2 className="font-display text-2xl">{t("pause", lang)}</h2>
      <Button className="mt-6 w-full" onClick={() => setScreen("play")}>
        {t("resume", lang)}
      </Button>
      <Button variant="secondary" className="mt-2 w-full" onClick={() => watchAd("rewarded-soul")}>
        {t("extraSoul", lang)}
      </Button>
      <Button variant="secondary" className="mt-2 w-full" onClick={gameHint}>
        {t("hint", lang)}
      </Button>
      <Button variant="ghost" className="mt-2 w-full" onClick={() => setScreen("title")}>
        {t("menu", lang)}
      </Button>
    </Modal>
  );
}

function RoomClearOverlay() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const playWorld = useGameStore((s) => s.playWorld);
  const playRoom = useGameStore((s) => s.playRoom);
  const startRun = useGameStore((s) => s.startRun);
  const watchAd = useGameStore((s) => s.watchAd);
  const save = useGameStore((s) => s.save);
  return (
    <Modal>
      <h2 className="font-display text-2xl">{t("roomClear", lang)}</h2>
      <p className="mt-2 text-sm text-muted">
        {t("room", lang)} {playRoom}/{ROOMS}
      </p>
      <Button
        className="mt-6 w-full"
        onClick={() => {
          if (!save.adsRemoved && playRoom % 5 === 0) {
            watchAd("interstitial");
            return;
          }
          startRun(playWorld, playRoom);
        }}
      >
        {t("next", lang)}
      </Button>
    </Modal>
  );
}

function WorldClearOverlay() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const playWorld = useGameStore((s) => s.playWorld);
  const startRun = useGameStore((s) => s.startRun);
  const watchAd = useGameStore((s) => s.watchAd);
  const save = useGameStore((s) => s.save);
  const setScreen = useGameStore((s) => s.setScreen);
  const last = playWorld >= WORLDS;
  return (
    <Modal>
      <h2 className="font-display text-2xl">{t("worldClear", lang)}</h2>
      <Button
        className="mt-6 w-full"
        onClick={() => {
          if (last) {
            setScreen("title");
            return;
          }
          if (!save.adsRemoved) {
            watchAd("interstitial");
            return;
          }
          startRun(playWorld, 0);
        }}
      >
        {t("next", lang)}
      </Button>
    </Modal>
  );
}

function WorldFailOverlay() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const restartWorld = useGameStore((s) => s.restartWorld);
  const watchAd = useGameStore((s) => s.watchAd);
  const setScreen = useGameStore((s) => s.setScreen);
  return (
    <Modal>
      <h2 className="font-display text-2xl">{t("worldFail", lang)}</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">{t("worldFailBody", lang)}</p>
      <Button className="mt-6 w-full" onClick={restartWorld}>
        {t("restartWorld", lang)}
      </Button>
      <Button variant="secondary" className="mt-2 w-full" onClick={() => watchAd("rewarded-continue")}>
        {t("watchContinue", lang)}
      </Button>
      <Button variant="ghost" className="mt-2 w-full" onClick={() => setScreen("title")}>
        {t("menu", lang)}
      </Button>
    </Modal>
  );
}

function AdScreen() {
  const lang = useGameStore((s) => s.save.settings.lang);
  const kind = useGameStore((s) => s.adKind);
  const finishAd = useGameStore((s) => s.finishAd);
  const [left, setLeft] = useState(kind === "interstitial" ? 3 : 5);
  useEffect(() => {
    setLeft(kind === "interstitial" ? 3 : 5);
    const id = window.setInterval(() => {
      setLeft((n) => {
        if (n <= 1) {
          window.clearInterval(id);
          return 0;
        }
        return n - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [kind]);
  const ready = left <= 0;
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-bg px-6">
      <p className="text-xs tracking-[0.3em] text-subtle uppercase">{t("adLabel", lang)}</p>
      <div className="mt-6 flex h-48 w-full max-w-sm items-center justify-center rounded-xl border border-border bg-surface-2">
        <div className="text-center">
          <p className="font-display text-lg">{t("sponsor", lang)}</p>
          <p className="mt-2 text-sm text-muted">Trickspire Ads</p>
        </div>
      </div>
      <Button className="mt-8" disabled={!ready} onClick={finishAd}>
        {ready ? t("skipAd", lang) : `${t("skipAd", lang)} ${left}`}
      </Button>
    </div>
  );
}

function AdBanner() {
  const lang = useGameStore((s) => s.save.settings.lang);
  return (
    <div className="mx-auto mt-2 flex h-14 w-full max-w-md items-center justify-center rounded-md border border-border bg-surface-2 text-xs text-subtle">
      {t("adLabel", lang)} · {t("sponsor", lang)}
    </div>
  );
}

function Modal({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/70 px-5">
      <div className="w-full max-w-sm rounded-xl border border-border bg-surface p-6">{children}</div>
    </div>
  );
}

function TopBar({ title, onBack }: { title: string; onBack: () => void }) {
  const lang = useGameStore((s) => s.save.settings.lang);
  return (
    <div className="flex items-center gap-2">
      <Button variant="ghost" size="icon" onClick={onBack} aria-label={t("back", lang)}>
        <ChevronLeft className="size-5 rtl:rotate-180" />
      </Button>
      <h1 className="font-display text-xl">{title}</h1>
    </div>
  );
}

function Toast() {
  const toast = useGameStore((s) => s.toast);
  const setToast = useGameStore((s) => s.setToast);
  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 1800);
    return () => window.clearTimeout(id);
  }, [toast, setToast]);
  if (!toast) return null;
  return (
    <div className="absolute bottom-24 left-1/2 z-40 -translate-x-1/2 rounded-md border border-border bg-surface px-3 py-2 text-sm">
      {toast}
    </div>
  );
}

function towerWash(): CSSProperties {
  return {
    background:
      "radial-gradient(1200px 500px at 50% -10%, #1c1824 0%, transparent 70%), repeating-linear-gradient(90deg, transparent 0 40px, rgba(240,235,227,0.03) 40px 41px)",
  };
}

function bootAudio() {
  unlockAudio();
  startMusic();
  const s = useGameStore.getState().save.settings;
  setVolumes(s.sfx, s.music);
  sfx.click();
}

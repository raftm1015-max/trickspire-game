import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

const APP_NAME = "Trickspire";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#0a090c" },
      { name: "description", content: "Trickspire — 20 worlds, 200 rooms, ten souls. The tower lies." },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){if(document.getElementById('trick-boot'))return;var d=document.createElement('div');d.id='trick-boot';d.setAttribute('style','position:fixed;inset:0;z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0a090c;color:#f0ebe3;font-family:Tahoma,Segoe UI,sans-serif');d.innerHTML='<p style="letter-spacing:.35em;font-size:12px;color:#9a9088;margin:0">TRICKSPIRE</p><p style="margin:16px 0 28px;font-size:28px;font-weight:700">Trickspire</p><div style="width:min(70vw,16rem);height:8px;border-radius:99px;background:#1c191f;overflow:hidden;border:1px solid #2a262c"><div id="trick-boot-bar" style="width:8%;height:100%;background:#e8e0d4;transition:width .12s linear"></div></div><p id="trick-boot-pct" style="margin-top:10px;font-size:12px;color:#9a9088">8%</p>';document.body.appendChild(d);var n=8,b=document.getElementById('trick-boot-bar'),p=document.getElementById('trick-boot-pct');var id=setInterval(function(){n=Math.min(90,n+2);if(b)b.style.width=n+'%';if(p)p.textContent=n+'%';},90);window.__trickBootStop=function(){clearInterval(id);if(b)b.style.width='100%';if(p)p.textContent='100%';setTimeout(function(){var e=document.getElementById('trick-boot');if(e)e.remove();},160);};})();`,
          }}
        />
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});

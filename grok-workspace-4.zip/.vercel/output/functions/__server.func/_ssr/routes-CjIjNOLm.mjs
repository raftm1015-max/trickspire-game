import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pause, c as Download, i as Play, l as ChevronLeft, n as Store, o as Heart, r as Settings, s as Gem } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CjIjNOLm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-opacity duration-[var(--motion-quick,150ms)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg border border-border hover:bg-surface",
			ghost: "text-fg hover:bg-surface-2",
			danger: "bg-soul text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-5 text-sm rounded-md",
			lg: "h-12 px-6 text-base rounded-lg",
			sm: "h-9 px-3 text-sm rounded-sm",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	ref,
	...props
}));
Button.displayName = "Button";
var GAME_KEYS = /* @__PURE__ */ new Set([
	"KeyA",
	"KeyD",
	"KeyW",
	"KeyS",
	"ArrowLeft",
	"ArrowRight",
	"ArrowUp",
	"ArrowDown",
	"Space",
	"KeyK",
	"KeyP",
	"Escape"
]);
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	prevJump = false;
	touchLeft = 0;
	touchRight = 0;
	touchJump = false;
	touchDown = false;
	pauseQueued = false;
	attach(el) {
		const down = (e) => {
			this.keys.add(e.code);
			if (GAME_KEYS.has(e.code)) e.preventDefault();
			if (e.code === "Escape" || e.code === "KeyP") this.pauseQueued = true;
		};
		const up = (e) => this.keys.delete(e.code);
		const clear = () => this.keys.clear();
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", clear);
		document.addEventListener("visibilitychange", () => {
			if (document.hidden) clear();
		});
		el.addEventListener("contextmenu", (e) => {
			e.preventDefault();
		}, { passive: false });
		this._cleanup = () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", clear);
		};
	}
	_cleanup = null;
	detach() {
		this._cleanup?.();
		this._cleanup = null;
	}
	setKeys(codes) {
		this.injected = codes.length ? codes : null;
	}
	sample(reverse, swapLR) {
		this.injected ?? [...this.keys];
		const has = (c) => this.injected ? this.injected.includes(c) : this.keys.has(c);
		let left = has("KeyA") || has("ArrowLeft") || this.touchLeft > .3;
		let right = has("KeyD") || has("ArrowRight") || this.touchRight > .3;
		if (swapLR) [left, right] = [right, left];
		if (reverse) [left, right] = [right, left];
		let moveX = 0;
		if (left) moveX -= 1;
		if (right) moveX += 1;
		const pads = navigator.getGamepads?.() ?? [];
		for (const pad of pads) {
			if (!pad) continue;
			const ax = pad.axes[0] ?? 0;
			if (Math.abs(ax) > .25) moveX = Math.sign(ax) * (reverse || swapLR ? -1 : 1);
			if (pad.buttons[14]?.pressed) moveX = reverse || swapLR ? 1 : -1;
			if (pad.buttons[15]?.pressed) moveX = reverse || swapLR ? -1 : 1;
			if (pad.buttons[0]?.pressed || pad.buttons[1]?.pressed) this.touchJump = true;
			if (pad.buttons[9]?.pressed) this.pauseQueued = true;
		}
		const jumpHeld = has("Space") || has("KeyW") || has("ArrowUp") || has("KeyK") || this.touchJump;
		const jumpPressed = jumpHeld && !this.prevJump;
		this.prevJump = jumpHeld;
		const down = has("KeyS") || has("ArrowDown") || this.touchDown;
		if (this.injected && this.injected.length === 0) {}
		return {
			moveX,
			jump: jumpPressed,
			jumpHeld,
			jumpPressed,
			down
		};
	}
};
var FIXED_DT = 1 / 60;
var T = {
	EMPTY: 0,
	SOLID: 1,
	SPIKE_U: 2,
	SPIKE_D: 3,
	SPIKE_L: 4,
	SPIKE_R: 5,
	SPAWN: 6,
	GOAL: 7,
	FAKE_GOAL: 8,
	CHECK: 9,
	FAKE_CHECK: 10,
	CRUMBLE: 11,
	ICE: 12,
	BOUNCE: 13,
	TELE_A: 14,
	TELE_B: 15,
	HIDDEN_SPIKE: 16,
	ONE_WAY: 17,
	INVIS: 18,
	FAKE_SOLID: 19,
	SPRING: 20,
	COIN: 21,
	CONV_L: 22,
	CONV_R: 23,
	LAVA: 24,
	BUTTON: 25,
	DOOR: 26,
	SPIKE_POP: 27,
	VANISH: 28
};
function mulberry(seed) {
	let s = seed | 0;
	return () => {
		s = Math.imul(s, 1831565813) + 3735928559 | 0;
		const t = Math.imul(s ^ s >>> 15, 1 | s);
		return ((t ^ t >>> 7) >>> 0) / 4294967296;
	};
}
var Grid = class {
	cols;
	rows;
	tiles;
	constructor(cols, rows) {
		this.cols = cols;
		this.rows = rows;
		this.tiles = new Uint8Array(cols * rows);
	}
	i(x, y) {
		return y * this.cols + x;
	}
	in(x, y) {
		return x >= 0 && y >= 0 && x < this.cols && y < this.rows;
	}
	get(x, y) {
		if (!this.in(x, y)) return T.SOLID;
		return this.tiles[this.i(x, y)];
	}
	set(x, y, v) {
		if (this.in(x, y)) this.tiles[this.i(x, y)] = v;
	}
	rect(x, y, w, h, v) {
		for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, v);
	}
	border() {
		this.rect(0, 0, this.cols, 1, T.SOLID);
		this.rect(0, this.rows - 1, this.cols, 1, T.SOLID);
		this.rect(0, 0, 1, this.rows, T.SOLID);
		this.rect(this.cols - 1, 0, 1, this.rows, T.SOLID);
	}
	ground() {
		this.rect(1, this.rows - 2, this.cols - 2, 1, T.SOLID);
	}
};
var TROLLS = [
	[
		"none",
		"none",
		"none",
		"falseFloor",
		"fakeGoal",
		"reverse",
		"crumble",
		"lyingSign",
		"vanishFloor",
		"combo"
	],
	[
		"crumble",
		"crumble",
		"falseFloor",
		"vanishFloor",
		"crumble",
		"fakeGoal",
		"crumble",
		"lyingSign",
		"combo",
		"crumble"
	],
	[
		"none",
		"spikePop",
		"falseFloor",
		"spikePop",
		"fakeCheck",
		"spikePop",
		"lyingSign",
		"combo",
		"spikePop",
		"combo"
	],
	[
		"reverse",
		"swapLR",
		"cameraFlip",
		"reverse",
		"mirrorCam",
		"swapLR",
		"reverse",
		"lyingSign",
		"combo",
		"cameraFlip"
	],
	[
		"falseFloor",
		"invisWall",
		"vanishFloor",
		"falseFloor",
		"invisWall",
		"fakeGoal",
		"vanishFloor",
		"combo",
		"invisWall",
		"combo"
	],
	[
		"gravity",
		"slowFall",
		"gravity",
		"jumpCut",
		"gravity",
		"fakeGoal",
		"slowFall",
		"combo",
		"gravity",
		"combo"
	],
	[
		"iceBoost",
		"boostSpike",
		"iceBoost",
		"iceBoost",
		"boostSpike",
		"fakeGoal",
		"iceBoost",
		"combo",
		"boostSpike",
		"combo"
	],
	[
		"shrink",
		"tiny",
		"shrink",
		"tiny",
		"jumpCut",
		"fakeGoal",
		"shrink",
		"combo",
		"tiny",
		"combo"
	],
	[
		"lyingSign",
		"fakeCheck",
		"fakeWin",
		"lyingSign",
		"fakeGoal",
		"fakeWin",
		"lyingSign",
		"combo",
		"fakeCheck",
		"combo"
	],
	[
		"timedDoor",
		"vanishFloor",
		"timedDoor",
		"spikePop",
		"timedDoor",
		"fakeGoal",
		"vanishFloor",
		"combo",
		"timedDoor",
		"combo"
	],
	[
		"darkness",
		"darkness",
		"invisWall",
		"darkness",
		"fakeGoal",
		"darkness",
		"lyingSign",
		"combo",
		"darkness",
		"combo"
	],
	[
		"fakeGoal",
		"fakeWin",
		"fakeGoal",
		"fakeCheck",
		"fakeGoal",
		"fakeGoal",
		"fakeWin",
		"combo",
		"fakeGoal",
		"combo"
	],
	[
		"none",
		"none",
		"none",
		"crumble",
		"fakeGoal",
		"none",
		"vanishFloor",
		"combo",
		"none",
		"combo"
	],
	[
		"teleport",
		"teleport",
		"fakeGoal",
		"teleport",
		"invisWall",
		"teleport",
		"lyingSign",
		"combo",
		"teleport",
		"combo"
	],
	[
		"wind",
		"wind",
		"boostSpike",
		"wind",
		"fakeGoal",
		"wind",
		"jumpCut",
		"combo",
		"wind",
		"combo"
	],
	[
		"risingLava",
		"risingLava",
		"timedDoor",
		"risingLava",
		"fakeGoal",
		"risingLava",
		"crumble",
		"combo",
		"risingLava",
		"combo"
	],
	[
		"invisWall",
		"falseFloor",
		"invisWall",
		"vanishFloor",
		"invisWall",
		"fakeGoal",
		"invisWall",
		"combo",
		"falseFloor",
		"combo"
	],
	[
		"combo",
		"reverse",
		"darkness",
		"risingLava",
		"fakeWin",
		"gravity",
		"wind",
		"combo",
		"shrink",
		"combo"
	],
	[
		"fakeWin",
		"swapLR",
		"goalRuns",
		"lyingSign",
		"lockedJump",
		"fakeCheck",
		"cameraFlip",
		"combo",
		"goalRuns",
		"combo"
	],
	[
		"combo",
		"combo",
		"risingLava",
		"darkness",
		"goalRuns",
		"gravity",
		"reverse",
		"combo",
		"fakeWin",
		"combo"
	]
];
function parseAscii(lines, world, room, trolls, signs = []) {
	const rows = lines.length;
	const cols = Math.max(...lines.map((l) => l.length));
	const g = new Grid(cols, rows);
	let spawn = {
		x: 2,
		y: rows - 4
	};
	let goal = {
		x: cols - 3,
		y: rows - 4
	};
	const moving = [];
	for (let y = 0; y < rows; y++) {
		const line = lines[y].padEnd(cols, ".");
		for (let x = 0; x < cols; x++) switch (line[x]) {
			case "#":
				g.set(x, y, T.SOLID);
				break;
			case "^":
				g.set(x, y, T.SPIKE_U);
				break;
			case "v":
				g.set(x, y, T.SPIKE_D);
				break;
			case "S":
				spawn = {
					x,
					y
				};
				break;
			case "G":
				goal = {
					x,
					y
				};
				g.set(x, y, T.GOAL);
				break;
			case "g":
				g.set(x, y, T.FAKE_GOAL);
				break;
			case "C":
				g.set(x, y, T.CHECK);
				break;
			case "c":
				g.set(x, y, T.FAKE_CHECK);
				break;
			case "P":
				g.set(x, y, T.CRUMBLE);
				break;
			case "F":
				g.set(x, y, T.FAKE_SOLID);
				break;
			case "I":
				g.set(x, y, T.INVIS);
				break;
			case "i":
				g.set(x, y, T.ICE);
				break;
			case "B":
				g.set(x, y, T.BOUNCE);
				break;
			case "A":
				g.set(x, y, T.TELE_A);
				break;
			case "T":
				g.set(x, y, T.TELE_B);
				break;
			case "-":
				g.set(x, y, T.ONE_WAY);
				break;
			case "=":
				g.set(x, y, T.CONV_R);
				break;
			case "+":
				g.set(x, y, T.CONV_L);
				break;
			case "O":
				g.set(x, y, T.SPRING);
				break;
			case "o":
				g.set(x, y, T.COIN);
				break;
			case "L":
				g.set(x, y, T.LAVA);
				break;
			case "D":
				g.set(x, y, T.DOOR);
				break;
			case "K":
				g.set(x, y, T.BUTTON);
				break;
			case "H":
				g.set(x, y, T.HIDDEN_SPIKE);
				break;
			case "V":
				g.set(x, y, T.VANISH);
				break;
			case "X": g.set(x, y, T.SPIKE_POP);
		}
	}
	return finish(g, world, room, trolls, spawn, goal, signs, moving);
}
function finish(g, world, room, trolls, spawn, goal, signs, moving) {
	const has = (id) => trolls.includes(id) || trolls.includes("combo");
	return {
		cols: g.cols,
		rows: g.rows,
		tiles: g.tiles,
		world,
		room,
		trolls,
		spawn,
		goal,
		signs,
		moving,
		wind: has("wind") ? world % 2 === 0 ? 140 : -140 : 0,
		gravitySign: 1,
		risingLava: has("risingLava"),
		darkness: has("darkness"),
		cameraFlip: has("cameraFlip"),
		mirrorCam: has("mirrorCam"),
		reverse: has("reverse"),
		swapLR: has("swapLR"),
		shrink: has("shrink") || has("tiny"),
		jumpCut: has("jumpCut"),
		lockedJump: has("lockedJump"),
		goalRuns: has("goalRuns"),
		fakeWin: has("fakeWin"),
		timedDoor: has("timedDoor"),
		vanishFloor: has("vanishFloor")
	};
}
var TUTORIAL = [
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S............................G#",
		"################################",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S..........###...............G#",
		"######......###..........#######",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S............................G#",
		"######......^^^^..........######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S............................G#",
		"######..FF^^.............#######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#...................g..........#",
		"#..................####........#",
		"#..............................#",
		"#..............................#",
		"#S............................G#",
		"#######.................########",
		"#.................^^^^.........#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............####............#",
		"#S............................G#",
		"#######....^^^^..........#######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S.....PPPP......PPPP.........G#",
		"######......^^^^......##########",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#S............................G#",
		"#######....^^^^..........#######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............C...............#",
		"#S............................G#",
		"#######..FF^^............#######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	],
	[
		"################################",
		"#..............................#",
		"#...................g..........#",
		"#..................####........#",
		"#S....PPPP....................G#",
		"######......^^^^..........######",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"#..............................#",
		"################################"
	]
];
var TUTORIAL_SIGNS = [
	[{
		x: 10,
		y: 6,
		ar: "امشِ إلى الباب. بسيط.",
		en: "Walk to the door. Simple."
	}],
	[{
		x: 12,
		y: 5,
		ar: "اقفز. المسافة تصدق هذه المرة.",
		en: "Jump. Space tells the truth this time."
	}],
	[{
		x: 12,
		y: 5,
		ar: "الإبر سيئة. تجاوزها.",
		en: "Needles are rude. Go over."
	}],
	[{
		x: 10,
		y: 5,
		ar: "الأرض صديقتك.",
		en: "The floor is your friend."
	}],
	[{
		x: 14,
		y: 5,
		ar: "أقرب باب هو الباب.",
		en: "The nearest door is the door."
	}],
	[{
		x: 12,
		y: 4,
		ar: "التحكم معكوس. أو لا.",
		en: "Controls are reversed. Or not."
	}],
	[{
		x: 12,
		y: 4,
		ar: "قف طويلاً. الأرض تحبك.",
		en: "Stand still. The floor loves you."
	}],
	[{
		x: 12,
		y: 4,
		ar: "لا تقفز.",
		en: "Do not jump."
	}],
	[{
		x: 14,
		y: 3,
		ar: "نقطة الحفظ آمنة دائماً.",
		en: "Checkpoints are always safe."
	}],
	[{
		x: 10,
		y: 3,
		ar: "الآن فهمت القواعد.",
		en: "Now you know the rules."
	}]
];
function applyTrollTiles(g, troll, R, spawnX, goalX) {
	const mid = (spawnX + goalX) / 2 | 0;
	const gy = g.rows - 2;
	if (troll === "falseFloor" || troll === "combo") {
		const w = 3 + (R() * 3 | 0);
		const x = Math.max(spawnX + 3, mid - 2);
		for (let i = 0; i < w; i++) {
			g.set(x + i, gy, T.FAKE_SOLID);
			g.set(x + i, gy + 1, T.SPIKE_U);
		}
	}
	if (troll === "crumble" || troll === "combo") {
		const x = mid;
		for (let i = 0; i < 5; i++) if (g.get(x + i, gy) === T.SOLID) g.set(x + i, gy, T.CRUMBLE);
	}
	if (troll === "fakeGoal" || troll === "fakeWin" || troll === "combo") {
		const fx = Math.min(g.cols - 4, mid + 2);
		const fy = gy - 4;
		g.rect(fx - 1, fy + 1, 3, 1, T.SOLID);
		g.set(fx, fy, T.FAKE_GOAL);
	}
	if (troll === "fakeCheck") g.set(mid, gy - 1, T.FAKE_CHECK);
	if (troll === "invisWall" || troll === "combo") {
		const x = mid + 1;
		g.rect(x, gy - 4, 1, 4, T.INVIS);
	}
	if (troll === "iceBoost" || troll === "boostSpike") {
		g.rect(spawnX + 4, gy, 10, 1, T.ICE);
		if (troll === "boostSpike") g.set(spawnX + 14, gy - 1, T.SPIKE_U);
	}
	if (troll === "teleport") {
		g.set(spawnX + 5, gy - 1, T.TELE_A);
		g.set(goalX - 3, gy - 1, T.TELE_B);
	}
	if (troll === "spikePop") for (let x = spawnX + 4; x < goalX - 2; x += 3) g.set(x, gy - 1, T.SPIKE_POP);
	if (troll === "timedDoor") {
		g.rect(mid, gy - 3, 1, 3, T.DOOR);
		g.set(mid - 2, gy - 1, T.BUTTON);
	}
	if (troll === "tiny") {}
}
function generate(world, room) {
	const troll = TROLLS[world]?.[room] ?? "none";
	const trolls = troll === "combo" ? ["combo", TROLLS[world % 17][room]] : [troll];
	const R = mulberry(world * 10007 + room * 9176 + 13);
	const cols = 32 + room * 2 + (world > 10 ? 6 : 0);
	const g = new Grid(cols, 16);
	g.border();
	g.ground();
	const family = (world * 3 + room * 7) % 8;
	const spawn = {
		x: 2,
		y: 12
	};
	let x = 5;
	let y = 14;
	const plats = [];
	const segments = 5 + (room + world) % 4;
	for (let s = 0; s < segments && x < cols - 6; s++) {
		const gap = 2 + (R() * (1 + Math.min(3, world / 5 | 0)) | 0);
		const width = 3 + (R() * 4 | 0);
		const dy = (R() * 5 | 0) - 2;
		y = Math.max(5, Math.min(13, y - dy));
		const pitX = x;
		g.rect(pitX, 14, gap, 1, T.EMPTY);
		if (family === 0 || family === 2 || troll === "spikePop" || world === 2) g.rect(pitX, 14, gap, 1, T.SPIKE_U);
		x += gap;
		const type = troll === "crumble" && s % 2 === 1 ? T.CRUMBLE : troll === "iceBoost" ? T.ICE : troll === "vanishFloor" && s === 1 ? T.VANISH : family === 4 && s % 2 ? T.ONE_WAY : T.SOLID;
		g.rect(x, y, width, 1, type);
		if (type === T.SOLID) g.rect(x, y + 1, width, 14 - y, T.SOLID);
		plats.push({
			x,
			y,
			w: width
		});
		if (R() > .7 && y < 12) g.set(x + 1, y - 1, T.COIN);
		x += width;
	}
	if (family === 1) {
		let sy = 13;
		let sx = 8;
		for (let i = 0; i < 6; i++) {
			g.rect(sx, sy, 2, 1, T.SOLID);
			sx += 3;
			sy -= 1;
			if (sy < 5) break;
		}
	}
	if (family === 5) g.rect(10, 4, cols - 16, 1, T.ONE_WAY);
	if (family === 6) g.rect(6, 14, cols - 12, 1, T.CONV_R);
	if (world === 12 || family === 7) {}
	const last = plats[plats.length - 1];
	const goal = last ? {
		x: Math.min(cols - 3, last.x + last.w - 1),
		y: last.y - 1
	} : {
		x: cols - 3,
		y: 12
	};
	g.set(goal.x, goal.y, T.GOAL);
	if (room >= 4) {
		const c = plats[Math.min(2, plats.length - 1)];
		if (c) g.set(c.x + 1, c.y - 1, T.CHECK);
	}
	for (const tr of trolls) applyTrollTiles(g, tr, R, spawn.x, goal.x);
	if (world === 11 && room % 2 === 0) {
		g.set(goal.x - 4, goal.y, T.FAKE_GOAL);
		g.rect(goal.x - 5, goal.y + 1, 3, 1, T.SOLID);
	}
	const moving = [];
	if (world === 12 || world >= 17 && room % 3 === 1 || family === 7) {
		const mx = 10 + room;
		10 * TILE_SAFE();
		moving.push({
			x: mx * 32,
			y: 288,
			w: 96,
			h: 12,
			x0: mx * 32,
			x1: (mx + 8) * 32,
			y0: 288,
			y1: 288,
			period: 3.2,
			t: 0,
			carry: true
		});
		g.rect(mx, 14, 10, 1, T.SPIKE_U);
	}
	const signs = [];
	if (troll === "lyingSign" || world === 8 || world === 0) {
		const lies = [
			{
				ar: "الباب على اليسار",
				en: "The door is to the left"
			},
			{
				ar: "لا تقفز هنا",
				en: "Do not jump here"
			},
			{
				ar: "الإبر زينة",
				en: "The spikes are decor"
			},
			{
				ar: "الأرض ثابتة",
				en: "The floor is stable"
			},
			{
				ar: "اعكس الاتجاه",
				en: "Reverse direction"
			}
		];
		const lie = lies[(world + room) % lies.length];
		signs.push({
			x: spawn.x + 4,
			y: spawn.y - 2,
			...lie
		});
	}
	return finish(g, world, room, trolls, spawn, goal, signs, moving);
}
function TILE_SAFE() {
	return 32;
}
function getLevel(world, room) {
	const w = Math.max(0, Math.min(19, world | 0));
	const r = Math.max(0, Math.min(9, room | 0));
	if (w === 0) return parseAscii(TUTORIAL[r], 0, r, TROLLS[0][r] === "combo" ? ["combo"] : [TROLLS[0][r]], TUTORIAL_SIGNS[r]);
	return generate(w, r);
}
function tileSolid(t, falling, fromAbove, reveal = false) {
	switch (t) {
		case T.SOLID:
		case T.CRUMBLE:
		case T.ICE:
		case T.BOUNCE:
		case T.SPRING:
		case T.CONV_L:
		case T.CONV_R:
		case T.VANISH:
		case T.DOOR: return true;
		case T.INVIS: return true;
		case T.ONE_WAY: return falling && fromAbove;
		case T.FAKE_SOLID: return false;
		default: return false;
	}
}
function looksSolid(t, hint) {
	if (t === T.FAKE_SOLID) return !hint;
	if (t === T.INVIS) return hint;
	if (t === T.FAKE_GOAL || t === T.GOAL) return false;
	return tileSolid(t, true, true) || t === T.SPIKE_U || t === T.HIDDEN_SPIKE;
}
var WORLDS_META = [
	{
		nameAr: "العتبة",
		nameEn: "Threshold",
		tagAr: "يبدو سهلاً",
		tagEn: "Looks easy"
	},
	{
		nameAr: "الغبار",
		nameEn: "Dust",
		tagAr: "الأرض لا تثبت",
		tagEn: "Floors forget you"
	},
	{
		nameAr: "الإبر",
		nameEn: "Needles",
		tagAr: "كل شيء يطعن",
		tagEn: "Everything bites"
	},
	{
		nameAr: "المرآة",
		nameEn: "Mirror",
		tagAr: "يدك تكذب",
		tagEn: "Your hands lie"
	},
	{
		nameAr: "الشبح",
		nameEn: "Phantom",
		tagAr: "ما تراه ليس هناك",
		tagEn: "Seen, not there"
	},
	{
		nameAr: "القلب",
		nameEn: "Heart",
		tagAr: "الجذب ينعكس",
		tagEn: "Pull reverses"
	},
	{
		nameAr: "الاندفاع",
		nameEn: "Rush",
		tagAr: "أسرع من فكرك",
		tagEn: "Faster than thought"
	},
	{
		nameAr: "القزم",
		nameEn: "Wane",
		tagAr: "تصغر ثم تسقط",
		tagEn: "Smaller, then gone"
	},
	{
		nameAr: "الهمس",
		nameEn: "Whisper",
		tagAr: "اللافتات تكذب",
		tagEn: "The signs lie"
	},
	{
		nameAr: "النبض",
		nameEn: "Pulse",
		tagAr: "التوقيت هو الفخ",
		tagEn: "Timing is the trap"
	},
	{
		nameAr: "الجوف",
		nameEn: "Hollow",
		tagAr: "النور بخيل",
		tagEn: "Light is stingy"
	},
	{
		nameAr: "التوأم",
		nameEn: "Twin",
		tagAr: "بابان، موت واحد",
		tagEn: "Two doors, one death"
	},
	{
		nameAr: "الانجراف",
		nameEn: "Drift",
		tagAr: "الأرض تمشي",
		tagEn: "The floor walks"
	},
	{
		nameAr: "الربط",
		nameEn: "Bind",
		tagAr: "نقل بلا إذن",
		tagEn: "Moved without asking"
	},
	{
		nameAr: "الريح",
		nameEn: "Gale",
		tagAr: "الهواء يدفع",
		tagEn: "Air shoves"
	},
	{
		nameAr: "الساعة",
		nameEn: "Clock",
		tagAr: "القاع يصعد",
		tagEn: "The floor rises"
	},
	{
		nameAr: "الزجاج",
		nameEn: "Glass",
		tagAr: "جدران عمياء",
		tagEn: "Blind walls"
	},
	{
		nameAr: "الجوقة",
		nameEn: "Choir",
		tagAr: "كل الأكاذيب معاً",
		tagEn: "Every lie at once"
	},
	{
		nameAr: "العرش",
		nameEn: "Throne",
		tagAr: "المعماري يلعب",
		tagEn: "The architect plays"
	},
	{
		nameAr: "البوابة",
		nameEn: "Gate",
		tagAr: "آخر كذبة",
		tagEn: "The last lie"
	}
];
var UI = {
	title: {
		ar: "برج الخداع",
		en: "Trickspire"
	},
	tag: {
		ar: "البرج يكذب. لا تثق بالأرض.",
		en: "The tower lies. Trust nothing."
	},
	play: {
		ar: "ابدأ التسلق",
		en: "Begin the climb"
	},
	continue: {
		ar: "تابع",
		en: "Continue"
	},
	worlds: {
		ar: "العوالم",
		en: "Worlds"
	},
	shop: {
		ar: "المتجر",
		en: "Shop"
	},
	settings: {
		ar: "الإعدادات",
		en: "Settings"
	},
	how: {
		ar: "كيف تلعب",
		en: "How to play"
	},
	install: {
		ar: "تثبيت على الجهاز",
		en: "Install on device"
	},
	pause: {
		ar: "إيقاف",
		en: "Pause"
	},
	resume: {
		ar: "متابعة",
		en: "Resume"
	},
	retry: {
		ar: "إعادة الغرفة",
		en: "Retry room"
	},
	menu: {
		ar: "القائمة",
		en: "Menu"
	},
	souls: {
		ar: "أرواح",
		en: "Souls"
	},
	coins: {
		ar: "عملات",
		en: "Coins"
	},
	room: {
		ar: "غرفة",
		en: "Room"
	},
	world: {
		ar: "عالم",
		en: "World"
	},
	locked: {
		ar: "مقفل",
		en: "Locked"
	},
	dead: {
		ar: "سقطت",
		en: "You fell"
	},
	soulsLeft: {
		ar: "أرواح متبقية",
		en: "souls left"
	},
	worldFail: {
		ar: "نفدت الأرواح",
		en: "Souls exhausted"
	},
	worldFailBody: {
		ar: "تعود إلى بداية هذا العالم. عشر أرواح جديدة.",
		en: "Back to the start of this world. Ten fresh souls."
	},
	restartWorld: {
		ar: "من البداية",
		en: "Start over"
	},
	watchContinue: {
		ar: "شاهد إعلاناً وتابع بثلاث أرواح",
		en: "Watch an ad, continue with 3 souls"
	},
	roomClear: {
		ar: "الغرفة صمدت",
		en: "The room held"
	},
	worldClear: {
		ar: "العالم يسقط خلفك",
		en: "The world falls behind"
	},
	next: {
		ar: "التالي",
		en: "Next"
	},
	skipAd: {
		ar: "تخطي",
		en: "Skip"
	},
	rewarded: {
		ar: "مكافأة",
		en: "Reward"
	},
	extraSoul: {
		ar: "روح إضافية",
		en: "Extra soul"
	},
	extraCoins: {
		ar: "٢٥ عملة",
		en: "25 coins"
	},
	skipRoom: {
		ar: "تجاوز الغرفة",
		en: "Skip room"
	},
	buySoul: {
		ar: "روح +١",
		en: "Soul +1"
	},
	buySouls3: {
		ar: "ثلاث أرواح",
		en: "Three souls"
	},
	refill: {
		ar: "املأ الأرواح",
		en: "Refill souls"
	},
	removeAds: {
		ar: "أزل الإعلانات",
		en: "Remove ads"
	},
	hint: {
		ar: "كشف الأفخاخ ٨ ثوانٍ",
		en: "Reveal traps for 8s"
	},
	watchCoins: {
		ar: "شاهد إعلاناً لـ ٢٥ عملة",
		en: "Watch ad for 25 coins"
	},
	owned: {
		ar: "تم الشراء",
		en: "Owned"
	},
	needCoins: {
		ar: "عملات غير كافية",
		en: "Not enough coins"
	},
	sfx: {
		ar: "المؤثرات",
		en: "Sound"
	},
	music: {
		ar: "الموسيقى",
		en: "Music"
	},
	shake: {
		ar: "اهتزاز الشاشة",
		en: "Screen shake"
	},
	lang: {
		ar: "اللغة",
		en: "Language"
	},
	reset: {
		ar: "مسح التقدم",
		en: "Reset progress"
	},
	confirmReset: {
		ar: "حذف كل التقدم؟",
		en: "Erase all progress?"
	},
	howBody: {
		ar: "تحرك بـ A/D أو الأسهم. اقفز بمسافة أو زر القفز. عشر أرواح. الموت يعيدك لآخر نقطة حفظ. إذا نفدت الأرواح تعود لبداية العالم. اللافتات تكذب أحياناً. الأبواب تكذب أحياناً. الأرض تكذب دائماً تقريباً.",
		en: "Move with A/D or arrows. Jump with Space or the jump button. Ten souls. Death returns you to the last checkpoint. Empty souls reset the world. Signs lie sometimes. Doors lie sometimes. The floor almost always lies."
	},
	installBody: {
		ar: "Trickspire تطبيق ويب يعمل على الهاتف والكمبيوتر ويمكن تثبيته على الشاشة الرئيسية كبرنامج مستقل. يعمل أونلاين ويحفظ تقدمك على جهازك. ملف APK لمتجر جوجل يحتاج حساب مطور وتوقيع خارج هذه المنصة — ثبّت اللعبة من المتصفح وستعمل كتطبيق كامل.",
		en: "Trickspire is a web app that runs on phone and desktop and can be installed to your home screen as a standalone app. It works online and saves progress on your device. A Play Store APK needs a developer account and signing outside this platform — install from the browser and it plays as a full app."
	},
	installNow: {
		ar: "تثبيت",
		en: "Install"
	},
	adLabel: {
		ar: "إعلان",
		en: "Ad"
	},
	sponsor: {
		ar: "مساحة إعلانية",
		en: "Sponsored space"
	},
	jump: {
		ar: "قفز",
		en: "Jump"
	},
	back: {
		ar: "رجوع",
		en: "Back"
	},
	cleared: {
		ar: "مكتمل",
		en: "Cleared"
	}
};
function t(key, lang) {
	const entry = UI[key];
	if (typeof entry === "object" && entry && "ar" in entry) return lang === "ar" ? entry.ar : entry.en;
	return String(entry);
}
var PALETTES = [
	{
		sky: ["#16121c", "#2a2434"],
		solid: "#3a3344",
		solidHi: "#524a5c",
		accent: "#c4b8a8",
		fog: "rgba(12,10,14,0.35)"
	},
	{
		sky: ["#1c1610", "#3a2a1c"],
		solid: "#5a4636",
		solidHi: "#7a6250",
		accent: "#d4b496",
		fog: "rgba(28,20,12,0.4)"
	},
	{
		sky: ["#140c12", "#2c1420"],
		solid: "#4a3038",
		solidHi: "#6a4850",
		accent: "#d08080",
		fog: "rgba(20,8,12,0.4)"
	},
	{
		sky: ["#10141c", "#1c2838"],
		solid: "#344056",
		solidHi: "#4c5c74",
		accent: "#a8c4d4",
		fog: "rgba(8,12,20,0.4)"
	},
	{
		sky: ["#101018", "#201c2c"],
		solid: "#38344c",
		solidHi: "#504868",
		accent: "#b8a8d0",
		fog: "rgba(10,8,18,0.5)"
	},
	{
		sky: ["#0c1414", "#183030"],
		solid: "#2c4844",
		solidHi: "#3c645c",
		accent: "#80c4b0",
		fog: "rgba(6,16,16,0.4)"
	},
	{
		sky: ["#1c100c", "#3c2414"],
		solid: "#5c3c28",
		solidHi: "#7c5840",
		accent: "#e0a070",
		fog: "rgba(24,12,8,0.4)"
	},
	{
		sky: ["#141018", "#2c2030"],
		solid: "#443850",
		solidHi: "#5c4c68",
		accent: "#d8b0c8",
		fog: "rgba(16,10,18,0.4)"
	},
	{
		sky: ["#12100c", "#2c281c"],
		solid: "#4a4434",
		solidHi: "#68604c",
		accent: "#c8c094",
		fog: "rgba(14,12,8,0.4)"
	},
	{
		sky: ["#140c18", "#301428"],
		solid: "#4c2844",
		solidHi: "#6c4060",
		accent: "#e090b0",
		fog: "rgba(18,8,16,0.4)"
	},
	{
		sky: ["#08080c", "#101018"],
		solid: "#242430",
		solidHi: "#383848",
		accent: "#888898",
		fog: "rgba(4,4,8,0.55)"
	},
	{
		sky: ["#180c0c", "#301818"],
		solid: "#4c3030",
		solidHi: "#6c4848",
		accent: "#e0a0a0",
		fog: "rgba(20,8,8,0.4)"
	},
	{
		sky: ["#0c141c", "#183040"],
		solid: "#2c4458",
		solidHi: "#3c5c74",
		accent: "#90c0d8",
		fog: "rgba(6,14,20,0.4)"
	},
	{
		sky: ["#100c1c", "#241838"],
		solid: "#3c3060",
		solidHi: "#544878",
		accent: "#b8a0e0",
		fog: "rgba(10,8,22,0.45)"
	},
	{
		sky: ["#0c1814", "#1c3830"],
		solid: "#2c5448",
		solidHi: "#3c7060",
		accent: "#90d8b8",
		fog: "rgba(6,18,14,0.4)"
	},
	{
		sky: ["#1c1408", "#3c2c10"],
		solid: "#5c4820",
		solidHi: "#7c6430",
		accent: "#e0c060",
		fog: "rgba(22,16,6,0.4)"
	},
	{
		sky: ["#14181c", "#2c343c"],
		solid: "#485058",
		solidHi: "#687078",
		accent: "#d0d8e0",
		fog: "rgba(12,14,16,0.45)"
	},
	{
		sky: ["#180c14", "#341828"],
		solid: "#503044",
		solidHi: "#704860",
		accent: "#e0a0c0",
		fog: "rgba(18,8,14,0.4)"
	},
	{
		sky: ["#0c0c10", "#1c1828"],
		solid: "#343044",
		solidHi: "#4c4860",
		accent: "#c0b8d0",
		fog: "rgba(8,8,12,0.5)"
	},
	{
		sky: ["#100808", "#280c10"],
		solid: "#441820",
		solidHi: "#642830",
		accent: "#e07070",
		fog: "rgba(16,4,6,0.5)"
	}
];
var WORLDS_INFO = WORLDS_META.map((m, i) => ({
	id: i,
	nameAr: m.nameAr,
	nameEn: m.nameEn,
	tagAr: m.tagAr,
	tagEn: m.tagEn,
	...PALETTES[i]
}));
function hash(x, y) {
	return Math.abs(Math.sin(x * 127.1 + y * 311.7) * 43758.5453) % 1;
}
function drawWorld(ctx, level, camX, camY, t, hint, doorOpen, lavaY, particles, player, sprites, shake, flip, mirror, darkness) {
	const theme = WORLDS_INFO[level.world];
	ctx.save();
	ctx.fillStyle = theme.sky[1];
	ctx.fillRect(0, 0, 960, 540);
	const sky = ctx.createLinearGradient(0, 0, 0, 540);
	sky.addColorStop(0, theme.sky[0]);
	sky.addColorStop(1, theme.sky[1]);
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, 960, 540);
	ctx.save();
	ctx.translate(480, 270);
	if (flip) ctx.scale(1, -1);
	if (mirror) ctx.scale(-1, 1);
	ctx.translate(-480, -270);
	ctx.translate(-camX + shake.x, -camY + shake.y);
	ctx.globalAlpha = .35;
	for (let i = 0; i < 8; i++) {
		const tx = i * 220 - camX * .15 % 220;
		const th = 180 + i * 73 % 160;
		ctx.fillStyle = theme.solid;
		ctx.fillRect(tx + camX * .15, level.rows * 32 - th - 40, 70 + i % 3 * 18, th);
		ctx.fillRect(tx + 20 + camX * .15, level.rows * 32 - th - 80, 16, 50);
	}
	ctx.globalAlpha = 1;
	const x0 = Math.max(0, Math.floor(camX / 32) - 1);
	const y0 = Math.max(0, Math.floor(camY / 32) - 1);
	const x1 = Math.min(level.cols, Math.ceil((camX + 960) / 32) + 1);
	const y1 = Math.min(level.rows, Math.ceil((camY + 540) / 32) + 1);
	for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
		const tile = level.tiles[y * level.cols + x];
		drawTile(ctx, tile, x, y, theme, t, hint, doorOpen);
	}
	for (const m of level.moving) {
		ctx.fillStyle = theme.solidHi;
		roundRect(ctx, m.x, m.y, m.w, m.h, 4);
		ctx.fill();
		ctx.fillStyle = theme.accent;
		ctx.globalAlpha = .35;
		ctx.fillRect(m.x + 4, m.y + 2, m.w - 8, 3);
		ctx.globalAlpha = 1;
	}
	for (const s of level.signs) {
		ctx.fillStyle = "#2a241c";
		ctx.fillRect(s.x * 32 + 6, s.y * 32 + 4, 20, 24);
		ctx.strokeStyle = theme.accent;
		ctx.lineWidth = 1;
		ctx.strokeRect(s.x * 32 + 6.5, s.y * 32 + 4.5, 19, 23);
	}
	if (level.risingLava) {
		ctx.fillStyle = "rgba(180, 36, 48, 0.78)";
		ctx.fillRect(0, lavaY, level.cols * 32, level.rows * 32);
		ctx.fillStyle = "rgba(232, 120, 80, 0.5)";
		ctx.fillRect(0, lavaY, level.cols * 32, 6);
	}
	for (const p of particles) {
		ctx.globalAlpha = Math.max(0, p.life / p.max);
		ctx.fillStyle = p.color;
		ctx.fillRect(p.x, p.y, p.size, p.size);
	}
	ctx.globalAlpha = 1;
	drawPlayer(ctx, player, sprites, t);
	ctx.restore();
	if (darkness) {
		const px = player.x + player.w / 2 - camX + shake.x;
		const py = player.y + player.h / 2 - camY + shake.y;
		const g = ctx.createRadialGradient(px, py, 28, px, py, 160);
		g.addColorStop(0, "rgba(0,0,0,0)");
		g.addColorStop(.45, "rgba(0,0,0,0.15)");
		g.addColorStop(1, "rgba(0,0,0,0.88)");
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, 960, 540);
	}
	ctx.fillStyle = theme.fog;
	ctx.fillRect(0, 0, 960, 540);
	ctx.restore();
}
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
}
function drawTile(ctx, tile, x, y, theme, t, hint, doorOpen) {
	const px = x * 32;
	const py = y * 32;
	const solidLook = looksSolid(tile, hint);
	if (tile === T.EMPTY || tile === T.SPAWN) return;
	if (tile === T.FAKE_SOLID && hint) {
		ctx.fillStyle = "rgba(180,36,48,0.35)";
		ctx.fillRect(px, py, 32, 32);
		return;
	}
	if (tile === T.INVIS && !hint) return;
	if (tile === T.INVIS && hint) {
		ctx.strokeStyle = "rgba(232,224,212,0.5)";
		ctx.strokeRect(px + 1, py + 1, 30, 30);
		return;
	}
	if (tile === T.SOLID || tile === T.CRUMBLE || tile === T.VANISH || tile === T.FAKE_SOLID || tile === T.ICE || tile === T.CONV_L || tile === T.CONV_R || tile === T.ONE_WAY || tile === T.BOUNCE || tile === T.SPRING) {
		if (!solidLook && tile === T.ONE_WAY) {
			ctx.fillStyle = theme.accent;
			ctx.globalAlpha = .5;
			ctx.fillRect(px, py, 32, 6);
			ctx.globalAlpha = 1;
			return;
		}
		ctx.fillStyle = tile === T.ICE ? "#7aa0b8" : tile === T.CRUMBLE || tile === T.VANISH ? theme.solidHi : theme.solid;
		ctx.fillRect(px, py, 32, 32);
		const v = hash(x, y);
		ctx.fillStyle = theme.solidHi;
		ctx.globalAlpha = .25 + v * .2;
		ctx.fillRect(px + 2, py + 2, 28, 4);
		ctx.globalAlpha = 1;
		ctx.strokeStyle = "rgba(0,0,0,0.35)";
		ctx.strokeRect(px + .5, py + .5, 31, 31);
		if (tile === T.CRUMBLE) {
			ctx.strokeStyle = "rgba(0,0,0,0.45)";
			ctx.beginPath();
			ctx.moveTo(px + 6, py + 10);
			ctx.lineTo(px + 18, py + 22);
			ctx.stroke();
		}
		if (tile === T.CONV_R || tile === T.CONV_L) {
			ctx.fillStyle = theme.accent;
			const dir = tile === T.CONV_R ? 1 : -1;
			const ox = t * 40 * dir % 12;
			ctx.fillRect(px + 8 + ox, py + 12, 8, 3);
		}
		if (tile === T.SPRING || tile === T.BOUNCE) {
			ctx.fillStyle = theme.accent;
			ctx.fillRect(px + 8, py + 8, 16, 6);
		}
		return;
	}
	if (tile === T.SPIKE_U || tile === T.HIDDEN_SPIKE || tile === T.SPIKE_POP) {
		if (tile === T.HIDDEN_SPIKE && !hint) return;
		if (tile === T.SPIKE_POP && !hint) {
			ctx.fillStyle = "rgba(180,36,48,0.15)";
			ctx.fillRect(px + 8, py + 24, 16, 4);
			return;
		}
		drawSpike(ctx, px, py, theme.accent);
		return;
	}
	if (tile === T.SPIKE_D) {
		ctx.save();
		ctx.translate(px + 16, py + 16);
		ctx.rotate(Math.PI);
		ctx.translate(-16, -16);
		drawSpike(ctx, 0, 0, theme.accent);
		ctx.restore();
		return;
	}
	if (tile === T.LAVA) {
		ctx.fillStyle = "#b4233a";
		ctx.fillRect(px, py, 32, 32);
		return;
	}
	if (tile === T.COIN) {
		ctx.fillStyle = theme.accent;
		ctx.beginPath();
		ctx.arc(px + 16, py + 16, 6 + Math.sin(t * 6 + x) * 1, 0, Math.PI * 2);
		ctx.fill();
		return;
	}
	if (tile === T.GOAL || tile === T.FAKE_GOAL) {
		const lie = tile === T.FAKE_GOAL && hint;
		ctx.fillStyle = lie ? "#b4233a" : theme.accent;
		ctx.fillRect(px + 4, py + 2, 24, 28);
		ctx.fillStyle = theme.sky[0];
		ctx.beginPath();
		ctx.moveTo(px + 8, py + 18);
		ctx.quadraticCurveTo(px + 16, py + 4, px + 24, py + 18);
		ctx.lineTo(px + 24, py + 28);
		ctx.lineTo(px + 8, py + 28);
		ctx.fill();
		ctx.fillStyle = lie ? "#b4233a" : "#e8c070";
		ctx.globalAlpha = .55 + Math.sin(t * 4) * .2;
		ctx.beginPath();
		ctx.arc(px + 16, py + 16, 5, 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 1;
		return;
	}
	if (tile === T.CHECK || tile === T.FAKE_CHECK) {
		const lie = tile === T.FAKE_CHECK && hint;
		ctx.fillStyle = lie ? "#b4233a" : theme.accent;
		ctx.fillRect(px + 14, py + 8, 4, 20);
		ctx.beginPath();
		ctx.arc(px + 16, py + 10, 7, 0, Math.PI * 2);
		ctx.fillStyle = lie ? "#6e1826" : "#b4233a";
		ctx.fill();
		ctx.fillStyle = "#f0ebe3";
		ctx.globalAlpha = .5 + Math.sin(t * 5) * .3;
		ctx.beginPath();
		ctx.arc(px + 16, py + 10, 3, 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 1;
		return;
	}
	if (tile === T.DOOR) {
		if (doorOpen) return;
		ctx.fillStyle = theme.solidHi;
		ctx.fillRect(px, py, 32, 32);
		ctx.fillStyle = theme.sky[0];
		ctx.fillRect(px + 8, py + 6, 16, 20);
		return;
	}
	if (tile === T.BUTTON) {
		ctx.fillStyle = theme.accent;
		ctx.fillRect(px + 8, py + 22, 16, 6);
		return;
	}
	if (tile === T.TELE_A || tile === T.TELE_B) {
		ctx.strokeStyle = tile === T.TELE_A ? theme.accent : "#b4233a";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(px + 16, py + 16, 8 + Math.sin(t * 5) * 2, 0, Math.PI * 2);
		ctx.stroke();
		return;
	}
}
function drawSpike(ctx, px, py, color) {
	ctx.fillStyle = color;
	ctx.beginPath();
	ctx.moveTo(px + 4, py + 30);
	ctx.lineTo(px + 16, py + 6);
	ctx.lineTo(px + 28, py + 30);
	ctx.closePath();
	ctx.fill();
	ctx.fillStyle = "rgba(0,0,0,0.35)";
	ctx.beginPath();
	ctx.moveTo(px + 16, py + 6);
	ctx.lineTo(px + 22, py + 30);
	ctx.lineTo(px + 16, py + 30);
	ctx.fill();
}
function drawPlayer(ctx, p, sprites, time) {
	const sheet = sprites[p.anim] ?? sprites.idle;
	const dw = 36 * p.scale * (1 + p.squish * .15);
	const dh = 44 * p.scale * (1 - p.squish * .2);
	const dx = p.x + p.w / 2 - dw / 2;
	const dy = p.y + p.h - dh + 2;
	ctx.save();
	if (p.flash > 0 && Math.floor(time * 20) % 2 === 0) ctx.globalAlpha = .45;
	if (sheet && sheet.complete && sheet.naturalWidth > 0) {
		const fw = sheet.naturalWidth / 2;
		const fh = sheet.naturalHeight / 2;
		const col = p.frame % 2;
		const row = Math.floor(p.frame / 2) % 2;
		ctx.translate(dx + dw / 2, dy + dh / 2);
		ctx.scale(p.facing, 1);
		ctx.drawImage(sheet, col * fw, row * fh, fw, fh, -dw / 2, -dh / 2, dw, dh);
	} else {
		ctx.translate(dx + dw / 2, dy + dh / 2);
		ctx.scale(p.facing, 1);
		ctx.fillStyle = "#2a262c";
		ctx.fillRect(-dw / 2, -dh / 2 + 6, dw, dh - 8);
		ctx.fillStyle = "#f0ebe3";
		ctx.beginPath();
		ctx.ellipse(0, -dh / 2 + 12, 7, 8, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = "#0a090c";
		ctx.fillRect(-3, -dh / 2 + 10, 2, 5);
		ctx.fillRect(2, -dh / 2 + 10, 2, 5);
		ctx.fillStyle = "#b4233a";
		ctx.beginPath();
		ctx.arc(dw / 2 - 6, 4, 3, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.restore();
}
function loadSprites() {
	const load = (src) => {
		const img = new Image();
		img.src = src;
		return img;
	};
	return {
		idle: load("/sprites/wick-idle.png"),
		run: load("/sprites/wick-run.png"),
		jump: load("/sprites/wick-jump.png"),
		hurt: load("/sprites/wick-hurt.png")
	};
}
var bus = null;
function ensure(gesture = false) {
	if (bus) {
		if (gesture && bus.ctx.state === "suspended") bus.ctx.resume();
		return bus;
	}
	if (!gesture) return null;
	const ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
	const master = ctx.createGain();
	const sfx = ctx.createGain();
	const music = ctx.createGain();
	sfx.connect(master);
	music.connect(master);
	master.connect(ctx.destination);
	master.gain.value = .85;
	sfx.gain.value = .7;
	music.gain.value = .22;
	bus = {
		ctx,
		master,
		sfx,
		music
	};
	return bus;
}
function unlockAudio() {
	ensure(true);
}
function setVolumes(sfx, music, muted = false) {
	const b = ensure(true);
	if (!b) return;
	const m = muted ? 0 : 1;
	b.sfx.gain.setTargetAtTime(sfx * sfx * m, b.ctx.currentTime, .03);
	b.music.gain.setTargetAtTime(music * music * m * .28, b.ctx.currentTime, .03);
}
function beep(freq, dur, type, gain = .12, slide = 0) {
	const b = bus;
	if (!b) return;
	const t = b.ctx.currentTime;
	const o = b.ctx.createOscillator();
	const g = b.ctx.createGain();
	o.type = type;
	o.frequency.setValueAtTime(freq, t);
	if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
	g.gain.setValueAtTime(gain, t);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	o.connect(g);
	g.connect(b.sfx);
	o.start(t);
	o.stop(t + dur + .02);
}
function noise(dur, gain = .08, hp = 400) {
	const b = bus;
	if (!b) return;
	const n = b.ctx.createBuffer(1, b.ctx.sampleRate * dur | 0, b.ctx.sampleRate);
	const d = n.getChannelData(0);
	for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
	const src = b.ctx.createBufferSource();
	src.buffer = n;
	const f = b.ctx.createBiquadFilter();
	f.type = "highpass";
	f.frequency.value = hp;
	const g = b.ctx.createGain();
	const t = b.ctx.currentTime;
	g.gain.setValueAtTime(gain, t);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	src.connect(f);
	f.connect(g);
	g.connect(b.sfx);
	src.start();
}
var sfx = {
	jump: () => beep(420 + Math.random() * 40, .09, "square", .07, -180),
	land: () => noise(.08, .06, 200),
	death: () => {
		beep(220, .28, "sawtooth", .1, -160);
		noise(.2, .08, 120);
	},
	coin: () => {
		beep(880, .07, "square", .06);
		beep(1320, .1, "square", .05);
	},
	check: () => {
		beep(523, .1, "triangle", .07);
		beep(784, .16, "triangle", .05);
	},
	goal: () => {
		beep(392, .12, "triangle", .08);
		beep(523, .14, "triangle", .07);
		beep(784, .22, "triangle", .06);
	},
	crumble: () => noise(.14, .05, 80),
	click: () => beep(660, .04, "square", .04)
};
var musicOn = false;
function startMusic() {
	if (!ensure(true) || musicOn) return;
	musicOn = true;
	const notes = [
		110,
		130.8,
		146.8,
		164.8,
		110,
		98,
		87.3,
		110
	];
	let i = 0;
	const tick = () => {
		if (!musicOn || !bus) return;
		const n = notes[i % notes.length];
		const t = bus.ctx.currentTime;
		const o = bus.ctx.createOscillator();
		const g = bus.ctx.createGain();
		o.type = "sine";
		o.frequency.value = n;
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(.09, t + .05);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .7);
		o.connect(g);
		g.connect(bus.music);
		o.start(t);
		o.stop(t + .75);
		if (i % 4 === 0) {
			const o2 = bus.ctx.createOscillator();
			const g2 = bus.ctx.createGain();
			o2.type = "triangle";
			o2.frequency.value = n * 2;
			g2.gain.setValueAtTime(.03, t);
			g2.gain.exponentialRampToValueAtTime(1e-4, t + .4);
			o2.connect(g2);
			g2.connect(bus.music);
			o2.start(t);
			o2.stop(t + .45);
		}
		i++;
		window.setTimeout(tick, 520);
	};
	tick();
}
function resumeAudio() {
	if (bus?.ctx.state === "suspended") bus.ctx.resume();
}
var MOVE_ACCEL = 2100;
var MOVE_MAX = 230;
var AIR_ACCEL = 1500;
var FRICTION = 1900;
var ICE_FRICTION = 240;
var GRAV_UP = 1250;
var GRAV_DOWN = 2500;
var JUMP_V = -560;
var COYOTE = .1;
var BUFFER = .12;
var TERMINAL = 640;
var PLAYER_W = 14;
var PLAYER_H = 20;
var TrickspireGame = class {
	canvas;
	ctx;
	input = new Input();
	hooks;
	level;
	player;
	sprites;
	camX = 0;
	camY = 0;
	acc = 0;
	last = 0;
	raf = 0;
	running = false;
	paused = false;
	souls = 10;
	coins = 0;
	roomCoins = 0;
	deaths = 0;
	world = 0;
	room = 0;
	checkpoint = {
		x: 0,
		y: 0
	};
	particles = [];
	trauma = 0;
	time = 0;
	crumble = /* @__PURE__ */ new Map();
	popped = /* @__PURE__ */ new Set();
	vanished = false;
	lavaY = 0;
	doorOpen = false;
	hintT = 0;
	lieWinT = 0;
	shakeOn = true;
	lang = "ar";
	teleCool = 0;
	signAr = null;
	signEn = null;
	hudT = 0;
	freezeT = 0;
	constructor(canvas, hooks) {
		this.canvas = canvas;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("No 2d context");
		this.ctx = ctx;
		this.hooks = hooks;
		this.sprites = loadSprites();
		this.input.attach(canvas);
		this.fit();
		window.addEventListener("resize", this.fit);
		this.wireControlsTest();
	}
	fit = () => {
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		this.canvas.width = 960 * dpr;
		this.canvas.height = 540 * dpr;
		this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	};
	start(world, room, souls, coins) {
		this.world = world;
		this.room = room;
		this.souls = souls;
		this.coins = coins;
		this.roomCoins = 0;
		this.level = getLevel(world, room);
		this.spawnAt(this.level.spawn.x, this.level.spawn.y, true);
		this.checkpoint = { ...this.level.spawn };
		this.camX = this.player.x + this.player.w / 2 - 480;
		this.camY = this.player.y + this.player.h / 2 - 270;
		this.lavaY = this.level.rows * 32;
		this.vanished = false;
		this.doorOpen = false;
		this.crumble.clear();
		this.popped.clear();
		this.lieWinT = 0;
		this.time = 0;
		this.running = true;
		this.paused = false;
		this.last = performance.now();
		this.acc = 0;
		cancelAnimationFrame(this.raf);
		this.raf = requestAnimationFrame(this.loop);
		this.emitHud();
	}
	spawnAt(tx, ty, resetVel) {
		const scale = this.level.shrink ? .58 : 1;
		this.player = {
			x: tx * 32 + (32 - PLAYER_W * scale) / 2,
			y: ty * 32 + 32 - PLAYER_H * scale - 1,
			vx: resetVel ? 0 : this.player?.vx ?? 0,
			vy: 0,
			w: PLAYER_W * scale,
			h: PLAYER_H * scale,
			facing: 1,
			grounded: false,
			coyote: 0,
			buffer: 0,
			scale,
			dead: false,
			squish: 0,
			anim: "idle",
			frame: 0,
			frameT: 0,
			flash: 0,
			jumps: 0,
			onIce: false,
			riding: -1
		};
	}
	setPaused(v) {
		this.paused = v;
	}
	setHint(seconds) {
		this.hintT = seconds;
	}
	destroy() {
		this.running = false;
		cancelAnimationFrame(this.raf);
		this.input.detach();
		window.removeEventListener("resize", this.fit);
		if (window.__controlsTest) delete window.__controlsTest;
	}
	loop = (now) => {
		if (!this.running) return;
		this.raf = requestAnimationFrame(this.loop);
		let dt = (now - this.last) / 1e3;
		this.last = now;
		if (dt > .1) dt = .1;
		if (this.paused) {
			this.draw();
			return;
		}
		this.acc += dt;
		while (this.acc >= FIXED_DT) {
			this.step(FIXED_DT);
			this.acc -= FIXED_DT;
		}
		this.draw();
	};
	step(dt) {
		this.time += dt;
		if (this.freezeT > 0) {
			this.freezeT -= dt;
			return;
		}
		if (this.lieWinT > 0) {
			this.lieWinT -= dt;
			if (this.lieWinT <= 0) this.kill();
			return;
		}
		if (this.player.dead) return;
		if (this.input.pauseQueued) {
			this.input.pauseQueued = false;
			this.hooks.onHud({
				...this.hudSnap(),
				paused: true
			});
		}
		const act = this.input.sample(this.level.reverse, this.level.swapLR);
		const p = this.player;
		if (act.jump) p.buffer = BUFFER;
		p.buffer = Math.max(0, p.buffer - dt);
		p.coyote = Math.max(0, p.coyote - dt);
		p.flash = Math.max(0, p.flash - dt);
		p.squish = Math.max(0, p.squish - dt * 4);
		this.teleCool = Math.max(0, this.teleCool - dt);
		this.hintT = Math.max(0, this.hintT - dt);
		this.trauma = Math.max(0, this.trauma - dt * 1.8);
		const accel = p.grounded ? MOVE_ACCEL : AIR_ACCEL;
		if (act.moveX !== 0) {
			p.vx += act.moveX * accel * dt;
			p.facing = act.moveX > 0 ? 1 : -1;
		} else {
			const max = (p.onIce ? ICE_FRICTION : FRICTION) * dt;
			if (Math.abs(p.vx) <= max) p.vx = 0;
			else p.vx -= Math.sign(p.vx) * max;
		}
		const cap = p.onIce ? MOVE_MAX * 1.35 : MOVE_MAX;
		if (p.vx > cap) p.vx = cap;
		if (p.vx < -cap) p.vx = -cap;
		if (this.level.wind) p.vx += this.level.wind * dt * .35;
		const gravSign = this.level.gravitySign * (this.level.trolls.includes("gravity") && Math.sin(this.time * .7) > .65 ? -1 : 1);
		const g = (p.vy * gravSign < 0 ? GRAV_UP : GRAV_DOWN) * gravSign;
		p.vy += g * dt;
		if (gravSign > 0 && p.vy > TERMINAL) p.vy = TERMINAL;
		if (gravSign < 0 && p.vy < -640) p.vy = -640;
		const canJump = !this.level.lockedJump || this.time > 1.4;
		const jumpV = this.level.jumpCut && p.jumps >= 1 ? JUMP_V * .55 : JUMP_V;
		if (p.buffer > 0 && (p.grounded || p.coyote > 0) && canJump) {
			p.vy = gravSign > 0 ? jumpV : -jumpV;
			p.grounded = false;
			p.coyote = 0;
			p.buffer = 0;
			p.jumps++;
			p.squish = -.4;
			sfx.jump();
			if (this.level.vanishFloor) this.vanished = true;
		}
		if (!act.jumpHeld && (gravSign > 0 && p.vy < 0 || gravSign < 0 && p.vy > 0)) p.vy *= .5;
		this.movePlatforms(dt);
		this.moveAxis(p, p.vx * dt, 0);
		const wasGround = p.grounded;
		p.grounded = false;
		p.onIce = false;
		this.moveAxis(p, 0, p.vy * dt);
		if (p.grounded && !wasGround) {
			p.squish = .45;
			sfx.land();
			this.burst(p.x + p.w / 2, p.y + p.h, 6, "#c4b8a8");
		}
		if (p.grounded) p.coyote = COYOTE;
		this.touchTiles(dt);
		this.anim(dt, act.moveX);
		if (this.level.risingLava) {
			const start = this.level.rows * 32 - 8;
			this.lavaY = start - this.time * (18 + this.room * 2);
			if (p.y + p.h > this.lavaY + 4) this.kill();
		}
		if (this.level.goalRuns) {
			const gx = this.level.goal.x * 32;
			if (Math.abs(p.x - gx) < 90 && this.level.goal.x < this.level.cols - 3) this.level.goal.x += dt * 1.6;
		}
		this.camera(dt);
		this.tickParticles(dt);
		this.hudT += dt;
		if (this.hudT > .12) {
			this.hudT = 0;
			this.emitHud();
		}
		if (p.y > this.level.rows * 32 + 40 || p.y < -80) this.kill();
	}
	movePlatforms(dt) {
		for (const m of this.level.moving) {
			m.t += dt;
			const u = (1 - Math.cos(m.t / m.period * Math.PI * 2)) / 2;
			const nx = m.x0 + (m.x1 - m.x0) * u;
			const ny = m.y0 + (m.y1 - m.y0) * u;
			const dx = nx - m.x;
			const dy = ny - m.y;
			m.x = nx;
			m.y = ny;
			const p = this.player;
			if (p.riding >= 0) {
				p.x += dx;
				p.y += dy;
			}
		}
	}
	moveAxis(p, dx, dy) {
		p.x += dx;
		p.y += dy;
		p.riding = -1;
		const x0 = Math.floor(p.x / 32);
		const y0 = Math.floor(p.y / 32);
		const x1 = Math.floor((p.x + p.w - .001) / 32);
		const y1 = Math.floor((p.y + p.h - .001) / 32);
		const falling = dy > 0;
		for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
			if (tx < 0 || ty < 0 || tx >= this.level.cols || ty >= this.level.rows) {
				if (dx > 0) p.x = tx * 32 - p.w;
				if (dx < 0) p.x = (tx + 1) * 32;
				if (dy > 0) {
					p.y = ty * 32 - p.h;
					p.vy = 0;
					p.grounded = true;
				}
				if (dy < 0) {
					p.y = (ty + 1) * 32;
					p.vy = 0;
				}
				if (dx !== 0) p.vx = 0;
				continue;
			}
			const id = ty * this.level.cols + tx;
			let tile = this.level.tiles[id];
			if (this.vanished && tile === T.VANISH) continue;
			if (this.crumble.get(id) === -1) continue;
			if (tile === T.DOOR && this.doorOpen) continue;
			const top = ty * 32;
			if (!tileSolid(tile, falling, p.y + p.h - dy <= top + 2)) continue;
			const left = tx * 32;
			const right = left + 32;
			const bottom = top + 32;
			if (dx > 0 && p.x + p.w > left && p.x < left) {
				p.x = left - p.w;
				p.vx = 0;
			} else if (dx < 0 && p.x < right && p.x + p.w > right) {
				p.x = right;
				p.vx = 0;
			}
			if (dy > 0 && p.y + p.h > top && p.y < top) {
				p.y = top - p.h;
				p.vy = 0;
				p.grounded = true;
				if (tile === T.ICE || tile === T.CONV_L || tile === T.CONV_R) p.onIce = true;
				if (tile === T.CONV_R) p.vx += 18;
				if (tile === T.CONV_L) p.vx -= 18;
				if (tile === T.SPRING || tile === T.BOUNCE) {
					p.vy = JUMP_V * 1.25;
					p.grounded = false;
				}
				if (tile === T.CRUMBLE || tile === T.VANISH) {
					if (!this.crumble.has(id)) this.crumble.set(id, .32);
				}
			} else if (dy < 0 && p.y < bottom && p.y + p.h > bottom) {
				p.y = bottom;
				p.vy = 0;
			}
		}
		for (let i = 0; i < this.level.moving.length; i++) {
			const m = this.level.moving[i];
			if (dy > 0 && aabb(p.x, p.y, p.w, p.h, m.x, m.y, m.w, m.h) && p.y + p.h - dy <= m.y + 6) {
				p.y = m.y - p.h;
				p.vy = 0;
				p.grounded = true;
				p.riding = i;
			}
		}
	}
	touchTiles(dt) {
		const p = this.player;
		const x0 = Math.floor(p.x / 32);
		const y0 = Math.floor(p.y / 32);
		const x1 = Math.floor((p.x + p.w - .001) / 32);
		const y1 = Math.floor((p.y + p.h - .001) / 32);
		this.signAr = null;
		this.signEn = null;
		for (const s of this.level.signs) if (Math.abs(s.x * 32 - p.x) < 64 && Math.abs(s.y * 32 - p.y) < 64) {
			this.signAr = s.ar;
			this.signEn = s.en;
		}
		for (const [id, t] of [...this.crumble]) {
			const nt = t - dt;
			if (nt <= 0) {
				this.level.tiles[id] = T.EMPTY;
				this.crumble.set(id, -1);
				sfx.crumble();
				this.trauma = Math.min(1, this.trauma + .25);
			} else this.crumble.set(id, nt);
		}
		for (let ty = y0 - 1; ty <= y1 + 1; ty++) for (let tx = x0 - 1; tx <= x1 + 1; tx++) {
			if (tx < 0 || ty < 0 || tx >= this.level.cols || ty >= this.level.rows) continue;
			const id = ty * this.level.cols + tx;
			const tile = this.level.tiles[id];
			const left = tx * 32;
			const top = ty * 32;
			if (tile === T.SPIKE_POP && Math.hypot(p.x - left, p.y - top) < 56) {
				this.popped.add(id);
				this.level.tiles[id] = T.SPIKE_U;
			}
			if (tile === T.HIDDEN_SPIKE && Math.hypot(p.x - left, p.y - top) < 40) this.level.tiles[id] = T.SPIKE_U;
			if (!aabb(p.x + 2, p.y + 2, p.w - 4, p.h - 4, left, top, 32, 32)) continue;
			if (tile === T.SPIKE_U || tile === T.SPIKE_D || tile === T.SPIKE_L || tile === T.SPIKE_R || tile === T.LAVA) {
				this.kill();
				return;
			}
			if (tile === T.FAKE_CHECK) {
				this.kill();
				return;
			}
			if (tile === T.GOAL) {
				this.winRoom();
				return;
			}
			if (tile === T.FAKE_GOAL) {
				if (this.level.fakeWin) {
					this.lieWinT = .9;
					this.trauma = .2;
				} else this.kill();
				return;
			}
			if (tile === T.CHECK) {
				this.checkpoint = {
					x: tx,
					y: ty
				};
				this.level.tiles[id] = T.EMPTY;
				sfx.check();
				this.hooks.onCheckpoint();
				this.burst(left + 16, top + 16, 10, "#b4233a");
			}
			if (tile === T.COIN) {
				this.level.tiles[id] = T.EMPTY;
				this.roomCoins += 1;
				this.coins += 1;
				sfx.coin();
				this.hooks.onCoin(this.coins);
			}
			if (tile === T.BUTTON) this.doorOpen = true;
			if ((tile === T.TELE_A || tile === T.TELE_B) && this.teleCool <= 0) {
				const want = tile === T.TELE_A ? T.TELE_B : T.TELE_A;
				for (let i = 0; i < this.level.tiles.length; i++) if (this.level.tiles[i] === want && i !== id) {
					const nx = i % this.level.cols;
					const ny = i / this.level.cols | 0;
					p.x = nx * 32 + 8;
					p.y = ny * 32 - p.h;
					this.teleCool = .6;
					this.trauma = .3;
					break;
				}
			}
		}
	}
	anim(dt, moveX) {
		const p = this.player;
		let next = "idle";
		if (p.flash > .05) next = "hurt";
		else if (!p.grounded) next = "jump";
		else if (Math.abs(p.vx) > 20 || moveX !== 0) next = "run";
		if (next !== p.anim) {
			p.anim = next;
			p.frame = 0;
			p.frameT = 0;
		}
		p.frameT += dt;
		const sp = p.anim === "run" ? .09 : p.anim === "jump" ? .12 : .18;
		if (p.frameT > sp) {
			p.frameT = 0;
			p.frame = (p.frame + 1) % 4;
			if (p.anim === "jump") p.frame = p.vy < -80 ? 1 : p.vy < 80 ? 2 : 3;
		}
	}
	camera(dt) {
		const p = this.player;
		const look = p.facing * 70;
		const tx = p.x + p.w / 2 - 480 + look;
		const ty = p.y + p.h / 2 - 270 - 20;
		const k = 1 - Math.exp(-6 * dt);
		this.camX += (tx - this.camX) * k;
		this.camY += (ty - this.camY) * k;
		const maxX = Math.max(0, this.level.cols * 32 - 960);
		const maxY = Math.max(0, this.level.rows * 32 - 540);
		this.camX = Math.max(0, Math.min(maxX, this.camX));
		this.camY = Math.max(0, Math.min(maxY, this.camY));
	}
	kill() {
		if (this.player.dead) return;
		this.player.dead = true;
		this.player.anim = "hurt";
		this.souls = Math.max(0, this.souls - 1);
		this.deaths++;
		this.trauma = 1;
		this.freezeT = .08;
		sfx.death();
		this.burst(this.player.x + this.player.w / 2, this.player.y + this.player.h / 2, 16, "#b4233a");
		this.hooks.onDeath(this.souls);
		if (this.souls <= 0) {
			this.hooks.onWorldFail();
			return;
		}
		window.setTimeout(() => {
			if (!this.running) return;
			this.spawnAt(this.checkpoint.x, this.checkpoint.y, true);
			this.player.flash = .8;
			this.lavaY = this.level.rows * 32;
			this.emitHud();
		}, 420);
	}
	winRoom() {
		if (this.player.dead) return;
		this.player.dead = true;
		sfx.goal();
		this.burst(this.player.x, this.player.y, 14, "#e8e0d4");
		const gained = 3 + this.roomCoins + (this.deaths === 0 ? 2 : 0);
		this.coins += 3;
		this.hooks.onRoomClear(gained);
	}
	burst(x, y, n, color) {
		for (let i = 0; i < n; i++) {
			const a = Math.random() * Math.PI * 2;
			const s = 40 + Math.random() * 120;
			this.particles.push({
				x,
				y,
				vx: Math.cos(a) * s,
				vy: Math.sin(a) * s,
				life: .35 + Math.random() * .3,
				max: .6,
				size: 2 + Math.random() * 3,
				color
			});
		}
	}
	tickParticles(dt) {
		for (const p of this.particles) {
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.vy += 400 * dt;
			p.life -= dt;
		}
		this.particles = this.particles.filter((p) => p.life > 0);
	}
	draw() {
		const shake = this.shakeOn ? {
			x: (Math.random() * 2 - 1) * this.trauma * this.trauma * 10,
			y: (Math.random() * 2 - 1) * this.trauma * this.trauma * 8
		} : {
			x: 0,
			y: 0
		};
		drawWorld(this.ctx, this.level, this.camX, this.camY, this.time, this.hintT > 0, this.doorOpen, this.lavaY, this.particles, this.player, this.sprites, shake, this.level.cameraFlip, this.level.mirrorCam, this.level.darkness);
		if (this.lieWinT > 0) {
			this.ctx.fillStyle = "rgba(10,9,12,0.55)";
			this.ctx.fillRect(0, 0, 960, 540);
			this.ctx.fillStyle = "#f0ebe3";
			this.ctx.font = "700 42px Syne, sans-serif";
			this.ctx.textAlign = "center";
			this.ctx.fillText(this.lang === "ar" ? "فزت" : "YOU WIN", 480, 270);
		}
	}
	hudSnap() {
		return {
			souls: this.souls,
			coins: this.coins,
			world: this.world,
			room: this.room,
			signAr: this.signAr,
			signEn: this.signEn,
			deaths: this.deaths,
			paused: this.paused
		};
	}
	emitHud() {
		this.hooks.onHud(this.hudSnap());
	}
	wireControlsTest() {
		window.__controlsTest = {
			getYaw: () => -this.player.x,
			getSpeed: () => Math.hypot(this.player.vx, this.player.vy),
			setKeys: (codes) => this.input.setKeys(codes),
			setSteer: (v) => {
				if (v > .2) this.input.setKeys(["KeyA"]);
				else if (v < -.2) this.input.setKeys(["KeyD"]);
				else this.input.setKeys([]);
			}
		};
	}
};
function aabb(ax, ay, aw, ah, bx, by, bw, bh) {
	return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}
var KEY = "trickspire-save-v1";
var BACKUP = "trickspire-save-bak";
var defaultSave = () => ({
	version: 1,
	unlockedWorld: 0,
	bestRoom: Array.from({ length: 20 }, () => 0),
	souls: 10,
	coins: 0,
	adsRemoved: false,
	currentWorld: 0,
	currentRoom: 0,
	inRun: false,
	deaths: 0,
	roomsCleared: 0,
	settings: {
		sfx: .8,
		music: .55,
		shake: true,
		lang: "ar"
	}
});
function migrate(raw) {
	const d = defaultSave();
	return {
		...d,
		...raw,
		version: 1,
		bestRoom: Array.from({ length: 20 }, (_, i) => raw.bestRoom?.[i] ?? 0),
		settings: {
			...d.settings,
			...raw.settings
		},
		souls: Math.max(0, Math.min(15, raw.souls ?? 10))
	};
}
function loadSave() {
	try {
		const s = localStorage.getItem(KEY);
		if (!s) return defaultSave();
		return migrate(JSON.parse(s));
	} catch {
		try {
			const b = localStorage.getItem(BACKUP);
			if (b) return migrate(JSON.parse(b));
		} catch {}
		return defaultSave();
	}
}
function writeSave(data) {
	try {
		const prev = localStorage.getItem(KEY);
		if (prev) localStorage.setItem(BACKUP, prev);
		localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
}
function markRoomCleared(save, world, room) {
	const best = [...save.bestRoom];
	best[world] = Math.max(best[world] ?? 0, room + 1);
	let unlocked = save.unlockedWorld;
	if (room + 1 >= 10) unlocked = Math.max(unlocked, Math.min(19, world + 1));
	return {
		...save,
		bestRoom: best,
		unlockedWorld: unlocked,
		roomsCleared: save.roomsCleared + 1,
		currentWorld: room + 1 >= 10 ? Math.min(19, world + 1) : world,
		currentRoom: room + 1 >= 10 ? 0 : room + 1,
		inRun: true
	};
}
var useGameStore = create((set, get) => ({
	save: loadSave(),
	screen: "title",
	prevScreen: "title",
	hud: {
		souls: 10,
		coins: 0,
		world: 0,
		room: 0,
		signAr: null,
		signEn: null,
		deaths: 0,
		paused: false
	},
	session: 0,
	playWorld: 0,
	playRoom: 0,
	adKind: null,
	adReturn: "title",
	toast: null,
	persist: () => writeSave(get().save),
	setScreen: (s) => set({
		prevScreen: get().screen,
		screen: s
	}),
	applyHud: (h) => {
		if (h.paused && get().screen === "play") {
			set({
				hud: h,
				screen: "pause"
			});
			return;
		}
		set({
			hud: h,
			save: {
				...get().save,
				souls: h.souls,
				coins: h.coins
			}
		});
	},
	startRun: (world = 0, room = 0) => {
		const save = {
			...get().save,
			currentWorld: world,
			currentRoom: room,
			inRun: true,
			souls: get().save.souls || 10
		};
		if (save.souls <= 0) save.souls = 10;
		set({
			save,
			playWorld: world,
			playRoom: room,
			screen: "play",
			session: get().session + 1,
			hud: {
				...get().hud,
				world,
				room,
				souls: save.souls,
				coins: save.coins,
				deaths: 0
			}
		});
		writeSave(save);
	},
	nextRoom: () => {
		const { playWorld, playRoom, save } = get();
		const next = markRoomCleared(save, playWorld, playRoom);
		if (playRoom + 1 >= 10) {
			set({
				save: {
					...next,
					souls: 10
				},
				screen: "worldClear",
				playWorld: playWorld + 1,
				playRoom: 0
			});
			writeSave({
				...next,
				souls: 10
			});
			return;
		}
		set({
			save: next,
			playRoom: playRoom + 1,
			screen: "roomClear"
		});
		writeSave(next);
	},
	failWorld: () => {
		const save = {
			...get().save,
			souls: 0
		};
		set({
			save,
			screen: "worldFail"
		});
		writeSave(save);
	},
	restartWorld: () => {
		const save = {
			...get().save,
			souls: 10,
			currentRoom: 0
		};
		set({
			save,
			playRoom: 0,
			screen: "play",
			session: get().session + 1
		});
		writeSave(save);
	},
	continueAd: () => {
		const save = {
			...get().save,
			souls: 3
		};
		set({
			save,
			screen: "play",
			session: get().session + 1
		});
		writeSave(save);
	},
	addCoins: (n) => {
		const save = {
			...get().save,
			coins: get().save.coins + n
		};
		set({ save });
		writeSave(save);
	},
	addSouls: (n) => {
		const save = {
			...get().save,
			souls: Math.min(15, get().save.souls + n)
		};
		set({
			save,
			hud: {
				...get().hud,
				souls: save.souls
			}
		});
		writeSave(save);
	},
	buy: (cost, apply) => {
		const { save } = get();
		if (save.coins < cost) return false;
		const next = apply({
			...save,
			coins: save.coins - cost
		});
		set({
			save: next,
			hud: {
				...get().hud,
				coins: next.coins,
				souls: next.souls
			}
		});
		writeSave(next);
		return true;
	},
	watchAd: (kind) => {
		if (get().save.adsRemoved && kind === "interstitial") {
			get().finishAd();
			return;
		}
		set({
			adKind: kind,
			adReturn: get().screen,
			screen: "ad"
		});
	},
	finishAd: () => {
		const kind = get().adKind;
		set({ adKind: null });
		if (kind === "rewarded-soul") {
			get().addSouls(1);
			set({ screen: get().adReturn === "pause" ? "pause" : "play" });
			return;
		}
		if (kind === "rewarded-coins") {
			get().addCoins(25);
			set({ screen: get().adReturn });
			return;
		}
		if (kind === "rewarded-continue") {
			get().continueAd();
			return;
		}
		if (kind === "rewarded-skip") {
			get().nextRoom();
			const st = get();
			if (st.screen === "worldClear") return;
			st.startRun(st.playWorld, st.playRoom);
			return;
		}
		if (kind === "interstitial") {
			const st = get();
			st.startRun(st.playWorld, st.playRoom);
			return;
		}
		set({ screen: get().adReturn });
	},
	setLang: (lang) => {
		const save = {
			...get().save,
			settings: {
				...get().save.settings,
				lang
			}
		};
		set({ save });
		writeSave(save);
	},
	setSetting: (patch) => {
		const save = {
			...get().save,
			settings: {
				...get().save.settings,
				...patch
			}
		};
		set({ save });
		writeSave(save);
	},
	resetAll: () => {
		const save = defaultSave();
		set({
			save,
			screen: "title",
			playWorld: 0,
			playRoom: 0
		});
		writeSave(save);
	},
	setToast: (t) => set({ toast: t })
}));
function GameApp() {
	const screen = useGameStore((s) => s.screen);
	const lang = useGameStore((s) => s.save.settings.lang);
	const dir = lang === "ar" ? "rtl" : "ltr";
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = dir;
	}, [lang, dir]);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.hidden) useGameStore.getState().persist();
			else resumeAudio();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh w-full flex-col overflow-hidden bg-bg text-fg",
		dir,
		children: [
			screen === "play" || screen === "pause" || screen === "roomClear" || screen === "worldFail" || screen === "worldClear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayLayer, {}) : null,
			screen === "title" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, {}),
			screen === "worlds" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldsScreen, {}),
			screen === "shop" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopScreen, {}),
			screen === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {}),
			screen === "how" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowScreen, {}),
			screen === "install" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallScreen, {}),
			screen === "ad" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdScreen, {}),
			screen === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseOverlay, {}),
			screen === "roomClear" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomClearOverlay, {}),
			screen === "worldClear" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldClearOverlay, {}),
			screen === "worldFail" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldFailOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toast, {})
		]
	});
}
function TitleScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const save = useGameStore((s) => s.save);
	const startRun = useGameStore((s) => s.startRun);
	const setScreen = useGameStore((s) => s.setScreen);
	const ads = !save.adsRemoved;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex h-full flex-col items-center justify-between px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 opacity-40",
				style: towerWash()
			}),
			ads && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mt-6 flex w-full max-w-md flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.35em] text-muted uppercase",
						children: "TRICKSPIRE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-5xl font-extrabold leading-tight tracking-tight text-fg",
						children: t("title", lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm leading-relaxed text-muted",
						children: t("tag", lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-subtle",
						children: [
							"20 × 10 · ",
							t("souls", lang),
							" 10"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full max-w-sm flex-col gap-2.5 pb-[max(1rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						className: "h-12 w-full font-display",
						onClick: () => {
							bootAudio();
							startRun(save.inRun ? save.currentWorld : 0, save.inRun ? save.currentRoom : 0);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), save.inRun ? t("continue", lang) : t("play", lang)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full",
						onClick: () => setScreen("worlds"),
						children: t("worlds", lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							onClick: () => setScreen("shop"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-4" }), t("shop", lang)]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							onClick: () => setScreen("install"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), t("install", lang)]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setScreen("how"),
							children: t("how", lang)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							onClick: () => setScreen("settings"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), t("settings", lang)]
						})]
					})
				]
			})
		]
	});
}
function WorldsScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const save = useGameStore((s) => s.save);
	const startRun = useGameStore((s) => s.startRun);
	const setScreen = useGameStore((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col px-4 pt-5 pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: t("worlds", lang),
			onBack: () => setScreen("title")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-2 gap-2 overflow-y-auto pb-8 sm:grid-cols-4",
			children: WORLDS_INFO.map((w) => {
				const locked = w.id > save.unlockedWorld;
				const done = (save.bestRoom[w.id] ?? 0) >= 10;
				const progress = save.bestRoom[w.id] ?? 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					disabled: locked,
					onClick: () => {
						bootAudio();
						startRun(w.id, 0);
					},
					className: cn("rounded-xl border border-border bg-surface p-3 text-start transition-opacity", locked && "opacity-40"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 h-12 rounded-md",
							style: { background: w.sky[1] }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-sm font-semibold",
							children: [
								String(w.id + 1).padStart(2, "0"),
								" · ",
								lang === "ar" ? w.nameAr : w.nameEn
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: lang === "ar" ? w.tagAr : w.tagEn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs tabular-nums text-subtle",
							children: locked ? t("locked", lang) : done ? t("cleared", lang) : `${progress}/10`
						})
					]
				}, w.id);
			})
		})]
	});
}
function ShopScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const save = useGameStore((s) => s.save);
	const buy = useGameStore((s) => s.buy);
	const watchAd = useGameStore((s) => s.watchAd);
	const setScreen = useGameStore((s) => s.setScreen);
	const setToast = useGameStore((s) => s.setToast);
	const tryBuy = (cost, apply, ok) => {
		if (!buy(cost, apply)) setToast(t("needCoins", lang));
		else setToast(ok);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col px-4 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("shop", lang),
				onBack: () => setScreen("title")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center gap-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 tabular-nums",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-4 text-accent" }),
						" ",
						save.coins
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 tabular-nums",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-4 text-soul" }),
						" ",
						save.souls
					]
				})]
			}),
			!save.adsRemoved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopRow, {
						title: t("buySoul", lang),
						price: "30",
						onClick: () => tryBuy(30, (s) => ({
							...s,
							souls: Math.min(15, s.souls + 1)
						}), t("buySoul", lang))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopRow, {
						title: t("buySouls3", lang),
						price: "80",
						onClick: () => tryBuy(80, (s) => ({
							...s,
							souls: Math.min(15, s.souls + 3)
						}), t("buySouls3", lang))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopRow, {
						title: t("refill", lang),
						price: "120",
						onClick: () => tryBuy(120, (s) => ({
							...s,
							souls: 10
						}), t("refill", lang))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopRow, {
						title: t("removeAds", lang),
						price: "500",
						disabled: save.adsRemoved,
						tag: save.adsRemoved ? t("owned", lang) : void 0,
						onClick: () => tryBuy(500, (s) => ({
							...s,
							adsRemoved: true
						}), t("removeAds", lang))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "mt-2",
						onClick: () => watchAd("rewarded-coins"),
						children: t("watchCoins", lang)
					})
				]
			})
		]
	});
}
function ShopRow({ title, price, onClick, disabled, tag }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		disabled,
		onClick,
		className: "flex h-14 items-center justify-between rounded-lg border border-border bg-surface px-4 text-sm disabled:opacity-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums text-muted",
			children: tag ?? price
		})]
	});
}
function SettingsScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const settings = useGameStore((s) => s.save.settings);
	const setSetting = useGameStore((s) => s.setSetting);
	const setLang = useGameStore((s) => s.setLang);
	const resetAll = useGameStore((s) => s.resetAll);
	const setScreen = useGameStore((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		setVolumes(settings.sfx, settings.music);
	}, [settings.sfx, settings.music]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col px-4 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("settings", lang),
				onBack: () => setScreen("title")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-6 text-xs text-muted",
				children: t("sfx", lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .05,
				value: settings.sfx,
				onChange: (e) => setSetting({ sfx: Number(e.target.value) }),
				className: "mt-1 w-full accent-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-5 text-xs text-muted",
				children: t("music", lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .05,
				value: settings.music,
				onChange: (e) => setSetting({ music: Number(e.target.value) }),
				className: "mt-1 w-full accent-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "mt-5 flex h-11 items-center justify-between rounded-md border border-border bg-surface px-4 text-sm",
				onClick: () => setSetting({ shake: !settings.shake }),
				children: [t("shake", lang), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: settings.shake ? "On" : "Off"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "mt-2 flex h-11 items-center justify-between rounded-md border border-border bg-surface px-4 text-sm",
				onClick: () => setLang(lang === "ar" ? "en" : "ar"),
				children: [t("lang", lang), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: lang === "ar" ? "العربية" : "English"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				className: "mt-8",
				onClick: () => {
					if (confirm(t("confirmReset", lang))) resetAll();
				},
				children: t("reset", lang)
			})
		]
	});
}
function HowScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const setScreen = useGameStore((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col px-5 pt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: t("how", lang),
			onBack: () => setScreen("title")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 max-w-md text-sm leading-relaxed text-muted",
			children: t("howBody", lang)
		})]
	});
}
function InstallScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const setScreen = useGameStore((s) => s.setScreen);
	const [deferred, setDeferred] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const onPrompt = (e) => {
			e.preventDefault();
			setDeferred(e);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col px-5 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
				title: t("install", lang),
				onBack: () => setScreen("title")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 max-w-md text-sm leading-relaxed text-muted",
				children: t("installBody", lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-6",
				onClick: async () => {
					if (deferred) {
						await deferred.prompt();
						setDeferred(null);
						return;
					}
					window.location.href = "/?install=1";
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), t("installNow", lang)]
			})
		]
	});
}
function PlayLayer() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const world = useGameStore((s) => s.playWorld);
	const room = useGameStore((s) => s.playRoom);
	const session = useGameStore((s) => s.session);
	const save = useGameStore((s) => s.save);
	const hud = useGameStore((s) => s.hud);
	const lang = save.settings.lang;
	const screen = useGameStore((s) => s.screen);
	const applyHud = useGameStore((s) => s.applyHud);
	const nextRoom = useGameStore((s) => s.nextRoom);
	const failWorld = useGameStore((s) => s.failWorld);
	const setScreen = useGameStore((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const game = new TrickspireGame(canvas, {
			onHud: applyHud,
			onDeath: () => {},
			onRoomClear: () => {
				const g = gameRef.current;
				if (g) {
					const st = useGameStore.getState();
					useGameStore.setState({ save: {
						...st.save,
						coins: g.coins,
						souls: g.souls
					} });
				}
				nextRoom();
			},
			onWorldFail: () => failWorld(),
			onWorldClear: () => {},
			onCoin: () => {},
			onCheckpoint: () => {}
		});
		game.lang = lang;
		game.shakeOn = save.settings.shake;
		game.start(world, room, save.souls, save.coins);
		gameRef.current = game;
		setVolumes(save.settings.sfx, save.settings.music);
		const onHint = () => game.setHint(8);
		window.addEventListener("trickspire-hint", onHint);
		return () => {
			window.removeEventListener("trickspire-hint", onHint);
			game.destroy();
			gameRef.current = null;
		};
	}, [
		world,
		room,
		session
	]);
	(0, import_react.useEffect)(() => {
		const g = gameRef.current;
		if (!g) return;
		g.setPaused(screen !== "play");
		g.shakeOn = save.settings.shake;
		g.lang = lang;
	}, [
		screen,
		save.settings.shake,
		lang
	]);
	const playing = screen === "play";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-full w-full bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 m-auto h-full w-full touch-none object-contain",
				style: {
					imageRendering: "auto",
					touchAction: "none"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudBar, {}),
			hud.signAr && playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute top-16 left-1/2 z-10 w-[min(90%,22rem)] -translate-x-1/2 rounded-md border border-border bg-surface/90 px-3 py-2 text-center text-sm text-fg",
				children: lang === "ar" ? hud.signAr : hud.signEn
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchPad, {
				onLeft: (v) => {
					if (gameRef.current) gameRef.current.input.touchLeft = v;
				},
				onRight: (v) => {
					if (gameRef.current) gameRef.current.input.touchRight = v;
				},
				onJump: (v) => {
					if (gameRef.current) gameRef.current.input.touchJump = v;
				}
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "absolute top-3 end-3 z-10 flex size-11 items-center justify-center rounded-md border border-border bg-surface/80",
				onClick: () => setScreen("pause"),
				"aria-label": t("pause", lang),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
			})
		]
	});
}
function HudBar() {
	const hud = useGameStore((s) => s.hud);
	const lang = useGameStore((s) => s.save.settings.lang);
	const world = WORLDS_INFO[hud.world];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute top-3 start-3 z-10 flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-2 rounded-md border border-border bg-surface/80 px-2.5 py-1.5 text-xs tabular-nums",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "inline-flex items-center gap-1",
				children: Array.from({ length: 10 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-2 rounded-full", i < hud.souls ? "bg-soul" : "bg-soul-dim") }, i))
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border border-border bg-surface/80 px-2.5 py-1 text-xs text-muted whitespace-nowrap",
			children: [
				(lang === "ar" ? world?.nameAr : world?.nameEn) ?? "",
				" · ",
				t("room", lang),
				" ",
				hud.room + 1,
				"/",
				10,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ms-2 inline-flex items-center gap-1 tabular-nums text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-3" }), hud.coins]
				})
			]
		})]
	});
}
function TouchPad({ onLeft, onRight, onJump }) {
	const lang = useGameStore((s) => s.save.settings.lang);
	const hold = (fn) => ({
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			fn(true);
		},
		onPointerUp: () => fn(false),
		onPointerCancel: () => fn(false)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "ltr",
		className: "absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "h-16 w-16 rounded-lg border border-border bg-surface/70 text-lg",
				...hold((v) => onLeft(v ? 1 : 0)),
				children: lang === "ar" ? "←" : "←"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "h-16 w-16 rounded-lg border border-border bg-surface/70 text-lg",
				...hold((v) => onRight(v ? 1 : 0)),
				children: "→"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "h-16 w-24 rounded-lg border border-border bg-accent/90 font-display text-sm text-accent-fg",
			...hold(onJump),
			children: t("jump", lang)
		})]
	});
}
function PauseOverlay() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const setScreen = useGameStore((s) => s.setScreen);
	const watchAd = useGameStore((s) => s.watchAd);
	const buy = useGameStore((s) => s.buy);
	const gameHint = () => {
		if (buy(15, (s) => s)) window.dispatchEvent(new Event("trickspire-hint"));
		else useGameStore.getState().setToast(t("needCoins", lang));
	};
	(0, import_react.useEffect)(() => {}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: t("pause", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-6 w-full",
			onClick: () => setScreen("play"),
			children: t("resume", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			className: "mt-2 w-full",
			onClick: () => watchAd("rewarded-soul"),
			children: t("extraSoul", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			className: "mt-2 w-full",
			onClick: gameHint,
			children: t("hint", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			className: "mt-2 w-full",
			onClick: () => setScreen("title"),
			children: t("menu", lang)
		})
	] });
}
function RoomClearOverlay() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const playWorld = useGameStore((s) => s.playWorld);
	const playRoom = useGameStore((s) => s.playRoom);
	const startRun = useGameStore((s) => s.startRun);
	const watchAd = useGameStore((s) => s.watchAd);
	const save = useGameStore((s) => s.save);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: t("roomClear", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted",
			children: [
				t("room", lang),
				" ",
				playRoom,
				"/",
				10
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-6 w-full",
			onClick: () => {
				if (!save.adsRemoved && playRoom % 5 === 0) {
					watchAd("interstitial");
					return;
				}
				startRun(playWorld, playRoom);
			},
			children: t("next", lang)
		})
	] });
}
function WorldClearOverlay() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const playWorld = useGameStore((s) => s.playWorld);
	const startRun = useGameStore((s) => s.startRun);
	const watchAd = useGameStore((s) => s.watchAd);
	const save = useGameStore((s) => s.save);
	const setScreen = useGameStore((s) => s.setScreen);
	const last = playWorld >= 20;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-2xl",
		children: t("worldClear", lang)
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		className: "mt-6 w-full",
		onClick: () => {
			if (last) {
				setScreen("title");
				return;
			}
			if (!save.adsRemoved) {
				watchAd("interstitial");
				return;
			}
			startRun(playWorld, 0);
		},
		children: t("next", lang)
	})] });
}
function WorldFailOverlay() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const restartWorld = useGameStore((s) => s.restartWorld);
	const watchAd = useGameStore((s) => s.watchAd);
	const setScreen = useGameStore((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: t("worldFail", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: t("worldFailBody", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-6 w-full",
			onClick: restartWorld,
			children: t("restartWorld", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			className: "mt-2 w-full",
			onClick: () => watchAd("rewarded-continue"),
			children: t("watchContinue", lang)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			className: "mt-2 w-full",
			onClick: () => setScreen("title"),
			children: t("menu", lang)
		})
	] });
}
function AdScreen() {
	const lang = useGameStore((s) => s.save.settings.lang);
	const kind = useGameStore((s) => s.adKind);
	const finishAd = useGameStore((s) => s.finishAd);
	const [left, setLeft] = (0, import_react.useState)(kind === "interstitial" ? 3 : 5);
	(0, import_react.useEffect)(() => {
		setLeft(kind === "interstitial" ? 3 : 5);
		const id = window.setInterval(() => {
			setLeft((n) => {
				if (n <= 1) {
					window.clearInterval(id);
					return 0;
				}
				return n - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [kind]);
	const ready = left <= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-bg px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.3em] text-subtle uppercase",
				children: t("adLabel", lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex h-48 w-full max-w-sm items-center justify-center rounded-xl border border-border bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: t("sponsor", lang)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Trickspire Ads"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-8",
				disabled: !ready,
				onClick: finishAd,
				children: ready ? t("skipAd", lang) : `${t("skipAd", lang)} ${left}`
			})
		]
	});
}
function AdBanner() {
	const lang = useGameStore((s) => s.save.settings.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto mt-2 flex h-14 w-full max-w-md items-center justify-center rounded-md border border-border bg-surface-2 text-xs text-subtle",
		children: [
			t("adLabel", lang),
			" · ",
			t("sponsor", lang)
		]
	});
}
function Modal({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/70 px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full max-w-sm rounded-xl border border-border bg-surface p-6",
			children
		})
	});
}
function TopBar({ title, onBack }) {
	const lang = useGameStore((s) => s.save.settings.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon",
			onClick: onBack,
			"aria-label": t("back", lang),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 rtl:rotate-180" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-xl",
			children: title
		})]
	});
}
function Toast() {
	const toast = useGameStore((s) => s.toast);
	const setToast = useGameStore((s) => s.setToast);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = window.setTimeout(() => setToast(null), 1800);
		return () => window.clearTimeout(id);
	}, [toast, setToast]);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute bottom-24 left-1/2 z-40 -translate-x-1/2 rounded-md border border-border bg-surface px-3 py-2 text-sm",
		children: toast
	});
}
function towerWash() {
	return { background: "radial-gradient(1200px 500px at 50% -10%, #1c1824 0%, transparent 70%), repeating-linear-gradient(90deg, transparent 0 40px, rgba(240,235,227,0.03) 40px 41px)" };
}
function bootAudio() {
	unlockAudio();
	startMusic();
	const s = useGameStore.getState().save.settings;
	setVolumes(s.sfx, s.music);
	sfx.click();
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
